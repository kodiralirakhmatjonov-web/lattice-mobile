# iumrah Business signing files

This directory is intentionally created without signing material.

After running **Prepare iOS Signing CSR**, upload these three files here:

- `distribution-private-key.enc`
- `AppleDistribution.cer`
- `iumrah-business.mobileprovision`

Never commit an unencrypted `.pem`, `.key`, `.p12`, Apple Account password, app-specific password, or `.p8` key.
