import Foundation

actor APIClient {
    static let shared = APIClient()

    private let session: URLSession
    let decoder: JSONDecoder
    let encoder: JSONEncoder

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.httpCookieStorage = HTTPCookieStorage.shared
        configuration.httpShouldSetCookies = true
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        session = URLSession(configuration: configuration)
        decoder = JSONDecoder()
        encoder = JSONEncoder()
    }

    func login(login: String, password: String) async throws -> SessionUser {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/auth/staff/login"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["login": login, "password": password])
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        let result = try decoder.decode(LoginResponse.self, from: data)
        guard result.ok == true, let resolvedLogin = result.login else { throw APIError.server(result.error ?? "LOGIN_FAILED") }
        BusinessSessionVault.clearSessionToken()
        _ = try await ensureBusinessSession()
        return SessionUser(login: resolvedLogin, role: result.role ?? "superadmin", displayName: "Super Administrator")
    }

    func sessionUser() async throws -> SessionUser {
        let (data, response) = try await perform(from: AppConfig.apiBaseURL.appending(path: "/api/auth/staff/session"))
        try validate(response, data: data)
        let value = try decoder.decode(SessionResponse.self, from: data)
        guard let user = value.user else { throw APIError.unauthorized }
        _ = try await ensureBusinessSession()
        return user
    }

    func logout() async {
        if BusinessSessionVault.sessionToken != nil {
            var sessionRequest = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/security/sessions/current"))
            sessionRequest.httpMethod = "DELETE"
            _ = try? await perform(sessionRequest)
        }
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/auth/staff/logout"))
        request.httpMethod = "POST"
        _ = try? await perform(request)
        BusinessSessionVault.clearSessionToken()
        HTTPCookieStorage.shared.cookies?.forEach { cookie in
            if cookie.domain.contains("iumrah.app") { HTTPCookieStorage.shared.deleteCookie(cookie) }
        }
    }

    func clearLocalBusinessSession() {
        BusinessSessionVault.clearSessionToken()
    }

    func businessSessions() async throws -> BusinessSessionsResponse {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/security/sessions")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BusinessSessionsResponse.self, from: data)
    }

    func approveBusinessSession(id: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/security/sessions/\(id)/approve"))
        request.httpMethod = "POST"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        _ = try decoder.decode(BusinessSessionActionResponse.self, from: data)
    }

    func terminateBusinessSession(id: String) async throws -> Bool {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/security/sessions/\(id)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        let result = try decoder.decode(BusinessSessionActionResponse.self, from: data)
        if result.signedOut == true { BusinessSessionVault.clearSessionToken() }
        return result.signedOut == true
    }

    func terminateOtherBusinessSessions() async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/security/sessions/others"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        _ = try decoder.decode(BusinessSessionActionResponse.self, from: data)
    }

    private func ensureBusinessSession() async throws -> BusinessAccountSession {
        let identity = try BusinessSessionVault.installationIdentity()
        let payload = BusinessDeviceDescriptor.registrationPayload(identity: identity)
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/security/sessions/register"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(payload)
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        let result = try decoder.decode(BusinessSessionRegistrationResponse.self, from: data)
        if let token = result.sessionToken, !token.isEmpty {
            try BusinessSessionVault.setSessionToken(token)
        } else if BusinessSessionVault.sessionToken == nil {
            throw APIError.server("BUSINESS_SESSION_TOKEN_MISSING")
        }
        return result.currentSession
    }

    func bookings() async throws -> [BookingSummary] {
        let (data, response) = try await perform(from: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings"))
        try validate(response, data: data)
        return try decoder.decode(BookingsResponse.self, from: data).bookings
    }

    func businessProfile() async throws -> BusinessTeamMember {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/me")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BusinessTeamMemberResponse.self, from: data).member
    }

    func saveBusinessProfile(_ member: BusinessTeamMember) async throws -> BusinessTeamMember {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/me"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BusinessTeamMemberPayload(member))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessTeamMemberResponse.self, from: data).member
    }

    func businessTeam() async throws -> [BusinessTeamMember] {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/team")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BusinessTeamResponse.self, from: data).members
    }

    func createBusinessTeamMember(_ member: BusinessTeamMember) async throws -> BusinessTeamMember {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/team"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BusinessTeamMemberPayload(member))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessTeamMemberResponse.self, from: data).member
    }

    func updateBusinessTeamMember(_ member: BusinessTeamMember) async throws -> BusinessTeamMember {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/team/\(member.id)"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BusinessTeamMemberPayload(member))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessTeamMemberResponse.self, from: data).member
    }

    func uploadBusinessTeamPhoto(memberID: String, imageData: Data) async throws -> BusinessTeamMember {
        let optimized = try ImageOptimizer.jpegData(from: imageData, maxDimension: 1200, quality: 0.80, targetBytes: 500_000)
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/team/\(memberID)/photo"))
        request.httpMethod = "POST"
        request.timeoutInterval = 75
        request.setValue("image/jpeg", forHTTPHeaderField: "Content-Type")
        request.httpBody = optimized
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessTeamMemberResponse.self, from: data).member
    }

    func deleteBusinessTeamPhoto(memberID: String) async throws -> BusinessTeamMember {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/team/\(memberID)/photo"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessTeamMemberResponse.self, from: data).member
    }

    func deleteBusinessTeamMember(id: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/team/\(id)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }

    func paymentTemplates() async throws -> [BusinessPaymentTemplate] {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/payment-templates")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BusinessPaymentTemplatesResponse.self, from: data).templates
    }

    func createPaymentTemplate(_ template: BusinessPaymentTemplate) async throws -> BusinessPaymentTemplate {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/payment-templates"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BusinessPaymentTemplatePayload(template))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessPaymentTemplateResponse.self, from: data).template
    }

    func updatePaymentTemplate(_ template: BusinessPaymentTemplate) async throws -> BusinessPaymentTemplate {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/payment-templates/\(template.id)"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BusinessPaymentTemplatePayload(template))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessPaymentTemplateResponse.self, from: data).template
    }

    func deletePaymentTemplate(id: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/payment-templates/\(id)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }

    func uploadPaymentTemplateQR(templateID: String, data: Data, contentType: String = "image/jpeg") async throws -> BusinessPaymentTemplate {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/payment-templates/\(templateID)/qr"))
        request.httpMethod = "POST"
        request.timeoutInterval = 75
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        request.httpBody = data
        let (body, response) = try await perform(request)
        try validate(response, data: body)
        return try decoder.decode(BusinessPaymentTemplateResponse.self, from: body).template
    }

    func deletePaymentTemplateQR(templateID: String) async throws -> BusinessPaymentTemplate {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/payment-templates/\(templateID)/qr"))
        request.httpMethod = "DELETE"
        let (body, response) = try await perform(request)
        try validate(response, data: body)
        return try decoder.decode(BusinessPaymentTemplateResponse.self, from: body).template
    }

    func applyPaymentTemplate(templateID: String, bookingID: String) async throws -> BusinessCheckout {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/payment-template/\(templateID)"))
        request.httpMethod = "POST"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        struct Envelope: Decodable { let ok: Bool; let checkout: BusinessCheckout }
        return try decoder.decode(Envelope.self, from: data).checkout
    }

    func bookingDetail(id: String) async throws -> BookingDetailResponse {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(id)")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BookingDetailResponse.self, from: data)
    }

    func bookingItinerary(bookingID: String) async throws -> [BookingItineraryItem] {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/itinerary")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BookingItineraryResponse.self, from: data).items
    }

    func saveBookingPricing(bookingID: String, components: [BookingPricingComponent], markupRate: Double, paymentFeeRate: Double) async throws -> BookingPricingOverride {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/pricing"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BookingPricingOverrideUpdatePayload(components: components, markupRate: markupRate, paymentFeeRate: paymentFeeRate))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BookingPricingOverrideResponse.self, from: data).pricing
    }

    func saveBookingItinerary(bookingID: String, items: [BookingItineraryItem]) async throws -> [BookingItineraryItem] {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/itinerary"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BookingItineraryUpdatePayload(items: items))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BookingItineraryResponse.self, from: data).items
    }

    func bookingESIMs(bookingID: String) async throws -> [BookingESIMProfile] {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/esims")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BookingESIMListResponse.self, from: data).esims
    }

    func saveBookingESIM(bookingID: String, esimID: String?, payload: BookingESIMUpsertPayload) async throws -> BookingESIMProfile {
        let path = esimID.map { "/api/admin/hotels/operations/bookings/\(bookingID)/esims/\($0)" }
            ?? "/api/admin/hotels/operations/bookings/\(bookingID)/esims"
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: path))
        request.httpMethod = esimID == nil ? "POST" : "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(payload)
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BookingESIMResponse.self, from: data).esim
    }

    func syncBookingESIM(bookingID: String, esimID: String) async throws -> BookingESIMProfile {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/esims/\(esimID)/sync"))
        request.httpMethod = "POST"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BookingESIMResponse.self, from: data).esim
    }

    func deleteBookingESIM(bookingID: String, esimID: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/esims/\(esimID)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        _ = try? decoder.decode(BookingESIMDeleteResponse.self, from: data)
    }

    func updateBookingOperation(id: String, status: TripStatus, paymentStatus: String, confirmationNumber: String, internalNotes: String) async throws -> BookingDetailResponse {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(id)"))
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BookingOperationUpdatePayload(status: status.rawValue, paymentStatus: paymentStatus, confirmationNumber: confirmationNumber, internalNotes: internalNotes))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BookingDetailResponse.self, from: data)
    }

    func savePaymentInstructions(bookingID: String, payload: BusinessPaymentInstructionsPayload) async throws -> BusinessCheckout {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/payment"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(payload)
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        struct Envelope: Decodable { let ok: Bool; let checkout: BusinessCheckout }
        return try decoder.decode(Envelope.self, from: data).checkout
    }

    func uploadPaymeQR(bookingID: String, data: Data, contentType: String = "image/jpeg") async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/payment-qr"))
        request.httpMethod = "POST"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        request.httpBody = data
        let (body, response) = try await perform(request)
        try validate(response, data: body)
    }

    func uploadTravelDocument(bookingID: String, kind: String, title: String, data: Data, contentType: String) async throws {
        var components = URLComponents(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/documents"), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "kind", value: kind), URLQueryItem(name: "title", value: title)]
        var request = URLRequest(url: components.url!)
        request.httpMethod = "POST"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        request.httpBody = data
        let (body, response) = try await perform(request)
        try validate(response, data: body)
    }

    func privateMedia(path: String) async throws -> Data {
        let url: URL
        if let direct = URL(string: path), direct.scheme != nil {
            url = direct
        } else if let relative = URL(string: path, relativeTo: AppConfig.apiBaseURL)?.absoluteURL {
            // Preserve query strings such as ?v=<updated_at>. URL.appending(path:) would
            // treat the question mark as path text and break protected media URLs.
            url = relative
        } else {
            throw APIError.invalidURL
        }
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return data
    }

    func deleteBooking(id: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(id)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        _ = try? decoder.decode(BookingDeleteResponse.self, from: data)
    }

    func verifyFlight(number: String, dateLocal: String, force: Bool = false) async throws -> FlightVerificationResponse {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/flight-verify"))
        request.httpMethod = "POST"
        request.timeoutInterval = 30
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(FlightVerificationPayload(flightNumber: number, dateLocal: dateLocal, force: force))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(FlightVerificationResponse.self, from: data)
    }

    func saveVerifiedFlight(bookingID: String, direction: BookingFlightDirection, verificationKey: String, candidateID: String) async throws -> BookingFlight {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/flights/\(direction.rawValue)"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(SaveVerifiedFlightPayload(verificationKey: verificationKey, candidateID: candidateID))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BookingFlightResponse.self, from: data).flight
    }

    func updateBookingAssignment(bookingID: String, makkahHotelID: String?, madinahHotelID: String?, guideID: String?) async throws -> BookingAssignment {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/bookings/\(bookingID)/assignments"))
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(BookingAssignmentPayload(makkahHotelID: makkahHotelID, madinahHotelID: madinahHotelID, guideID: guideID))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BookingAssignmentResponse.self, from: data).assignment
    }

    func pilgrims(archiveOnly: Bool = false, query: String? = nil) async throws -> [PilgrimSummary] {
        var components = URLComponents(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/pilgrims"), resolvingAgainstBaseURL: false)!
        var items: [URLQueryItem] = []
        if archiveOnly { items.append(URLQueryItem(name: "archive", value: "1")) }
        if let query, !query.isEmpty { items.append(URLQueryItem(name: "q", value: query)) }
        components.queryItems = items.isEmpty ? nil : items
        let (data, response) = try await perform(from: components.url!)
        try validate(response, data: data)
        return try decoder.decode(PilgrimsResponse.self, from: data).pilgrims
    }

    func pilgrimDetail(id: String) async throws -> PilgrimDetailResponse {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/pilgrims/\(id)")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(PilgrimDetailResponse.self, from: data)
    }

    func primaryHotels(city: String? = nil) async throws -> [PrimaryHotelAssignment] {
        var components = URLComponents(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/primary-hotels"), resolvingAgainstBaseURL: false)!
        if let city { components.queryItems = [URLQueryItem(name: "city", value: city)] }
        let (data, response) = try await perform(from: components.url!)
        try validate(response, data: data)
        return try decoder.decode(PrimaryHotelsResponse.self, from: data).assignments
    }

    func savePrimaryHotels(city: String, stars: Int, hotelIDs: [String]) async throws -> [PrimaryHotelAssignment] {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/primary-hotels"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(PrimaryHotelsUpdatePayload(city: city, stars: stars, hotelIDs: hotelIDs))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(PrimaryHotelsResponse.self, from: data).assignments
    }

    func businessChatThreads() async throws -> [BusinessChatThreadSummary] {
        let (data, response) = try await perform(from: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/chats"))
        try validate(response, data: data)
        return try decoder.decode(BusinessChatThreadsResponse.self, from: data).threads
    }

    func businessChatMessages(bookingID: String) async throws -> [BusinessChatMessage] {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/chats/\(bookingID)/messages")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BusinessChatMessagesResponse.self, from: data).messages
    }

    func sendBusinessChatMessage(bookingID: String, body: String, clientMessageID: String) async throws -> BusinessChatMessage {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/chats/\(bookingID)/messages"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(SendBusinessChatMessagePayload(body: body, clientMessageID: clientMessageID))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessChatMessageResponse.self, from: data).message
    }

    func sendBusinessChatImage(bookingID: String, data: Data) async throws -> BusinessChatMessage {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/chats/\(bookingID)/attachments"))
        request.httpMethod = "POST"
        request.timeoutInterval = 75
        request.setValue("image/jpeg", forHTTPHeaderField: "Content-Type")
        request.httpBody = data
        let (responseData, response) = try await perform(request)
        try validate(response, data: responseData)
        return try decoder.decode(BusinessChatMessageResponse.self, from: responseData).message
    }

    func markBusinessChatRead(bookingID: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/chats/\(bookingID)/read"))
        request.httpMethod = "POST"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }

    func registerPushDevice(token: String, environment: String = "production") async throws -> PushDeviceRegistrationResponse {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/push/devices"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(PushDeviceRegistrationPayload(deviceToken: token, environment: environment))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(PushDeviceRegistrationResponse.self, from: data)
    }

    func pushStatus() async throws -> PushStatusResponse {
        let (data, response) = try await perform(from: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/push/status"))
        try validate(response, data: data)
        return try decoder.decode(PushStatusResponse.self, from: data)
    }

    func hotels() async throws -> [HotelListItem] {
        let (data, response) = try await perform(from: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels"))
        try validate(response, data: data)
        return try decoder.decode(HotelsResponse.self, from: data).hotels
    }

    func hotelDetail(id: String) async throws -> HotelAdminDetail {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(id)")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(HotelAdminDetailResponse.self, from: data).hotel
    }

    func updateHotelStars(id: String, stars: Int) async throws -> HotelAdminDetail {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(id)"))
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(HotelStarsUpdatePayload(stars: stars))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelAdminDetailResponse.self, from: data).hotel
    }

    func updateHotelCity(id: String, city: String) async throws -> HotelAdminDetail {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(id)"))
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(HotelCityUpdatePayload(city: city))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelAdminDetailResponse.self, from: data).hotel
    }

    func setManualHotelPrice(id: String, nightlyUSD: Double) async throws -> HotelPriceResponse {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(id)/price"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(HotelManualPriceUpdatePayload(nightlyUSD: nightlyUSD))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelPriceResponse.self, from: data)
    }

    func clearManualHotelPrice(id: String) async throws -> HotelPriceResponse {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(id)/price"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelPriceResponse.self, from: data)
    }

    // MARK: - ChatGPT hotel price update v2
    //
    // The public city feed is a read-only mirror of the catalog currently shown
    // in iumrah Business. ChatGPT returns one strict v2 JSON document which is
    // pasted into the app. Preview revalidates city, snapshot, dates, source and
    // old price before a row can be selected. Only high-confidence direct-source
    // rows can be written to the production price cache.

    func previewHotelPriceJSON(_ document: HotelPriceUpdateDocument) async throws -> HotelPriceJSONPreview {
        guard document.schema == "iumrah.hotel-price-update.v2" else {
            throw APIError.server("UNSUPPORTED_PRICE_UPDATE_SCHEMA")
        }
        let sync = try await hotelSyncStatus(city: document.city)
        try validateHotelPriceDocument(document, sync: sync)
        let currentHotels = try await hotels()
        return buildLocalHotelPriceJSONPreview(document, currentHotels: currentHotels)
    }

    func applyHotelPriceJSON(_ document: HotelPriceUpdateDocument, hotelIDs: [String]) async throws -> HotelPriceJSONApplyResponse {
        guard document.schema == "iumrah.hotel-price-update.v2" else {
            throw APIError.server("UNSUPPORTED_PRICE_UPDATE_SCHEMA")
        }

        let sync = try await hotelSyncStatus(city: document.city)
        try validateHotelPriceDocument(document, sync: sync)

        // Revalidate immediately before writing so a changed catalog/source cannot
        // be silently overwritten by an older ChatGPT result.
        let latestHotels = try await hotels()
        let latestPreview = buildLocalHotelPriceJSONPreview(document, currentHotels: latestHotels)
        let selected = Set(hotelIDs)
        let ready = latestPreview.items.filter { selected.contains($0.hotelID) && $0.selectable && $0.reviewStatus == "ready" }
        let updatesByID = Dictionary(uniqueKeysWithValues: document.hotels.map { ($0.hotelID, $0) })

        var appliedIDs: [String] = []
        for item in ready {
            guard let update = updatesByID[item.hotelID],
                  let newPrice = roundedPriceExchangeValue(item.newNightlyUSD), newPrice > 0 else { continue }
            let payload = HotelVerifiedPriceUpdatePayload(
                sourceSnapshotID: document.sourceSnapshotID,
                oldNightlyUSD: roundedPriceExchangeValue(update.oldNightlyUSD),
                nightlyUSD: newPrice,
                provider: update.provider,
                sourceURL: update.sourceURL,
                checkedSourceURL: update.checkedSourceURL,
                checkIn: document.checkIn,
                checkOut: document.checkOut,
                rooms: document.rooms,
                adults: document.adults,
                confidence: "high",
                checkedAt: update.checkedAt ?? document.checkedAt,
                evidence: update.evidence
            )
            do {
                _ = try await setVerifiedHotelPrice(id: item.hotelID, payload: payload)
                appliedIDs.append(item.hotelID)
            } catch {
                // Keep successfully applied rows. Failed rows remain selectable on
                // the returned preview and can be retried without duplicating data.
                continue
            }
        }

        let appliedSet = Set(appliedIDs)
        let finalItems = latestPreview.items.map { item -> HotelPriceJSONPreviewItem in
            guard appliedSet.contains(item.hotelID) else { return item }
            return HotelPriceJSONPreviewItem(
                hotelID: item.hotelID,
                hotelName: item.hotelName,
                status: item.status,
                oldNightlyUSD: item.oldNightlyUSD,
                newNightlyUSD: item.newNightlyUSD,
                provider: item.provider,
                sourceURL: item.sourceURL,
                checkedSourceURL: item.checkedSourceURL,
                checkIn: item.checkIn,
                checkOut: item.checkOut,
                confidence: item.confidence,
                evidence: item.evidence,
                reason: item.reason,
                checkedAt: item.checkedAt,
                city: item.city,
                stars: item.stars,
                currentNightlyUSD: item.newNightlyUSD,
                currentProvider: item.currentProvider,
                currentSourceURL: item.currentSourceURL,
                isManualOverride: false,
                reviewStatus: "applied",
                selectable: false,
                issue: nil,
                deltaUSD: 0,
                deltaPercent: 0
            )
        }
        let finalPreview = makeHotelPriceJSONPreview(document: document, items: finalItems)
        let now = priceExchangeTimestamp()

        return HotelPriceJSONApplyResponse(
            ok: true,
            applied: appliedIDs.count,
            requested: selected.count,
            skipped: max(0, selected.count - appliedIDs.count),
            appliedHotelIDs: appliedIDs,
            preview: finalPreview,
            appliedBy: nil,
            appliedAt: now
        )
    }

    private func validateHotelPriceDocument(_ document: HotelPriceUpdateDocument, sync: BusinessHotelSyncStatusResponse) throws {
        guard let expectedCity = canonicalPriceExchangeCity(document.city), expectedCity == sync.city else {
            throw APIError.server("PRICE_UPDATE_CITY_MISMATCH")
        }
        guard sync.enabled, sync.configured else {
            throw APIError.server("HOTEL_SYNC_ACCESS_NOT_ENABLED")
        }
        guard let snapshotID = sync.snapshotID, snapshotID == document.sourceSnapshotID else {
            throw APIError.server("HOTEL_SYNC_SNAPSHOT_CHANGED")
        }
        guard sync.checkIn == document.checkIn, sync.checkOut == document.checkOut else {
            throw APIError.server("HOTEL_SYNC_DATES_CHANGED")
        }
        guard document.rooms == 1, document.adults == 2 else {
            throw APIError.server("HOTEL_SYNC_OCCUPANCY_MISMATCH")
        }
    }

    private func buildLocalHotelPriceJSONPreview(_ document: HotelPriceUpdateDocument, currentHotels: [HotelListItem]) -> HotelPriceJSONPreview {
        let currentByID = Dictionary(uniqueKeysWithValues: currentHotels.map { ($0.id, $0) })
        let expectedCity = canonicalPriceExchangeCity(document.city)

        let items = document.hotels.map { update -> HotelPriceJSONPreviewItem in
            guard let hotel = currentByID[update.hotelID] else {
                return previewItem(update, hotelName: update.hotelName ?? update.hotelID, confidence: priceExchangeConfidence(update.confidence), reviewStatus: "invalid", selectable: false, issue: "HOTEL_NOT_FOUND")
            }

            let confidence = priceExchangeConfidence(update.confidence)
            let currentPrice = roundedPriceExchangeValue(hotel.price?.nightlyUSD)
            let currentSource = hotel.sourceURL ?? hotel.price?.sourceURL
            let currentProvider = normalizedPriceExchangeProvider(hotel.sourceProvider ?? hotel.price?.provider, sourceURL: currentSource)
            let city = canonicalPriceExchangeCity(hotel.city)
            let updateProvider = normalizedPriceExchangeProvider(update.provider, sourceURL: update.sourceURL)
            let status = update.status.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)

            var reviewStatus = "invalid"
            var selectable = false
            var issue: String? = nil

            if expectedCity == nil || city != expectedCity {
                reviewStatus = "conflict"
                issue = "CITY_CHANGED"
            } else if update.checkIn != document.checkIn || update.checkOut != document.checkOut {
                reviewStatus = "invalid"
                issue = "DATES_NOT_VERIFIED"
            } else if (update.rooms ?? document.rooms) != document.rooms || (update.adults ?? document.adults) != document.adults {
                reviewStatus = "invalid"
                issue = "OCCUPANCY_NOT_VERIFIED"
            } else if !priceExchangePricesMatch(currentPrice, update.oldNightlyUSD) {
                reviewStatus = "conflict"
                issue = "PRICE_CHANGED_AFTER_SNAPSHOT"
            } else if !priceExchangeSourcesMatch(currentSource, update.sourceURL) {
                reviewStatus = "conflict"
                issue = "SOURCE_CHANGED_AFTER_SNAPSHOT"
            } else if currentProvider != nil && updateProvider != nil && currentProvider != updateProvider {
                reviewStatus = "conflict"
                issue = "PROVIDER_MISMATCH"
            } else if status == "unchanged" {
                reviewStatus = "unchanged"
            } else if status == "unverified" {
                reviewStatus = "unverified"
                issue = update.reason ?? "SOURCE_NOT_VERIFIED"
            } else if status == "changed" {
                guard let newPrice = roundedPriceExchangeValue(update.newNightlyUSD), newPrice > 0 else {
                    return previewItem(update, hotel: hotel, confidence: confidence, currentPrice: currentPrice, currentProvider: currentProvider, currentSourceURL: currentSource, reviewStatus: "invalid", selectable: false, issue: "INVALID_NEW_PRICE")
                }
                guard let checked = update.checkedSourceURL, priceExchangeSourcesMatch(update.sourceURL, checked) else {
                    return previewItem(update, hotel: hotel, confidence: confidence, currentPrice: currentPrice, currentProvider: currentProvider, currentSourceURL: currentSource, reviewStatus: "invalid", selectable: false, issue: "DIRECT_SOURCE_NOT_VERIFIED")
                }
                guard priceExchangeCheckedURLMatchesDates(checked, provider: updateProvider, checkIn: document.checkIn, checkOut: document.checkOut) else {
                    return previewItem(update, hotel: hotel, confidence: confidence, currentPrice: currentPrice, currentProvider: currentProvider, currentSourceURL: currentSource, reviewStatus: "invalid", selectable: false, issue: "CHECKED_SOURCE_DATES_NOT_VERIFIED")
                }
                if confidence.label == "high" {
                    if priceExchangePricesMatch(currentPrice, newPrice) {
                        reviewStatus = "unchanged"
                    } else {
                        reviewStatus = "ready"
                        selectable = true
                    }
                } else {
                    reviewStatus = "needs_review"
                    issue = "HIGH_CONFIDENCE_REQUIRED"
                }
            } else {
                reviewStatus = "invalid"
                issue = "INVALID_RESULT_STATUS"
            }

            return previewItem(update, hotel: hotel, confidence: confidence, currentPrice: currentPrice, currentProvider: currentProvider, currentSourceURL: currentSource, reviewStatus: reviewStatus, selectable: selectable, issue: issue)
        }

        return makeHotelPriceJSONPreview(document: document, items: items)
    }

    private func previewItem(
        _ update: HotelPriceUpdateItem,
        hotel: HotelListItem? = nil,
        hotelName: String? = nil,
        confidence: HotelPriceJSONConfidence,
        currentPrice: Double? = nil,
        currentProvider: String? = nil,
        currentSourceURL: String? = nil,
        reviewStatus: String,
        selectable: Bool,
        issue: String?
    ) -> HotelPriceJSONPreviewItem {
        let newPrice = roundedPriceExchangeValue(update.newNightlyUSD)
        let delta: Double?
        let percent: Double?
        if let currentPrice, let newPrice {
            let raw = newPrice - currentPrice
            delta = (raw * 100).rounded() / 100
            percent = currentPrice > 0 ? ((raw / currentPrice) * 10_000).rounded() / 100 : nil
        } else {
            delta = nil
            percent = nil
        }

        return HotelPriceJSONPreviewItem(
            hotelID: update.hotelID,
            hotelName: hotel?.name ?? hotelName ?? update.hotelName ?? update.hotelID,
            status: update.status,
            oldNightlyUSD: roundedPriceExchangeValue(update.oldNightlyUSD),
            newNightlyUSD: newPrice,
            provider: normalizedPriceExchangeProvider(update.provider, sourceURL: update.sourceURL),
            sourceURL: update.sourceURL,
            checkedSourceURL: update.checkedSourceURL,
            checkIn: update.checkIn,
            checkOut: update.checkOut,
            confidence: confidence,
            evidence: update.evidence,
            reason: update.reason,
            checkedAt: update.checkedAt,
            city: hotel?.city,
            stars: hotel?.stars,
            currentNightlyUSD: currentPrice,
            currentProvider: currentProvider,
            currentSourceURL: currentSourceURL,
            isManualOverride: hotel?.price?.isManualOverride,
            reviewStatus: reviewStatus,
            selectable: selectable,
            issue: issue,
            deltaUSD: delta,
            deltaPercent: percent
        )
    }

    private func makeHotelPriceJSONPreview(document: HotelPriceUpdateDocument, items: [HotelPriceJSONPreviewItem]) -> HotelPriceJSONPreview {
        HotelPriceJSONPreview(
            schema: document.schema,
            sourceSnapshotID: document.sourceSnapshotID,
            city: document.city,
            checkIn: document.checkIn,
            checkOut: document.checkOut,
            checkedAt: document.checkedAt,
            total: items.count,
            changed: items.filter { $0.reviewStatus == "ready" }.count,
            unchanged: items.filter { $0.reviewStatus == "unchanged" || $0.reviewStatus == "applied" }.count,
            conflicts: items.filter { $0.reviewStatus == "conflict" }.count,
            unverified: items.filter { $0.reviewStatus == "unverified" || $0.reviewStatus == "needs_review" }.count,
            invalid: items.filter { $0.reviewStatus == "invalid" }.count,
            items: items
        )
    }

    private func canonicalPriceExchangeCity(_ value: String?) -> String? {
        let raw = (value ?? "").lowercased().replacingOccurrences(of: "-", with: " ").replacingOccurrences(of: "_", with: " ")
        if raw.contains("makkah") || raw.contains("mecca") || raw.contains("مكة") { return "Makkah" }
        if raw.contains("madinah") || raw.contains("medina") || raw.contains("المدينة") { return "Madinah" }
        return nil
    }

    private func roundedPriceExchangeValue(_ value: Double?) -> Double? {
        guard let value, value.isFinite, value >= 0, value <= 10_000 else { return nil }
        return (value * 100).rounded() / 100
    }

    private func priceExchangePricesMatch(_ lhs: Double?, _ rhs: Double?) -> Bool {
        let a = roundedPriceExchangeValue(lhs)
        let b = roundedPriceExchangeValue(rhs)
        if a == nil && b == nil { return true }
        guard let a, let b else { return false }
        return abs(a - b) < 0.01
    }

    private func priceExchangeSourcesMatch(_ lhs: String?, _ rhs: String?) -> Bool {
        let a = lhs?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let b = rhs?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if a.isEmpty && b.isEmpty { return true }
        guard !a.isEmpty, !b.isEmpty else { return false }
        if a == b { return true }
        guard let ua = URL(string: a), let ub = URL(string: b) else { return false }
        let pathA = ua.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let pathB = ub.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let hostA = ua.host?.lowercased().replacingOccurrences(of: "www.", with: "")
        let hostB = ub.host?.lowercased().replacingOccurrences(of: "www.", with: "")
        return hostA == hostB && pathA.lowercased() == pathB.lowercased()
    }

    private func priceExchangeCheckedURLMatchesDates(_ value: String, provider: String?, checkIn: String, checkOut: String) -> Bool {
        guard let components = URLComponents(string: value) else { return false }
        let params = Dictionary(
            (components.queryItems ?? []).map { ($0.name.lowercased(), $0.value ?? "") },
            uniquingKeysWith: { _, newest in newest }
        )
        switch provider {
        case "Booking":
            return params["checkin"] == checkIn && params["checkout"] == checkOut
        case "Expedia":
            let inDate = params["chkin"] ?? params["startdate"]
            let outDate = params["chkout"] ?? params["enddate"]
            return inDate == checkIn && outDate == checkOut
        default:
            return false
        }
    }

    private func normalizedPriceExchangeProvider(_ value: String?, sourceURL: String?) -> String? {
        let raw = (value ?? "").lowercased()
        if raw.contains("booking") { return "Booking" }
        if raw.contains("expedia") { return "Expedia" }
        if let host = URL(string: sourceURL ?? "")?.host?.lowercased() {
            if host == "booking.com" || host.hasSuffix(".booking.com") { return "Booking" }
            if host == "expedia.com" || host.hasSuffix(".expedia.com") || host.contains("expedia.") { return "Expedia" }
        }
        let trimmed = value?.trimmingCharacters(in: .whitespacesAndNewlines)
        return (trimmed?.isEmpty == false) ? trimmed : nil
    }

    private func priceExchangeConfidence(_ value: String?) -> HotelPriceJSONConfidence {
        switch (value ?? "").lowercased() {
        case "high": return HotelPriceJSONConfidence(label: "high", score: 0.98)
        case "medium": return HotelPriceJSONConfidence(label: "medium", score: 0.80)
        case "low": return HotelPriceJSONConfidence(label: "low", score: 0.55)
        default: return HotelPriceJSONConfidence(label: "none", score: 0)
        }
    }

    private func priceExchangeTimestamp() -> String {
        ISO8601DateFormatter().string(from: Date())
    }

    func hotelCloudHealth() async throws -> HotelCloudHealthResponse {
        let (data, response) = try await perform(from: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/health"))
        try validate(response, data: data)
        return try decoder.decode(HotelCloudHealthResponse.self, from: data)
    }

    func checkHotelSourceDuplicate(_ sourceURL: String) async throws -> HotelDuplicate? {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/dedupe"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(HotelSourceDuplicatePayload(sourceURL: sourceURL))
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelDuplicateResponse.self, from: data).duplicate
    }

    func checkHotelDuplicate(_ hotel: HotelDraft) async throws -> HotelDuplicate? {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/dedupe"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(hotel)
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelDuplicateResponse.self, from: data).duplicate
    }

    func startHotelImport(
        _ hotel: HotelDraft,
        publishWhenComplete: Bool,
        idempotencyKey: String,
        allowPossibleDuplicate: Bool = false
    ) async throws -> HotelImportJob {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/import-jobs"))
        request.httpMethod = "POST"
        request.timeoutInterval = 45
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(idempotencyKey, forHTTPHeaderField: "Idempotency-Key")
        request.httpBody = try encoder.encode(
            HotelImportStartPayload(
                hotel: hotel,
                images: hotel.selectedImages,
                publishWhenComplete: publishWhenComplete,
                idempotencyKey: idempotencyKey,
                allowPossibleDuplicate: allowPossibleDuplicate
            )
        )
        let (data, response) = try await perform(request)
        if let http = response as? HTTPURLResponse, http.statusCode == 409,
           let conflict = try? decoder.decode(HotelImportConflictResponse.self, from: data),
           let duplicate = conflict.duplicate {
            if conflict.error == "POSSIBLE_DUPLICATE" { throw APIError.possibleDuplicate(duplicate) }
            throw APIError.hotelAlreadyExists(duplicate)
        }
        try validate(response, data: data)
        return try decoder.decode(HotelImportJobResponse.self, from: data).job
    }

    func hotelImportJob(id: String) async throws -> HotelImportJob {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/import-jobs/\(id)")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(HotelImportJobResponse.self, from: data).job
    }

    func hotelImportJobs(activeOnly: Bool = false) async throws -> [HotelImportJob] {
        var components = URLComponents(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/import-jobs"), resolvingAgainstBaseURL: false)!
        if activeOnly { components.queryItems = [URLQueryItem(name: "active", value: "1")] }
        let (data, response) = try await perform(from: components.url!)
        try validate(response, data: data)
        return try decoder.decode(HotelImportJobsResponse.self, from: data).jobs
    }

    func activeHotelImportJobs() async throws -> [HotelImportJob] {
        try await hotelImportJobs(activeOnly: true)
    }

    func retryHotelImportJob(id: String) async throws -> HotelImportJob {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/import-jobs/\(id)/retry"))
        request.httpMethod = "POST"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelImportJobResponse.self, from: data).job
    }

    func cancelHotelImportJob(id: String) async throws -> HotelImportJob {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/import-jobs/\(id)/cancel"))
        request.httpMethod = "POST"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(HotelImportJobResponse.self, from: data).job
    }

    func deleteHotelImportJob(id: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/import-jobs/\(id)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }

    func deleteHotel(id: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(id)"))
        request.httpMethod = "DELETE"
        request.timeoutInterval = 45
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }

    func saveHotel(_ hotel: HotelDraft, allowPossibleDuplicate: Bool = false) async throws -> HotelListItem? {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if allowPossibleDuplicate { request.setValue("1", forHTTPHeaderField: "X-Iumrah-Allow-Possible-Duplicate") }
        request.httpBody = try encoder.encode(hotel)
        let (data, response) = try await perform(request)
        if let http = response as? HTTPURLResponse, http.statusCode == 409,
           let conflict = try? decoder.decode(HotelImportConflictResponse.self, from: data),
           let duplicate = conflict.duplicate {
            if conflict.error == "POSSIBLE_DUPLICATE" { throw APIError.possibleDuplicate(duplicate) }
            throw APIError.hotelAlreadyExists(duplicate)
        }
        try validate(response, data: data)
        return try decoder.decode(HotelSaveResponse.self, from: data).hotel
    }

    func clearHotelImages(hotelID: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(hotelID)/images"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }

    func uploadHotelImage(hotelID: String, candidate: HotelImageCandidate, position: Int) async throws {
        guard let sourceURL = URL(string: candidate.url) else { throw APIError.invalidURL }
        var sourceRequest = URLRequest(url: sourceURL)
        sourceRequest.timeoutInterval = 45
        sourceRequest.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
        sourceRequest.setValue("image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
        sourceRequest.setValue("en-US,en;q=0.9", forHTTPHeaderField: "Accept-Language")
        sourceRequest.setValue(candidate.sourcePageURL, forHTTPHeaderField: "Referer")

        let (imageData, sourceResponse) = try await perform(sourceRequest)
        guard let http = sourceResponse as? HTTPURLResponse, (200..<300).contains(http.statusCode), !imageData.isEmpty else {
            throw APIError.server("IMAGE_DOWNLOAD_FAILED")
        }
        let optimized = try ImageOptimizer.jpegData(from: imageData)

        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/\(hotelID)/images"))
        request.httpMethod = "POST"
        request.timeoutInterval = 75
        request.setValue("image/jpeg", forHTTPHeaderField: "Content-Type")
        request.setValue(candidate.provider, forHTTPHeaderField: "X-Iumrah-Source")
        request.setValue(candidate.kind.rawValue, forHTTPHeaderField: "X-Iumrah-Category")
        request.setValue(candidate.sourcePageURL, forHTTPHeaderField: "X-Iumrah-Source-URL")
        if let label = candidate.label { request.setValue(String(label.prefix(480)), forHTTPHeaderField: "X-Iumrah-Label") }
        if let room = candidate.roomName { request.setValue(String(room.prefix(220)), forHTTPHeaderField: "X-Iumrah-Room") }
        request.setValue(String(position), forHTTPHeaderField: "X-Iumrah-Position")
        request.setValue(candidate.isCover ? "1" : "0", forHTTPHeaderField: "X-Iumrah-Cover")
        request.httpBody = optimized
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }


    func clientNotificationAudience() async throws -> BusinessNotificationAudienceCounts {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/notifications/audience")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BusinessNotificationAudienceResponse.self, from: data).audience
    }

    func clientNotifications() async throws -> [BusinessClientNotification] {
        let url = AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/notifications")
        let (data, response) = try await perform(from: url)
        try validate(response, data: data)
        return try decoder.decode(BusinessClientNotificationsResponse.self, from: data).notifications
    }

    func sendClientNotification(_ payload: BusinessClientNotificationPayload) async throws -> BusinessClientNotificationSendResponse {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/hotels/operations/notifications"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(payload)
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessClientNotificationSendResponse.self, from: data)
    }

    func ziyarats(city: String? = nil) async throws -> [BusinessZiyaratRoute] {
        var components = URLComponents(url: AppConfig.apiBaseURL.appending(path: "/api/admin/ziyarats"), resolvingAgainstBaseURL: false)!
        if let city, !city.isEmpty {
            components.queryItems = [URLQueryItem(name: "city", value: city)]
        }
        let (data, response) = try await perform(from: components.url!)
        try validate(response, data: data)
        return try decoder.decode(BusinessZiyaratCatalogResponse.self, from: data).routes
    }

    func createZiyarat(_ payload: BusinessZiyaratPlacePayload) async throws -> BusinessZiyaratPlace {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/ziyarats"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(payload)
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessZiyaratPlaceResponse.self, from: data).place
    }

    func updateZiyarat(id: String, payload: BusinessZiyaratPlacePayload) async throws -> BusinessZiyaratPlace {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/ziyarats/places/\(id)"))
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try encoder.encode(payload)
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        return try decoder.decode(BusinessZiyaratPlaceResponse.self, from: data).place
    }

    func deleteZiyarat(id: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/ziyarats/places/\(id)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        _ = try? decoder.decode(BusinessZiyaratDeleteResponse.self, from: data)
    }

    func uploadZiyaratImage(placeID: String, imageData: Data, position: Int) async throws {
        let optimized = try ImageOptimizer.ziyaratJPEGData(from: imageData)
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/ziyarats/places/\(placeID)/images"))
        request.httpMethod = "POST"
        request.timeoutInterval = 90
        request.setValue("image/jpeg", forHTTPHeaderField: "Content-Type")
        request.setValue(String(position), forHTTPHeaderField: "X-Iumrah-Position")
        request.httpBody = optimized
        let (data, response) = try await perform(request)
        try validate(response, data: data)
        _ = try decoder.decode(BusinessZiyaratImageUploadResponse.self, from: data)
    }

    func deleteZiyaratImage(placeID: String, imageID: String) async throws {
        var request = URLRequest(url: AppConfig.apiBaseURL.appending(path: "/api/admin/ziyarats/places/\(placeID)/images/\(imageID)"))
        request.httpMethod = "DELETE"
        let (data, response) = try await perform(request)
        try validate(response, data: data)
    }

    func perform(_ original: URLRequest) async throws -> (Data, URLResponse) {
        var request = original
        if let url = request.url,
           url.host?.lowercased() == AppConfig.apiBaseURL.host?.lowercased(),
           url.path.hasPrefix("/api/admin/"),
           let token = BusinessSessionVault.sessionToken {
            request.setValue(token, forHTTPHeaderField: "X-Iumrah-Business-Session")
        }
        return try await session.data(for: request)
    }

    func perform(from url: URL) async throws -> (Data, URLResponse) {
        try await perform(URLRequest(url: url))
    }

    func validate(_ response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
        if http.statusCode == 401 { throw APIError.unauthorized }
        guard (200..<300).contains(http.statusCode) else {
            let message = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["error"] as? String
            throw APIError.server(message ?? "HTTP_\(http.statusCode)")
        }
    }
}

enum APIError: LocalizedError {
    case unauthorized
    case invalidURL
    case invalidResponse
    case possibleDuplicate(HotelDuplicate)
    case hotelAlreadyExists(HotelDuplicate)
    case server(String)

    var errorDescription: String? {
        switch self {
        case .unauthorized: return "Сессия администратора истекла. Войдите снова."
        case .invalidURL: return "Некорректная ссылка."
        case .invalidResponse: return "Сервер вернул некорректный ответ."
        case .possibleDuplicate(let hotel): return "Возможно, этот отель уже есть в базе: \(hotel.name)."
        case .hotelAlreadyExists(let hotel): return "Этот отель уже есть в базе: \(hotel.name)."
        case .server(let value):
            switch value {
            case "PAYMENT_INSTRUCTIONS_REQUIRED": return "Сначала сохраните хотя бы один способ оплаты: Visa, PayMe или Humo."
            case "PAYMENT_TEMPLATE_NOT_FOUND": return "Шаблон реквизитов больше не существует. Обновите список Payments."
            case "PAYMENT_TEMPLATE_QR_NOT_FOUND": return "QR шаблона не найден в хранилище. Откройте Payments и загрузите QR заново."
            case "PAYMENT_TEMPLATE_NAME_REQUIRED": return "Введите название шаблона реквизитов."
            case "PAYMENT_INSTRUCTIONS_LOCKED": return "Реквизиты этой поездки уже нельзя изменять на текущем этапе."
            case "IUMRAH_ACCOUNT_REQUIRED": return "Паломник ещё не активировал свой iumrah ID и пароль."
            case "TRAVELER_DATA_INCOMPLETE": return "Не все анкеты паломников заполнены полностью и с паспортом."
            case "PAYMENT_RECEIPT_REQUIRED": return "Паломник ещё не прикрепил чек оплаты."
            case "TRAVEL_DOCUMENT_REQUIRED": return "Перед статусом «Готово к поездке» загрузите хотя бы один документ поездки."
            case "INVALID_STATUS_TRANSITION": return "Этот переход статуса недоступен из текущего состояния поездки."
            case "PRIMARY_SESSION_REQUIRED": return "Только основное устройство может завершать другие сеансы."
            case "PRIMARY_SESSION_PROTECTED": return "Основной сеанс защищён и не может быть завершён с другого устройства."
            case "DEVICE_BLOCKED": return "Это устройство было отключено с основного устройства."
            case "DEVICE_PROOF_INVALID": return "Не удалось подтвердить защищённую идентичность этого устройства."
            case "BUSINESS_SESSION_TOKEN_MISSING": return "Сервер не выдал защищённый ключ сеанса. Попробуйте войти снова."
            case "ESIM_ACCESS_NOT_CONFIGURED": return "API eSIM Access ещё не подключён к Cloudflare Worker."
            case "ESIM_ACCESS_AUTH_FAILED": return "eSIM Access отклонил API-аутентификацию. Проверьте ESIM_ACCESS_CODE и при необходимости ESIM_ACCESS_SECRET в Cloudflare."
            case "ESIM_ACCESS_BALANCE_INSUFFICIENT": return "Недостаточно средств на балансе eSIM Access. Сначала пополните баланс."
            case "ESIM_ACCESS_PACKAGE_NOT_FOUND": return "Этот тариф больше недоступен. Обновите список тарифов."
            case "ESIM_ACCESS_PRICE_CHANGED": return "Цена тарифа изменилась в eSIM Access. Обновите тарифы и подтвердите покупку заново."
            case "ESIM_ACCESS_PURCHASE_PRIMARY_ONLY": return "Покупать eSIM можно только с основного устройства iumrah Business."
            case "ESIM_ACCESS_PURCHASE_SUPERADMIN_ONLY": return "Покупка eSIM доступна только владельцу / superadmin."
            case "ESIM_ACCESS_PROFILE_NOT_READY": return "eSIM ещё выпускается. Подождите несколько секунд и обновите профиль."
            case "ESIM_ACCESS_PROFILE_ALREADY_ASSIGNED": return "Эта eSIM уже назначена другой поездке."
            case "ESIM_ACCESS_PURCHASE_REQUIRES_REVIEW": return "Предыдущая попытка покупки не получила подтверждение. Проверьте заказ в eSIM Access перед повторной покупкой, чтобы исключить двойное списание."
            case "INVALID_HOTEL_PRICE": return "Введите корректную цену за одну ночь в долларах."
            case "HOTEL_PRICE_REFRESH_IN_PROGRESS": return "Цена уже обновляется из источника. Дождитесь завершения и откройте отель повторно."
            case "HOTEL_PRICE_BROWSER_UNAVAILABLE": return "Облачный браузер цен недоступен. Проверьте развёртывание Hotels Cloud."
            case "HOTEL_PRICE_SOURCE_MISSING": return "Для этого отеля не закреплён источник Booking или Expedia."
            case "HOTEL_PRICE_SOURCE_CHALLENGE": return "Источник запросил проверку браузера. Ручная цена сохранится; попробуйте обновить из источника позже."
            case "HOTEL_PRICE_NOT_FOUND_ON_SOURCE": return "Источник открылся, но актуальную цену на странице определить не удалось."
            case "HOTEL_PRICE_SOURCE_FETCH_FAILED": return "Не удалось открыть источник цены. Попробуйте ещё раз позже."
            case "HOTEL_PRICE_SOURCE_HTTP_429": return "Источник временно ограничил запросы. Последняя сохранённая цена остаётся активной; автоматическое обновление повторится позже."
            default: return value
            }
        }
    }
}
