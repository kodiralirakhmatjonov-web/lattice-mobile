import type { Metadata, Viewport } from "next";
import "./design-system.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "iumrah — Independent Umrah",
  description: "Build and book your Umrah package with direct flights, curated hotels and iumrah Care.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#f6f7f9",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}
