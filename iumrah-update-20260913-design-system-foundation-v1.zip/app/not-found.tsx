import { AppShell } from "@/components/app/AppShell";
import { ButtonLink, PageContainer, PageHeader, Section } from "@/components/ui";

export default function NotFound() {
  return (
    <AppShell>
      <PageContainer size="reading">
        <Section>
          <PageHeader
            align="center"
            kicker="404"
            title="Страница не найдена."
            description="Ссылка устарела или страница была перемещена. Вернитесь на главную и продолжите оттуда."
            actions={<ButtonLink href="/">На главную</ButtonLink>}
          />
        </Section>
      </PageContainer>
    </AppShell>
  );
}
