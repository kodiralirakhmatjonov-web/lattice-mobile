# Iumrah Design System

Version: 1.0 — Foundation

This document is the source of truth for all new and migrated Iumrah web UI. Existing feature CSS that conflicts with this document is legacy debt, not precedent.

The goal is not to make every page look identical. The goal is for every page to use the same visual grammar, interaction rules and quality bar.

---

## 1. Brand Principles

Iumrah is a premium consumer travel product for independent/private Umrah planning. It must not look like a generic travel agency, a religious template, a fintech dashboard or an AI-generated SaaS landing page.

The product character is:

- **Calm** — low visual noise, deliberate emphasis.
- **Precise** — consistent geometry, spacing and states.
- **Human** — clear language, support-oriented tone, real travel context.
- **Premium** — restraint and quality rather than decoration.
- **Product-first** — real itinerary, booking and journey UI is the visual subject.
- **Confident** — one primary action at a time.

Religious identity should come from purpose, content, imagery and respectful language — not ornamental patterns, gold palettes or decorative mosque motifs.

---

## 2. Visual Principles

1. Use whitespace and typography before adding a container.
2. Use a card only when a boundary improves grouping, scanning or interaction.
3. Avoid cards nested inside cards unless the inner surface is an actual interactive sub-item.
4. Color is functional. Neutral UI is the default.
5. Product-category color may aid scanning, but must not become page decoration.
6. Glass/blur is reserved for floating navigation and overlays where depth has a functional meaning.
7. Shadows communicate elevation, not luxury.
8. Display type is used sparingly. Most screens should be dominated by product content, not giant headlines.
9. Do not invent page-specific button, input, radius or shadow systems.
10. A new component must make the system smaller or clearer, not add an exception.

---

## 3. Colors

Canonical variables live in `app/design-system.css`.

| Role | Token | Value / intent |
|---|---|---|
| Brand | `--color-brand` | `#111113` — primary neutral action |
| Accent | `--color-accent` | `#316cff` — focus / selective emphasis |
| Background | `--color-background` | `#f6f7f9` |
| Surface | `--color-surface` | `#ffffff` |
| Secondary surface | `--color-surface-secondary` | `#f1f2f5` |
| Elevated surface | `--color-surface-elevated` | translucent white for floating UI |
| Text primary | `--color-text-primary` | `#111113` |
| Text secondary | `--color-text-secondary` | `#686a72` |
| Text tertiary | `--color-text-tertiary` | `#96989f` |
| Border subtle | `--color-border-subtle` | low-contrast divider/boundary |
| Border default | `--color-border-default` | normal controls/cards |
| Border strong | `--color-border-strong` | hover/selected structure |
| Success | `--color-success` | positive state only |
| Warning | `--color-warning` | caution / availability only |
| Error | `--color-error` | destructive/error only |

### Product accents

Use only where the category itself matters:

- Flight: `--color-flight` / `--color-flight-surface`
- Hotel: `--color-hotel` / `--color-hotel-surface`
- Transfer: `--color-transfer` / `--color-transfer-surface`
- Care: `--color-care` / `--color-care-surface`
- Warm/service: `--color-warm` / `--color-warm-surface`

### Rules

- Do not add a new gray because an existing gray is “almost right”.
- Do not hardcode a color in a reusable component.
- Page photography may contain rich color; UI chrome should remain restrained.
- Error/success colors never replace explanatory text.

---

## 4. Typography

### Font families

Default:

```css
font-family: var(--font-sans);
```

Rounded accent:

```css
font-family: var(--font-rounded);
```

Use rounded typography only for selected product/marketing display moments, package totals or intentionally Apple-like feature titles. Do not use it for body copy, forms, navigation or every card title.

### Scale

| Role | Size | Weight | Line height | Tracking |
|---|---:|---:|---:|---:|
| Display | `clamp(48px, 5.4vw, 72px)` | 700 | .96 | -.055em |
| H1 | `clamp(40px, 4.5vw, 56px)` | 700 | 1.00 | -.045em |
| H2 | `clamp(32px, 3vw, 40px)` | 700 | 1.06 | -.035em |
| H3 | `clamp(24px, 2vw, 28px)` | 700 | 1.12 | -.025em |
| Title | 18px | 600 | 1.28 | -.015em |
| Body | 16px | 400 | 1.55 | -.01em |
| Body secondary | 14px | 400 | 1.50 | -.005em |
| Caption | 12px | 500 | 1.40 | 0 |
| Label | 12px | 600 | 1.25 | .02em |
| Button | 14px | 600 | 1.00 | -.01em |

### Rules

- New UI must not use text below 12px.
- Inputs/selects use 16px text on mobile to avoid iOS Safari zoom.
- Long body text max width: `68ch`.
- Supporting copy near a headline should normally remain within `52ch`.
- Do not make a headline large simply because a page is empty.
- Avoid extreme negative tracking on long Cyrillic text.
- Use 400 / 500 / 600 / 700 as the normal weight vocabulary. Add another weight only with a demonstrated need.

Classes: `.ui-display`, `.ui-h1`, `.ui-h2`, `.ui-h3`, `.ui-title`, `.ui-body`, `.ui-body-secondary`, `.ui-caption`, `.ui-label`.

---

## 5. Spacing

Canonical scale:

| Token | Value |
|---|---:|
| `--space-1` | 4px |
| `--space-2` | 8px |
| `--space-3` | 12px |
| `--space-4` | 16px |
| `--space-5` | 20px |
| `--space-6` | 24px |
| `--space-8` | 32px |
| `--space-10` | 40px |
| `--space-12` | 48px |
| `--space-16` | 64px |
| `--space-20` | 80px |
| `--space-24` | 96px |
| `--space-32` | 128px |

### Rules

- New reusable components use this scale only.
- 1–3px values are permitted for borders, optical corrections and progress indicators, not general layout.
- Related label/value pairs normally use 4–8px.
- Component internal groups normally use 12–24px.
- Major page sections use `--section-space`, not arbitrary margins.

---

## 6. Radii

| Token | Value | Usage |
|---|---:|---|
| `--radius-sm` | 12px | compact controls / chips |
| `--radius-md` | 16px | buttons / inputs |
| `--radius-lg` | 24px | nested surfaces / media |
| `--radius-card` | 28px | major cards |
| `--radius-sheet` | 32px | sheets / large overlays |
| `--radius-pill` | 999px | statuses, segmented pills, explicit pill buttons |

Circle = `50%` only for genuinely circular controls/statuses.

Do not add 17px, 19px, 23px, 27px, 31px etc. to new components because one screen “looks slightly better” with it.

---

## 7. Shadows

| Token | Usage |
|---|---|
| `--shadow-subtle` | buttons / tiny elevated elements |
| `--shadow-card` | elevated cards |
| `--shadow-floating` | floating navigation / popovers |
| `--shadow-modal` | sheets / modal surfaces |

Rules:

- Default card should usually use a subtle border with no shadow.
- Use `--shadow-card` only when elevation helps hierarchy.
- Do not combine a strong outline, glow and strong shadow on the same element.
- No black “luxury” drop shadows.

---

## 8. Borders

Use:

- `--border-subtle` for static surface separation.
- `--border-default` for controls and normal boundaries.
- `--border-strong` for hover/selected structure.

A selected state may use accent border/focus ring, but the semantic selection must not depend on color alone.

---

## 9. Layout / Grid

Canonical container widths:

- Wide product content: `1220px` (`--layout-max`).
- Product/form flow: `860px` (`--layout-content`).
- Narrow forms/details: `760px` (`--layout-narrow`).
- Reading content: `680px` (`--layout-reading`).

Horizontal page padding:

- Mobile: 20px.
- Tablet ≥768px: 32px.
- Large desktop ≥1200px: 40px.

Section spacing:

- Mobile: 80px.
- Tablet: 96px.
- Large desktop: 128px.
- Compact product sections: 48px.

Default grid gap:

- Mobile: 20px.
- Tablet/desktop: 24px.

Core primitives:

```tsx
<PageContainer />
<Section />
<Stack />
<Grid />
```

Do not create page-specific `max-width` unless the content type genuinely introduces a new layout tier. If that happens repeatedly, add a named system tier rather than copying the number.

---

## 10. Buttons

Components: `Button`, `ButtonLink`, `IconButton` in `components/ui`.

### Variants

- **Primary** — one primary action for the current decision/section.
- **Secondary** — alternative action with lower emphasis.
- **Ghost** — tertiary/navigation action.
- **Destructive** — irreversible/danger action only.

### Sizes

| Size | Min height |
|---|---:|
| Small | 44px |
| Medium | 50px |
| Large | 56px |

Default radius: 16px.
Pill is an explicit `shape="pill"` option, not the default.

### States required

- default
- hover where pointer exists
- pressed
- focus-visible
- disabled
- loading

Rules:

- One section should not contain multiple equally strong Primary actions.
- Button text describes the result: “Продолжить к трансферу”, not “Далее” when context is ambiguous.
- Icon-only controls require a visible tooltip/title or accessible label and a ≥44px target.

---

## 11. Cards

Core `Card` controls only shared surface rules. Domain components still own their composition.

Card families:

### Content Card

Editorial/contextual content. Usually static. Border preferred over shadow.

### Product Card

Hotel, flight, transfer or package. May contain media and selection state. Selection is a domain behaviour.

### Booking / Summary Card

Transactional recap. Dense but structured. Price/action hierarchy is stronger than decoration.

### Interactive Card

The whole card is actionable/selectable. Implement it with a semantic `button` or `Link` around/within the domain component; do not make a generic `div` card clickable. It requires hover/pressed/focus/selected states.

### Feature Card

Use sparingly. Do not build generic three-card SaaS sections by default.

Shared rules:

- Base radius: 28px.
- Base padding: 24px.
- Nested surface radius: 16–24px depending hierarchy.
- Card grids use one consistent media height/aspect ratio.
- Avoid putting every text block in a card.
- Avoid card → card → pill → icon-well nesting unless each level conveys structure.

---

## 12. Forms

Components: `TextField`, `SelectField`, `FieldShell`.

Standard control:

- Default height: 50px.
- Radius: 16px.
- Input text: 16px.
- Label: 12px / 600.
- Helper/error: 12px.
- Background: secondary surface.
- Border: default border.

### Required states

- default
- hover
- focus-visible
- disabled
- invalid
- loading where relevant

Rules:

- Placeholder is not a label.
- Error text explains what to fix.
- Do not communicate invalid state using border color only.
- Group related inputs; separate unrelated tasks with spacing rather than decorative containers.
- Date pickers, segmented controls and switches may be domain components but must consume system tokens.

---

## 13. Navigation

### Current canonical app navigation

`AppShell` + `BottomNav` is the current shared product shell.

Bottom navigation destinations:

1. Главная
2. Собрать
3. Бронь
4. Поддержка

Rules:

- Active destination uses `aria-current="page"`.
- Navigation icons use `Symbol`.
- Never create a page-local bottom navigation.
- Sticky CTAs must account for nav height + safe-area inset.

### Header / footer policy

A canonical website header and footer do not yet exist in the current product. Do **not** invent different headers/footers per page. When these are designed, they must be implemented once as shared components and adopted product-wide.

Generator’s progress header is a flow-specific control, not a global site header.

---

## 14. Icons

Primary icon language: Cupertino/SF-style symbols through `components/design/Symbol.tsx`.

Standard visual sizes:

- 16px — compact inline icon.
- 20px — default control icon.
- 24px — emphasized action / card icon.
- 32px — rare feature/empty-state icon.

Rules:

- Do not mix emoji, random SVG libraries and Unicode pictograms with `Symbol`.
- Do not type raw glyph codepoints in feature components.
- If an icon is missing, extend `SymbolName` and its mapping centrally.
- Filled/outline treatment should be consistent for the same semantic action.
- Icon wells are optional and functional; never wrap every icon in a colored square by default.

The current web font is resolved externally. This is an infrastructure detail; feature code must remain isolated from it through `Symbol`.

---

## 15. Images

Preferred ratios:

- Hero/feature landscape: 16:9 desktop; deliberate 4:5 or 3:4 crop may be used on mobile.
- Product card / hotel: 4:3.
- Compact thumbnail: 1:1.
- Wide itinerary media: 3:2.

Rules:

- Use `object-fit: cover` for photography.
- Set `object-position` only when a specific focal point requires it.
- Items in the same grid use the same media ratio.
- Do not distort images to match a fixed box.
- Prefer real, high-resolution travel/product imagery to decorative generated backgrounds.
- Apply radius according to the parent card hierarchy, not a random media-only value.

---

## 16. Motion

Tokens:

- `--motion-fast`: 120ms — pressed/tap response.
- `--motion-normal`: 220ms — hover/state transition.
- `--motion-slow`: 360ms — larger layout/reveal transitions.
- `--ease-standard`
- `--ease-emphasized`

Preferred motion:

- subtle opacity change
- 1–2px translation
- 0.985–0.99 pressed scale
- smooth layout change
- sheet entrance
- content reveal when state changes

Avoid:

- looping decorative motion
- parallax without a product reason
- exaggerated spring/bounce
- animating every card on initial load

`prefers-reduced-motion: reduce` is implemented globally and must remain respected.

---

## 17. Responsive Rules

Canonical breakpoints for new/migrated UI:

- `480px` — compact phone adjustments.
- `768px` — tablet / two-column opportunities.
- `1024px` — desktop layout transition.
- `1280px` — large desktop refinement.

Legacy feature CSS currently contains additional breakpoints. Remove them gradually as each feature migrates; do not add more legacy breakpoints.

### Mobile principles

- Mobile is a composition, not a squeezed desktop layout.
- Primary content comes before supporting sidebars.
- Collapse multi-column grids when scanning becomes harder.
- Do not reduce important text below system minimums to make layout fit.
- Touch targets ≥44px.
- No horizontal page overflow.
- Horizontal product scrollers are allowed only when the interaction is intentional and visually clear.
- Sheets become bottom-aligned and account for safe-area inset.
- Sticky CTA must not conflict with BottomNav.

---

## 18. Accessibility

Required:

- Text/background contrast suitable for WCAG AA for normal content.
- Focus-visible state for keyboard users.
- Semantic headings in logical order.
- Real labels for form controls.
- `aria-label` for icon-only controls.
- `aria-current` for current navigation item.
- Error message associated with its field.
- Touch targets ≥44px.
- 16px form-control text on mobile.
- Motion reduced under `prefers-reduced-motion`.
- Do not rely on color alone for status/selection.

Global focus-visible and reduced-motion rules live in `app/design-system.css`.

---

## 19. Do / Don’t

### Do

- Use one clear H1 and one primary action.
- Let whitespace create hierarchy.
- Use neutral surfaces with category color only when useful.
- Reuse `Button`, `Card`, fields, layout primitives and `Symbol`.
- Keep product screenshots/itinerary content visually dominant.
- Use the spacing/radius scales even when a one-off value seems tempting.
- Test mobile separately, not after desktop is finished.

### Don’t

- Do not create random purple/blue gradient heroes.
- Do not use glass on every surface.
- Do not make every section a rounded card.
- Do not create generic three-feature SaaS grids by default.
- Do not add floating badges as decoration.
- Do not use emoji as interface icons.
- Do not create page-specific primary-button styling.
- Do not use 8–10px text for meaningful content.
- Do not introduce a new radius/shadow/color because one screen needs “something different”.
- Do not use `!important` as the normal way to migrate design.

---

## 20. Rules for Adding New Components

Before creating a component:

1. Search `components/ui` and existing domain components.
2. Decide whether the need is a **primitive** or a **domain component**.
3. If the same visual/interaction pattern exists twice, reuse or extract it.
4. Primitive styling must use design tokens only.
5. Domain components may define composition but should consume system spacing, typography, surfaces, radii, color and motion.
6. Add all required states before considering the component complete.
7. Define mobile behaviour at the same time as desktop behaviour.
8. Add accessibility semantics at implementation time, not after review.
9. If a new token is necessary, update this document and `design-system.css` in the same change.
10. Never solve a conflict by creating a third near-identical visual variant.

### Core component inventory

Available now:

- `Button`
- `ButtonLink`
- `IconButton`
- `Card`
- `Badge`
- `TextField`
- `SelectField`
- `FieldShell`
- `PageContainer`
- `Section`
- `Stack`
- `Grid`
- `PageHeader`
- `SheetOverlay`
- `SheetSurface`
- `Symbol` (existing icon layer)
- `AppShell` / `BottomNav` (existing navigation layer)

Do not create a second component with the same responsibility.

---

## 21. Interaction State Contract

Every interactive component must explicitly support the states that apply to it:

| State | Required behaviour |
|---|---|
| Default | obvious affordance without decoration overload |
| Hover | subtle only; pointer devices only |
| Pressed | immediate tactile response |
| Focus | visible keyboard focus ring |
| Selected | structural + semantic signal, not color alone |
| Disabled | reduced emphasis + interaction blocked |
| Loading | prevents duplicate action and communicates progress |
| Success | confirms completed action where needed |
| Error | explains failure and recovery path |

---

## 22. Migration Policy

The system is introduced progressively. Existing UI is not automatically approved simply because it predates this document.

Migration order:

1. Tokens.
2. Core components.
3. Shared shell/navigation.
4. Home.
5. Generator stages one at a time.
6. Booking.
7. Care.
8. Global header/footer once approved.
9. Edge states and cleanup.

When a screen migrates:

- preserve business logic and API contracts;
- replace old visual primitives with system components;
- remove obsolete CSS for that migrated pattern;
- do not preserve an old visual variant “just in case” unless another live screen still depends on it.

---

## 23. Visual QA Gate

A UI task is not complete when TypeScript builds. It is complete after visual QA.

Required viewports for significant screens:

- 390px phone
- 430px large phone
- 768px tablet
- 1024px small desktop
- 1440px desktop

Check:

- hierarchy
- alignment
- typography
- spacing rhythm
- radius consistency
- shadow/elevation consistency
- image crop
- CTA dominance
- interaction states
- keyboard focus
- touch targets
- overflow
- safe areas
- neighbouring-page consistency

If the screenshot looks more crowded, cheaper or less intentional than the product benchmark, identify the cause and revise before shipping.
