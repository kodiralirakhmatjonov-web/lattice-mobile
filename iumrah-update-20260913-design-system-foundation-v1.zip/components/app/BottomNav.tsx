"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Symbol, type SymbolName } from "@/components/design/Symbol";

const items: Array<{ href: string; label: string; icon: SymbolName; matches: (path: string) => boolean }> = [
  { href: "/", label: "Главная", icon: "sparkles", matches: (path) => path === "/" },
  { href: "/generator", label: "Собрать", icon: "airplane", matches: (path) => path.startsWith("/generator") },
  { href: "/booking", label: "Бронь", icon: "calendar", matches: (path) => path.startsWith("/booking") },
  { href: "/support", label: "Поддержка", icon: "message", matches: (path) => path.startsWith("/support") },
];

export function BottomNav() {
  const pathname = usePathname();
  return (
    <nav className="bottom-nav" aria-label="Основная навигация">
      <div className="bottom-nav-inner">
        {items.map((item) => {
          const active = item.matches(pathname);
          return (
            <Link key={item.href} href={item.href} className={active ? "bottom-nav-item is-active" : "bottom-nav-item"} aria-current={active ? "page" : undefined}>
              <span className="bottom-nav-icon"><Symbol name={item.icon} size={20} /></span>
              <span>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
