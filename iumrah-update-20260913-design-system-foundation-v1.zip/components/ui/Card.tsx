import type { HTMLAttributes, ReactNode } from "react";

export type CardSurface = "default" | "subtle" | "elevated";

export type CardProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  surface?: CardSurface;
};

export function Card({
  children,
  surface = "default",
  className,
  ...props
}: CardProps) {
  return (
    <div
      {...props}
      className={className ? `ui-card ${className}` : "ui-card"}
      data-surface={surface}
    >
      {children}
    </div>
  );
}
