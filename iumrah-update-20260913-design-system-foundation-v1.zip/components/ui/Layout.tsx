import type { CSSProperties, HTMLAttributes, ReactNode } from "react";

export type ContainerSize = "wide" | "content" | "narrow" | "reading";
export type SpaceToken = 1 | 2 | 3 | 4 | 5 | 6 | 8 | 10 | 12 | 16 | 20 | 24 | 32;

type ContainerProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  size?: ContainerSize;
};

export function PageContainer({ children, size = "wide", className, ...props }: ContainerProps) {
  return (
    <div
      {...props}
      className={className ? `ui-container ${className}` : "ui-container"}
      data-size={size === "wide" ? undefined : size}
    >
      {children}
    </div>
  );
}

type SectionProps = HTMLAttributes<HTMLElement> & {
  children: ReactNode;
  spacing?: "default" | "compact";
};

export function Section({ children, spacing = "default", className, ...props }: SectionProps) {
  return (
    <section
      {...props}
      className={className ? `ui-section ${className}` : "ui-section"}
      data-spacing={spacing === "default" ? undefined : spacing}
    >
      {children}
    </section>
  );
}

type StackProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  gap?: SpaceToken;
};

export function Stack({ children, gap = 4, className, style, ...props }: StackProps) {
  const stackStyle = {
    ...style,
    "--ui-stack-gap": `var(--space-${gap})`,
  } as CSSProperties;
  return <div {...props} className={className ? `ui-stack ${className}` : "ui-stack"} style={stackStyle}>{children}</div>;
}

type GridProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  columns?: 1 | 2 | 3 | 4;
  gap?: SpaceToken;
};

export function Grid({ children, columns = 1, gap = 5, className, style, ...props }: GridProps) {
  const gridStyle = {
    ...style,
    "--ui-grid-gap": `var(--space-${gap})`,
  } as CSSProperties;
  return <div {...props} className={className ? `ui-grid ${className}` : "ui-grid"} data-columns={columns} style={gridStyle}>{children}</div>;
}
