import type { ButtonHTMLAttributes } from "react";
import { Symbol, type SymbolName } from "@/components/design/Symbol";

export type IconButtonSize = "sm" | "md" | "lg";
export type IconButtonVariant = "secondary" | "primary" | "ghost";

export type IconButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children" | "aria-label"> & {
  label: string;
  icon: SymbolName;
  size?: IconButtonSize;
  variant?: IconButtonVariant;
  iconSize?: 16 | 20 | 24 | 32;
};

export function IconButton({
  label,
  icon,
  size = "sm",
  variant = "secondary",
  iconSize = 20,
  className,
  type = "button",
  ...props
}: IconButtonProps) {
  return (
    <button
      {...props}
      type={type}
      aria-label={label}
      title={label}
      className={className ? `ui-icon-button ${className}` : "ui-icon-button"}
      data-size={size}
      data-variant={variant}
    >
      <Symbol name={icon} size={iconSize} />
    </button>
  );
}
