import type { InputHTMLAttributes, ReactNode, SelectHTMLAttributes } from "react";

export type FieldShellProps = {
  id: string;
  label: string;
  helper?: ReactNode;
  error?: ReactNode;
  children: ReactNode;
  className?: string;
};

export function FieldShell({ id, label, helper, error, children, className }: FieldShellProps) {
  const messageId = helper || error ? `${id}-message` : undefined;
  return (
    <label
      htmlFor={id}
      className={className ? `ui-field ${className}` : "ui-field"}
      data-invalid={error ? "true" : undefined}
    >
      <span className="ui-field-label">{label}</span>
      {children}
      {messageId ? (
        <span className="ui-field-message" id={messageId} role={error ? "alert" : undefined}>
          {error || helper}
        </span>
      ) : null}
    </label>
  );
}

type TextFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, "id"> & {
  id: string;
  label: string;
  helper?: ReactNode;
  error?: ReactNode;
  fieldClassName?: string;
};

export function TextField({ id, label, helper, error, fieldClassName, className, ...props }: TextFieldProps) {
  const messageId = helper || error ? `${id}-message` : undefined;
  return (
    <FieldShell id={id} label={label} helper={helper} error={error} className={fieldClassName}>
      <input
        {...props}
        id={id}
        className={className ? `ui-input ${className}` : "ui-input"}
        aria-invalid={error ? true : undefined}
        aria-describedby={messageId}
      />
    </FieldShell>
  );
}

type SelectFieldProps = Omit<SelectHTMLAttributes<HTMLSelectElement>, "id"> & {
  id: string;
  label: string;
  helper?: ReactNode;
  error?: ReactNode;
  fieldClassName?: string;
};

export function SelectField({ id, label, helper, error, fieldClassName, className, children, ...props }: SelectFieldProps) {
  const messageId = helper || error ? `${id}-message` : undefined;
  return (
    <FieldShell id={id} label={label} helper={helper} error={error} className={fieldClassName}>
      <select
        {...props}
        id={id}
        className={className ? `ui-select ${className}` : "ui-select"}
        aria-invalid={error ? true : undefined}
        aria-describedby={messageId}
      >
        {children}
      </select>
    </FieldShell>
  );
}
