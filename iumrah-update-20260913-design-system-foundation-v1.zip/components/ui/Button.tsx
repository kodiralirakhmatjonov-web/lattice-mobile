import Link from "next/link";
import type { ButtonHTMLAttributes, ReactNode } from "react";

export type ButtonVariant = "primary" | "secondary" | "ghost" | "destructive";
export type ButtonSize = "sm" | "md" | "lg";
export type ButtonShape = "rounded" | "pill";

type SharedProps = {
  children: ReactNode;
  variant?: ButtonVariant;
  size?: ButtonSize;
  shape?: ButtonShape;
  leading?: ReactNode;
  trailing?: ReactNode;
  className?: string;
};

export type ButtonProps = SharedProps &
  Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> & {
    loading?: boolean;
  };

function classes(className?: string) {
  return className ? `ui-button ${className}` : "ui-button";
}

export function Button({
  children,
  variant = "primary",
  size = "md",
  shape = "rounded",
  leading,
  trailing,
  loading = false,
  disabled,
  className,
  type = "button",
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={classes(className)}
      data-variant={variant}
      data-size={size}
      data-shape={shape}
    >
      {loading ? <span className="ui-button-spinner" aria-hidden="true" /> : leading}
      <span>{children}</span>
      {!loading && trailing}
    </button>
  );
}

export type ButtonLinkProps = SharedProps & {
  href: string;
  prefetch?: boolean;
  ariaLabel?: string;
};

export function ButtonLink({
  children,
  href,
  variant = "primary",
  size = "md",
  shape = "rounded",
  leading,
  trailing,
  className,
  prefetch,
  ariaLabel,
}: ButtonLinkProps) {
  return (
    <Link
      href={href}
      prefetch={prefetch}
      aria-label={ariaLabel}
      className={classes(className)}
      data-variant={variant}
      data-size={size}
      data-shape={shape}
    >
      {leading}
      <span>{children}</span>
      {trailing}
    </Link>
  );
}
