import type { HTMLAttributes, ReactNode } from "react";

export type PageHeaderProps = HTMLAttributes<HTMLElement> & {
  kicker?: ReactNode;
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  align?: "left" | "center";
  level?: "display" | "h1";
};

export function PageHeader({
  kicker,
  title,
  description,
  actions,
  align = "left",
  level = "h1",
  className,
  ...props
}: PageHeaderProps) {
  return (
    <header
      {...props}
      className={className ? `ui-page-header ${className}` : "ui-page-header"}
      data-align={align}
    >
      {kicker ? <span className="ui-page-header-kicker">{kicker}</span> : null}
      <h1 className={level === "display" ? "ui-display" : "ui-h1"}>{title}</h1>
      {description ? <p className="ui-page-header-copy">{description}</p> : null}
      {actions}
    </header>
  );
}
