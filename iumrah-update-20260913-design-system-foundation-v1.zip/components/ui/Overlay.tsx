import type { HTMLAttributes, ReactNode } from "react";

/**
 * Presentational sheet primitives only.
 * The caller owns open/close state, focus restoration and any domain behaviour.
 */
export function SheetOverlay({ children, className, ...props }: HTMLAttributes<HTMLDivElement> & { children: ReactNode }) {
  return (
    <div
      {...props}
      role="presentation"
      className={className ? `ui-overlay ${className}` : "ui-overlay"}
    >
      {children}
    </div>
  );
}

export function SheetSurface({
  children,
  labelledBy,
  className,
  ...props
}: HTMLAttributes<HTMLDivElement> & { children: ReactNode; labelledBy: string }) {
  return (
    <div
      {...props}
      role="dialog"
      aria-modal="true"
      aria-labelledby={labelledBy}
      className={className ? `ui-sheet ${className}` : "ui-sheet"}
    >
      <span className="ui-sheet-handle" aria-hidden="true" />
      {children}
    </div>
  );
}
