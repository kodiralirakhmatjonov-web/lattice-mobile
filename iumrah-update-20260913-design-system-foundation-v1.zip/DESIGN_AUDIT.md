# Iumrah Frontend UI/UX Audit

Status: foundation audit completed before further redesign work.

This audit is intentionally system-level. It does not propose a new Home page or a page-by-page visual redesign. Its purpose is to identify why the current product drifts visually and to define what must become shared infrastructure before new UI is added.

## 1. Product surfaces reviewed

The current public frontend is a small Next.js product with several deep states rather than many independent routes. The following surfaces were reviewed together:

1. `/` — public Home / entry point.
2. `/generator` — origin and traveller setup.
3. `/generator` — direct-flight selection state.
4. `/generator` — hotel selection and hotel detail/choice sheets.
5. `/generator` — transfer and Haramain selection.
6. `/generator` — final package comparison / ready state.
7. `/booking` — empty, review, profile sheet and booking success states.
8. `/support` — empty Care state, conversation state and composer.
9. Shared `BottomNav` / `AppShell`.
10. `not-found` edge state.

Legacy redirects `/plan`, `/journey` and `/care` were also checked for routing consistency.

## 2. Current frontend architecture

### Styling

- Global CSS: `app/globals.css`.
- Generator-specific CSS Module: `components/generator/FixedDatesGenerator.module.css`.
- Tailwind is installed but is not the active styling architecture.
- No canonical theme/tokens file existed before this audit.
- A small set of root variables existed, but most visual values were hardcoded in feature CSS.

### Shared product components

- `components/app/AppShell.tsx`
- `components/app/BottomNav.tsx`
- `components/design/Symbol.tsx`
- `components/design/SiteShell.tsx` — currently only an alias.

### Large feature components

- `FixedDatesGenerator.tsx`: ~895 lines.
- `BookingClient.tsx`: ~336 lines.
- `SupportClient.tsx`: ~134 lines.

The generator has good feature isolation, but visual primitives and domain UI are tightly coupled inside one component and one large module stylesheet.

## 3. Quantitative CSS drift

The two principal stylesheets contain roughly 939 qualified CSS rules. A static audit found:

- 44 distinct `font-size` values.
- 14 distinct `font-weight` values.
- 23 distinct `gap` values.
- 89 distinct `padding` values.
- 63 distinct `margin` values.
- 39 distinct `border-radius` values.
- 62 distinct `box-shadow` values.
- 412 distinct raw color/rgba expressions (661 literal uses) in source.
- 31 `!important` declarations remain in legacy CSS.
- 7 inline `style={{...}}` uses exist in TSX, concentrated in the old 404 and a small part of Generator; the 404 is migrated in this foundation change.

The problem is not that every value is individually wrong. The problem is that there is no controlled vocabulary, so almost every component is free to invent a slightly different solution.

## 4. What should be preserved

The current product already has several useful foundations and they should not be discarded:

- System-first typography (`-apple-system` / SF on Apple devices).
- A central `Symbol` wrapper for Cupertino-style iconography.
- A mostly neutral white / near-white visual palette.
- Functional category accents for flights, hotels, transfer and Care.
- App-like bottom navigation with four clear destinations.
- Generator feature isolation through a CSS Module.
- Strong business flow separation: generator → booking → Care.
- Server-authoritative pricing and booking logic are visually independent and must remain untouched.
- Existing product photography can remain, subject to a future image-treatment pass.

## 5. System-level findings

### P0 — design system does not yet exist

The previous `:root` variables covered only a small subset of the UI. Typography, spacing, radius, shadow, layout, controls and motion did not have canonical scales. As a result, feature CSS became the real source of truth.

**Action:** introduce one semantic token layer and require all new/migrated UI to use it.

### P0 — two separate visual universes exist

The general site uses global CSS while the generator has its own extensive styling vocabulary. The generator independently defines cards, headings, sheets, controls, shadows, badges, pills, input states and breakpoints.

**Action:** retain feature-specific composition, but move primitives and visual constants to the shared system.

### P0 — shared component layer is too thin

`AppShell`, `BottomNav` and `Symbol` are the only meaningful visual primitives. Buttons, fields, cards, badges, containers, sections and page headers are implemented repeatedly with class combinations.

**Action:** add a small core UI layer. Do not create a large generic component library; only standardize patterns that already recur.

### P0 — navigation shell is incomplete

The product has a shared bottom navigation, but Home also creates its own brand header while Generator creates a separate sticky flow header. Booking and Support have different top-of-page structures. There is no canonical website footer.

**Action:** preserve BottomNav as the current app navigation. Do not invent a new global header/footer during this foundation pass. Any future site header/footer must be built once as system components and then reused everywhere.

## 6. Typography findings

### Problems

- Headline scales vary significantly between Home, Generator, Booking and Support.
- Many components use 8–10px text. This is too small for important information and creates a visually compressed, prototype-like feel.
- Weight values include 650, 680, 720, 750, 760, 780, 800, 850 and 900. System fonts may synthesize several of these rather than render intentionally different cuts.
- Letter spacing ranges from strong negative display tracking to aggressive uppercase spacing without a shared rule.
- Rounded typography is used in feature-specific places without a documented semantic role.

### Direction

Use one fixed text hierarchy. Default text is system sans. Rounded typography is an accent reserved for selected product moments, not a second global type system.

New UI must not use text below 12px. Form controls on mobile use at least 16px to prevent iOS Safari focus zoom.

## 7. Spacing and layout findings

### Problems

- Global layout widths include 1220, 920, 860, 820, 780, 760, 700, 650, 600, 590, 560, 520 and other one-off values.
- Feature gaps and padding use many values with no shared scale.
- Breakpoints are fragmented: 390, 430, 520, 680, 700, 760, 820, 900 and 980px all appear.
- Some pages use broad desktop layouts while others behave like narrow mobile app screens at all widths.

### Direction

Use explicit layout tiers rather than arbitrary max-widths:

- wide product container
- content container
- narrow/form container
- reading measure

Use four canonical responsive breakpoints for new/migrated UI: 480, 768, 1024 and 1280px.

## 8. Radius and surface findings

### Problems

The UI uses many related radii: 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 30, 31, 32, 34, 38, 40, 42 and pill/circle values.

This produces visual drift even when each individual card looks acceptable.

Several sections are also over-cardified: a large card contains smaller rounded cards which contain rounded icon wells and pills. This weakens hierarchy.

### Direction

Five primary radii only: small, medium, large, card, sheet plus pill/circle. Cards should only be used when grouping or interaction needs a boundary.

## 9. Shadow and elevation findings

### Problems

More than 60 distinct shadow values appear. Similar surfaces therefore feel slightly different in depth. Some selected cards combine outline, glow and drop shadow at the same time.

### Direction

Four elevation levels only: subtle, card, floating, modal. Most static cards should have either a subtle border or card shadow, not both at maximum strength.

## 10. Button findings

### Problems

- Primary actions exist under many unrelated class names.
- Radius varies between 17px and full pill.
- Height varies by screen.
- Hover, pressed, disabled and loading feedback are not implemented consistently.
- Several later rules rely on `!important` to force booking buttons into a new shape.

### Direction

Four semantic variants only: Primary, Secondary, Ghost, Destructive.
Three sizes: 44, 50 and 56px minimum height.
Pill is a shape option, not a new button variant.

## 11. Card findings

### Problems

Cards are organized by visual styling rather than semantic role. Home feature cards, booking cards, support cards, generator cards, comparison cards and notice cards all invent their own padding/radius/elevation.

### Direction

Shared `Card` provides only surface, border, elevation and base padding. Domain components own composition. This prevents a generic SaaS-card system while still keeping family resemblance.

## 12. Forms findings

### Problems

- Booking form, generator search, chat composer and profile sheet inputs use different heights, radii, backgrounds and focus treatments.
- Some form typography is 11–13px.
- Error messages are visually implemented in feature code rather than through a shared pattern.
- Placeholder and helper semantics are inconsistent.

### Direction

One 50px default control height, 16px input text, visible label, helper/error message, common focus ring and disabled state. Feature-specific controls such as segmented controls and switches may remain domain components but must consume the same tokens.

## 13. Overlay / sheet findings

Generator hotel sheets and Booking profile sheets solve the same surface problem independently. They use similar but different blur, radius, padding, handle dimensions and animation timing.

**Action:** define shared overlay/sheet surface tokens now. Behaviour and domain content remain inside each feature until migration.

## 14. Icon findings

### Strength

`Symbol.tsx` already creates a central icon-language boundary. This is the correct architectural idea.

### Problems

- Sizes are frequently one-off values such as 15, 18, 19, 22, 25 and 30.
- A few text glyphs remain in product UI (`✈`, arrows, check marks, luggage glyphs).
- Icon wells vary in dimensions and radius.

### Direction

New UI uses `Symbol` only, normally at 16 / 20 / 24 / 32px. If a symbol is missing, extend `SymbolName` centrally instead of inserting emoji or raw Unicode pictograms.

## 15. Image findings

### Problems

- Hero, hotel and thumbnail crops are controlled locally.
- Heights are often fixed rather than aspect-ratio based.
- There is no documented mobile crop rule.

### Direction

Use a small set of aspect ratios, `object-fit: cover`, explicit focal position when necessary and consistent media radius per card family.

## 16. Responsive findings

### Problems

- Breakpoints are page-owned rather than system-owned.
- Mobile sometimes receives a compressed desktop component instead of a recomposed layout.
- Sticky CTA, bottom navigation and sheets each calculate safe areas independently.
- Some UI text becomes extremely small to fit mobile density.

### Direction

New components must define mobile behaviour first, then tablet/desktop expansion. Do not solve mobile by reducing font size below the system minimum.

## 17. Interaction and accessibility findings

### Problems

- Focus-visible treatment was not global.
- Reduced-motion behaviour was not defined.
- Some icon-only controls are visually 31–38px, below the recommended 44px touch target.
- Several important labels/descriptions use 8–10px text.
- Interactive states vary between hover-only, active-only and no feedback.
- `aria-current` was missing from the shared bottom navigation.

### Foundation changes in this update

- Global focus-visible treatment is now defined.
- Reduced-motion behaviour is defined.
- New icon-button primitive has a minimum 44px target.
- New field primitive uses 16px control text.
- Bottom navigation now exposes `aria-current="page"`.

## 18. Code-structure findings

### Generator

`FixedDatesGenerator.tsx` is doing state orchestration and rendering every major stage in one file. This is not a business-logic bug, but it makes visual migration risky because every stage shares one large component and a 300+ rule module stylesheet.

**Migration:** split by stage only when that stage is being migrated. Do not rewrite the generator wholesale.

### Booking

The Booking UI contains an older base layer and later “native” overrides, including `!important`. This is evidence of styling accretion.

**Migration:** move one state at a time onto shared primitives, then delete the corresponding obsolete rules.

### Global CSS

`globals.css` contains both legacy and current classes. Some older Home / booking patterns remain even when newer `native-*` patterns override them.

**Migration:** delete stale rules only after proving they are unused. Do not perform broad cleanup and visual migration in the same change.

## 19. Foundation decisions

The product visual language is defined as:

- **Calm** — hierarchy through spacing and typography, not decoration.
- **Precise** — limited scales and predictable geometry.
- **Human** — supportive language and approachable product imagery.
- **Premium** — restraint, proportion and polish rather than gold/glass/gradient effects.
- **Product-first** — UI and travel content are the visual subject; generic marketing decoration is secondary.
- **Confident** — one clear action and one clear hierarchy at a time.

## 20. Migration priority

Do not redesign all screens at once.

1. Tokens and accessibility foundation — completed in this pass.
2. Core reusable components — completed in this pass for new/migrated UI.
3. Shared navigation/shell polish — next controlled migration.
4. Home — migrate after its visual direction is explicitly approved.
5. Generator stage by stage: origin → flights → hotels → transfer → ready.
6. Booking states.
7. Care/chat.
8. Shared site header/footer when their product role is approved.
9. Edge/loading/error/empty states.
10. Delete legacy CSS only as each migrated surface stops depending on it.

The rule for every migration is: **replace a visual pattern; do not add a parallel third version.**
