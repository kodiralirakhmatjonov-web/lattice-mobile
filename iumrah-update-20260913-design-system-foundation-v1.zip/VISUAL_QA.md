# Iumrah Visual QA Checklist

Use this checklist after every meaningful UI change. Do not approve a screen from source code alone.

## Viewports

Render/check at minimum:

- 390px — standard phone
- 430px — large phone
- 768px — tablet
- 1024px — small desktop
- 1440px — desktop

## 1. Product consistency

- Does the screen use the same typography scale as neighbouring screens?
- Are control heights and radii from the system?
- Are cards from the same visual family?
- Is the same semantic action represented the same way elsewhere?
- Did this change create a new visual variant that should not exist?

## 2. Hierarchy

- Can a user identify the page purpose in under two seconds?
- Is there one obvious primary action?
- Is secondary information visually secondary?
- Are labels, values and supporting text clearly distinguishable?
- Is any decorative element competing with the task?

## 3. Spacing / composition

- Are related elements closer than unrelated sections?
- Does the page follow the spacing scale?
- Are left/right edges aligned to a consistent grid?
- Are there accidental large empty zones or crowded groups?
- Is whitespace doing useful hierarchy work rather than merely making the page tall?

## 4. Type

- No meaningful text below 12px.
- Form controls are 16px on mobile.
- Headlines do not wrap awkwardly at 390/430px.
- Line length is comfortable.
- Weight/tracking does not create fake “premium” styling.

## 5. Cards / surfaces

- Is a card actually necessary?
- Are nested cards justified?
- Is radius consistent with hierarchy?
- Is elevation consistent with surface role?
- Are image ratios/crops aligned in a grid?

## 6. Interaction

- Hover exists where appropriate on pointer devices.
- Pressed state gives immediate feedback.
- Focus-visible is obvious.
- Disabled state is unambiguous.
- Loading prevents repeated action.
- Selected state is not communicated by color alone.
- Error state explains recovery.

## 7. Mobile

- No horizontal page overflow.
- No desktop grid simply squeezed into phone width.
- Touch targets are at least 44px.
- Sticky CTA does not conflict with BottomNav.
- Safe-area inset is respected.
- Sheets remain reachable and scroll correctly.
- Keyboard/focus does not hide the active input/CTA.

## 8. Accessibility

- Semantic heading order is valid.
- Form labels are real labels.
- Icon-only buttons have accessible names.
- Active navigation exposes current state.
- Contrast is sufficient.
- Reduced-motion preference is respected.

## 9. Final comparison

Place the result mentally or literally next to a high-quality consumer product reference such as Tripsy, Tangem or Apple.

Ask:

1. Is Iumrah more visually noisy?
2. Are its proportions less controlled?
3. Does it have more arbitrary cards/pills/effects?
4. Is the product itself less visible than the decoration?
5. Does any area look like a generic AI-generated layout?

If yes, the task is not finished.
