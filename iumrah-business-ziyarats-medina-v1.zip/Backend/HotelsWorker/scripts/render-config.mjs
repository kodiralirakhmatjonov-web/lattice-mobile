import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const [hotelDatabaseID, zoneID] = process.argv.slice(2);
const accountID = process.env.CLOUDFLARE_ACCOUNT_ID;
const apiToken = process.env.CLOUDFLARE_API_TOKEN;

if (!hotelDatabaseID || !zoneID || !accountID || !apiToken) {
  console.error('Usage: node scripts/render-config.mjs <HOTEL_D1_DATABASE_ID> <ZONE_ID> with CLOUDFLARE_ACCOUNT_ID and CLOUDFLARE_API_TOKEN');
  process.exit(1);
}

const headers = {
  Authorization: `Bearer ${apiToken}`,
  'Content-Type': 'application/json',
};

async function d1Query(databaseID, sql, params = []) {
  const response = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountID}/d1/database/${databaseID}/query`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({ sql, params }),
    },
  );
  if (!response.ok) throw new Error(`D1 query failed for ${databaseID} (${response.status})`);
  const payload = await response.json();
  if (payload?.success === false) throw new Error(`D1 query rejected for ${databaseID}`);
  return payload?.result?.[0]?.results ?? [];
}

async function operationalBookingIDs() {
  try {
    const rows = await d1Query(
      hotelDatabaseID,
      `SELECT booking_id
       FROM pilgrim_trips
       WHERE booking_id IS NOT NULL AND booking_id <> ''
       ORDER BY COALESCE(updated_at, created_at) DESC
       LIMIT 25`,
    );
    return [...new Set(rows.map(row => String(row?.booking_id || '').trim()).filter(Boolean))];
  } catch (error) {
    console.warn(`Could not read operational booking IDs from HOTELS_DB: ${error?.message || error}`);
    return [];
  }
}

async function validateBookingDatabase(databaseID) {
  try {
    const rows = await d1Query(
      databaseID,
      `SELECT
         (SELECT COUNT(*) FROM bookings) AS booking_count,
         (SELECT MAX(COALESCE(updated_at, created_at, '')) FROM bookings) AS newest_booking,
         (SELECT COUNT(*) FROM pragma_table_info('bookings') WHERE name IN ('id','access_token_hash','payload_json','status')) AS required_columns`,
    );
    const row = rows[0];
    if (!row || Number(row.required_columns ?? 0) !== 4) return null;
    return {
      bookingCount: Number(row.booking_count ?? 0),
      newestBooking: String(row.newest_booking ?? ''),
    };
  } catch {
    return null;
  }
}

async function deployedBookingsBinding(databases) {
  // Reuse the binding that is already serving production before attempting any
  // discovery. This is safer than inferring the source database from stale
  // operational rows in iumrah-hotels.
  for (const scriptName of ['iumrah-hotels-api', 'iumrah-package-api']) {
    try {
      const response = await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${accountID}/workers/scripts/${scriptName}/settings`,
        { headers },
      );
      if (!response.ok) continue;
      const payload = await response.json();
      const bindings = Array.isArray(payload?.result?.bindings) ? payload.result.bindings : [];
      const binding = bindings.find(item =>
        String(item?.name || '') === 'BOOKINGS_DB' && String(item?.type || '').toLowerCase() === 'd1'
      );
      const id = String(binding?.database_id ?? binding?.id ?? '').trim();
      if (!id || id === String(hotelDatabaseID)) continue;

      const validation = await validateBookingDatabase(id);
      if (!validation) continue;
      const listed = databases.find(item => String(item?.uuid ?? item?.id ?? '') === id);
      const name = String(listed?.name ?? 'iumrah-bookings');
      console.log(`Using current production BOOKINGS_DB binding from ${scriptName}: ${name} (${id})`);
      return { id, name, ...validation, overlapCount: 0, source: `worker:${scriptName}` };
    } catch (error) {
      console.warn(`Could not read ${scriptName} bindings: ${error?.message || error}`);
    }
  }
  return null;
}

async function findBookingDatabase() {
  const listResponse = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountID}/d1/database?per_page=100`,
    { headers },
  );
  if (!listResponse.ok) throw new Error(`Unable to list D1 databases (${listResponse.status})`);
  const listPayload = await listResponse.json();
  const databases = Array.isArray(listPayload.result) ? listPayload.result : [];

  const deployed = await deployedBookingsBinding(databases);
  if (deployed) return deployed;

  const knownBookingIDs = await operationalBookingIDs();
  const candidates = [];

  for (const database of databases) {
    const id = database.uuid ?? database.id;
    if (!id || String(id) === String(hotelDatabaseID)) continue;
    const validation = await validateBookingDatabase(id);
    if (!validation) continue;

    let overlapCount = 0;
    if (knownBookingIDs.length) {
      try {
        const placeholders = knownBookingIDs.map(() => '?').join(',');
        const overlapRows = await d1Query(
          id,
          `SELECT COUNT(*) AS overlap_count FROM bookings WHERE id IN (${placeholders})`,
          knownBookingIDs,
        );
        overlapCount = Number(overlapRows?.[0]?.overlap_count ?? 0);
      } catch {
        overlapCount = 0;
      }
    }

    candidates.push({
      id: String(id),
      name: String(database.name ?? 'iumrah-bookings'),
      bookingCount: validation.bookingCount,
      newestBooking: validation.newestBooking,
      overlapCount,
      source: 'discovery',
    });
  }

  if (!candidates.length) {
    throw new Error('No existing D1 database with the production bookings schema (id/access_token_hash/payload_json/status) was found.');
  }

  candidates.sort((a, b) => {
    if (knownBookingIDs.length && b.overlapCount !== a.overlapCount) return b.overlapCount - a.overlapCount;
    const byNewest = b.newestBooking.localeCompare(a.newestBooking);
    if (byNewest !== 0) return byNewest;
    return b.bookingCount - a.bookingCount;
  });

  const selected = candidates[0];
  if (knownBookingIDs.length && selected.overlapCount === 0) {
    // The operational mirror may contain old/deleted IDs and must not block a
    // legitimate deploy. Fall back to the same deterministic newest-booking
    // selection used by PackageEngine, while still requiring the full schema.
    console.warn(
      `No bookings D1 overlaps the ${knownBookingIDs.length} operational IDs. ` +
      `Falling back to the newest schema-compatible bookings database: ${selected.name} (${selected.id}).`,
    );
  }

  console.log(`Operational booking IDs used for D1 verification: ${knownBookingIDs.length}`);
  console.log('Bookings D1 candidates:', candidates.map(item => `${item.name}:overlap=${item.overlapCount}:count=${item.bookingCount}:newest=${item.newestBooking}`).join(', '));
  console.log(`Using bookings D1: ${selected.name} (${selected.id})`);
  return selected;
}

async function normalizeBookingStatuses(databaseID) {
  const mappings = [
    ['NEW', 'AVAILABILITY_CHECK'],
    ['PAID', 'BOOKING_CONFIRMED'],
    ['DOCUMENTS_READY', 'READY_TO_TRAVEL'],
  ];

  const before = await d1Query(
    databaseID,
    `SELECT UPPER(COALESCE(status,'')) AS status, COUNT(*) AS count FROM bookings GROUP BY UPPER(COALESCE(status,'')) ORDER BY status`,
  );

  for (const [legacy, canonical] of mappings) {
    await d1Query(
      databaseID,
      `UPDATE bookings SET status=? WHERE UPPER(COALESCE(status,''))=?`,
      [canonical, legacy],
    );

    // Keep the immutable booking payload readable by older consumers while making
    // its embedded status agree with the canonical database status when present.
    try {
      await d1Query(
        databaseID,
        `UPDATE bookings
         SET payload_json=json_set(payload_json,'$.status',?)
         WHERE json_valid(payload_json)=1
           AND UPPER(COALESCE(json_extract(payload_json,'$.status'),''))=?`,
        [canonical, legacy],
      );
    } catch (error) {
      console.warn(`Could not normalize embedded payload status ${legacy}: ${error?.message || error}`);
    }
  }

  const after = await d1Query(
    databaseID,
    `SELECT UPPER(COALESCE(status,'')) AS status, COUNT(*) AS count FROM bookings GROUP BY UPPER(COALESCE(status,'')) ORDER BY status`,
  );
  const forbidden = new Set(['NEW', 'PAID', 'DOCUMENTS_READY']);
  const remaining = after.filter(row => forbidden.has(String(row?.status || '').toUpperCase()) && Number(row?.count || 0) > 0);
  if (remaining.length) {
    throw new Error(`Legacy booking statuses remain after normalization: ${JSON.stringify(remaining)}`);
  }
  console.log('Bookings status normalization:', { before, after });
}

const bookingDatabase = await findBookingDatabase();
await normalizeBookingStatuses(bookingDatabase.id);
const template = fs.readFileSync(new URL('../wrangler.template.jsonc', import.meta.url), 'utf8');
const rendered = template
  .replaceAll('__D1_DATABASE_ID__', hotelDatabaseID)
  .replaceAll('__BOOKING_D1_DATABASE_ID__', bookingDatabase.id)
  .replaceAll('__BOOKING_D1_DATABASE_NAME__', bookingDatabase.name.replaceAll('"', '\\"'))
  .replaceAll('__ZONE_ID__', zoneID);

JSON.parse(rendered);
const generatedConfigURL = new URL('../wrangler.generated.jsonc', import.meta.url);
fs.writeFileSync(generatedConfigURL, rendered);
console.log('Generated wrangler.generated.jsonc with HOTELS_DB + verified BOOKINGS_DB bindings');

async function seedZiyaratMedia() {
  // The repository ZIP updater intentionally protects .github/workflows. Keep the
  // initial bundled Ziyarats media bootstrap here so a normal root-level
  // iumrah-business-*.zip patch is sufficient: the existing deployment workflow
  // already runs this renderer after the R2 bucket has been resolved/created.
  if (!process.env.CI || !process.env.CLOUDFLARE_API_TOKEN || !process.env.CLOUDFLARE_ACCOUNT_ID) {
    console.log('Skipping Ziyarats R2 seed outside authenticated CI.');
    return;
  }

  const workerRoot = path.dirname(fileURLToPath(new URL('../package.json', import.meta.url)));
  const seedRoot = path.join(workerRoot, 'seed', 'ziyarats', 'quba-mosque');
  if (!fs.existsSync(seedRoot)) {
    console.log('No bundled Ziyarats seed media found.');
    return;
  }

  const allSeedNames = fs.readdirSync(seedRoot)
    .filter(name => /^quba-[1-5]\.jpg$/i.test(name))
    .sort();
  let namesToSeed = allSeedNames;

  // Before migration 0029 is applied the table does not exist, which is the
  // first-install signal. On later deploys, upload only seed objects that are
  // still referenced in D1; this avoids resurrecting media an admin deleted.
  try {
    const referenced = await d1Query(
      hotelDatabaseID,
      `SELECT object_key FROM ziyarat_images
       WHERE place_id='quba-mosque' AND object_key LIKE 'ziyarats/quba-mosque/quba-%.jpg'
       ORDER BY position ASC`,
    );
    const wanted = new Set(referenced.map(row => path.basename(String(row?.object_key || ''))).filter(Boolean));
    namesToSeed = allSeedNames.filter(name => wanted.has(name));
    if (!namesToSeed.length) {
      console.log('Quba seed rows are not present in D1; preserving the current admin-managed gallery.');
      return;
    }
  } catch {
    console.log('Ziyarats schema not present yet; seeding first-install Quba media.');
  }

  const bucket = String(process.env.R2_NAME || 'iumrah-hotels-media').trim();
  const configPath = fileURLToPath(generatedConfigURL);
  const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';

  for (const name of namesToSeed) {
    const filePath = path.join(seedRoot, name);
    const objectKey = `ziyarats/quba-mosque/${name}`;
    console.log(`Seeding R2 object ${objectKey}`);
    execFileSync(
      npx,
      ['wrangler', 'r2', 'object', 'put', `${bucket}/${objectKey}`, `--file=${filePath}`, '--content-type=image/jpeg', '--remote', `--config=${configPath}`],
      { cwd: workerRoot, stdio: 'inherit', env: process.env },
    );
  }
}

await seedZiyaratMedia();
