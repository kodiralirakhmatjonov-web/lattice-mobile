import { WorkflowEntrypoint } from 'cloudflare:workers';

const JSON_HEADERS = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store'
};

const PUBLIC_CACHE_HEADERS = {
  'cache-control': 'public, max-age=60, s-maxage=300'
};

export default {
  async fetch(request, env) {
    try {
      const url = new URL(request.url);

      if (request.method === 'OPTIONS') {
        return new Response(null, {
          status: 204,
          headers: corsHeaders(request)
        });
      }

      if (url.pathname.startsWith('/api/admin/hotels')) {
        const staff = await requireStaff(request, env);
        if (!staff.ok) return staff.response;
        return withCors(await handleAdmin(request, env, url, staff.user), request);
      }

      if (url.pathname.startsWith('/api/catalog/hotels')) {
        return withCors(await handleCatalog(request, env, url), request);
      }

      return json({ ok: false, error: 'NOT_FOUND' }, 404);
    } catch (error) {
      console.error('HOTELS_API_UNHANDLED', error);
      return json({ ok: false, error: 'INTERNAL_ERROR' }, 500);
    }
  },

  async scheduled(_controller, env, ctx) {
    ctx.waitUntil(syncRecentBookingsAndNotify(env));
  }
};

async function handleAdmin(request, env, url, user) {
  const parts = pathParts(url.pathname, '/api/admin/hotels');

  if (parts.length === 0) {
    if (request.method === 'GET') {
      return listHotels(env, url, false);
    }
    if (request.method === 'POST') {
      return saveHotel(request, env, user);
    }
    return methodNotAllowed();
  }

  if (parts.length === 1 && parts[0] === 'health') {
    if (request.method !== 'GET') return methodNotAllowed();
    return health(env, true);
  }

  if (parts[0] === 'dedupe') {
    if (request.method !== 'POST' || parts.length !== 1) return methodNotAllowed();
    return checkDuplicateRequest(request, env);
  }

  if (parts[0] === 'source-rooms') {
    if (parts.length !== 1 || request.method !== 'POST') return methodNotAllowed();
    return recoverSourceRooms(request, env);
  }

  if (parts[0] === 'import-jobs') {
    if (parts.length === 1 && request.method === 'GET') return listImportJobs(env, url);
    if (parts.length === 1 && request.method === 'POST') return createImportJob(request, env, user);
    const jobID = safeID(parts[1]);
    if (!jobID) return json({ ok: false, error: 'INVALID_JOB_ID' }, 400);
    if (parts.length === 2 && request.method === 'GET') return importJobDetail(env, jobID);
    if (parts.length === 2 && request.method === 'DELETE') return deleteImportJob(env, jobID);
    if (parts.length === 3 && parts[2] === 'retry' && request.method === 'POST') return retryImportJob(env, jobID);
    if (parts.length === 3 && parts[2] === 'cancel' && request.method === 'POST') return cancelImportJob(env, jobID);
    return methodNotAllowed();
  }

  if (parts[0] === 'chats') {
    return handleBusinessChats(request, env, parts.slice(1), user);
  }

  if (parts[0] === 'push') {
    return handleBusinessPush(request, env, parts.slice(1), user);
  }

  if (parts[0] === 'operations') {
    return handleBusinessOperations(request, env, url, parts.slice(1), user);
  }

  const hotelID = safeID(parts[0]);
  if (!hotelID) return json({ ok: false, error: 'INVALID_HOTEL_ID' }, 400);

  if (parts.length === 1) {
    if (request.method === 'GET') return hotelDetail(env, hotelID, true, url);
    if (request.method === 'DELETE') return deleteHotel(env, hotelID);
    return methodNotAllowed();
  }

  if (parts.length === 2 && parts[1] === 'images') {
    if (request.method === 'POST') return uploadHotelImage(request, env, hotelID);
    if (request.method === 'DELETE') return deleteAllHotelImages(env, hotelID);
    return methodNotAllowed();
  }

  if (parts.length === 3 && parts[1] === 'images') {
    if (request.method !== 'GET') return methodNotAllowed();
    return serveHotelImage(env, hotelID, parts[2], true);
  }

  return json({ ok: false, error: 'NOT_FOUND' }, 404);
}


async function handleBusinessChats(request, env, parts, user) {
  if (parts.length === 0 && request.method === 'GET') return listBusinessChatThreads(env);
  const bookingID = cleanText(parts[0], 180);
  if (!bookingID) return json({ ok: false, error: 'INVALID_BOOKING_ID' }, 400);
  if (parts.length === 1 && request.method === 'GET') return chatMessages(env, bookingID, true);
  if (parts.length === 2 && parts[1] === 'messages') {
    if (request.method === 'GET') return chatMessages(env, bookingID, true);
    if (request.method === 'POST') return sendChatMessage(request, env, bookingID, user);
  }
  if (parts.length === 2 && parts[1] === 'attachments' && request.method === 'POST') {
    return sendChatAttachment(request, env, bookingID, user, true);
  }
  if (parts.length === 3 && parts[1] === 'media' && request.method === 'GET') {
    return serveChatAttachment(env, bookingID, parts[2]);
  }
  if (parts.length === 2 && parts[1] === 'read' && request.method === 'POST') {
    await env.HOTELS_DB.batch([
      env.HOTELS_DB.prepare('UPDATE business_chat_messages SET read_by_staff=1 WHERE booking_id=?').bind(bookingID),
      env.HOTELS_DB.prepare('UPDATE business_chat_threads SET unread_for_staff=0, updated_at=? WHERE booking_id=?').bind(new Date().toISOString(), bookingID)
    ]);
    return json({ ok: true });
  }
  return methodNotAllowed();
}

async function listBusinessChatThreads(env) {
  const result = await env.HOTELS_DB.prepare(`
    SELECT booking_id, last_message_at, last_message_preview, last_sender_type, unread_for_staff, updated_at
    FROM business_chat_threads
    ORDER BY COALESCE(last_message_at, updated_at) DESC
    LIMIT 300
  `).all();
  return json({
    ok: true,
    threads: (result.results || []).map(row => ({
      bookingID: row.booking_id,
      lastMessageAt: row.last_message_at || row.updated_at,
      lastMessagePreview: row.last_message_preview || '',
      lastSenderType: row.last_sender_type || null,
      unreadForStaff: Number(row.unread_for_staff || 0) === 1
    }))
  });
}

async function chatMessages(env, bookingID, admin = true) {
  await importLegacyChatForBooking(env, bookingID).catch(() => {});
  const result = await env.HOTELS_DB.prepare(`
    SELECT id, booking_id, sender_type, sender_name, body, created_at, read_by_staff, message_type, attachment_id
    FROM business_chat_messages WHERE booking_id=? ORDER BY created_at ASC LIMIT 500
  `).bind(bookingID).all();
  return json({
    ok: true,
    bookingID,
    messages: (result.results || []).map(row => mapChatMessage(row, admin))
  });
}

function mapChatMessage(row, admin = true) {
  const attachmentID = row.attachment_id || null;
  return {
    id: row.id,
    bookingID: row.booking_id,
    senderType: row.sender_type,
    senderName: row.sender_name || null,
    body: row.body || (row.message_type === 'image' ? 'Фотография' : ''),
    messageType: row.message_type || 'text',
    attachmentID,
    attachmentURL: attachmentID ? (admin ? `/api/admin/hotels/chats/${encodeURIComponent(row.booking_id)}/media/${encodeURIComponent(attachmentID)}` : `/api/catalog/hotels/client/chats/${encodeURIComponent(row.booking_id)}/media/${encodeURIComponent(attachmentID)}`) : null,
    createdAt: row.created_at,
    readByStaff: Number(row.read_by_staff || 0) === 1
  };
}

async function staffDisplayName(env, user) {
  const login = cleanText(user?.login, 180);
  if (login) {
    const row = await env.HOTELS_DB.prepare('SELECT first_name, last_name, role_title FROM team_members WHERE staff_login=? LIMIT 1').bind(login).first().catch(() => null);
    if (row) {
      const name = [row.first_name, row.last_name].filter(Boolean).join(' ').trim();
      if (name) return safeHumanText(name, 160) || 'iumrah Business';
      if (row.role_title) return safeHumanText(row.role_title, 160) || 'iumrah Business';
    }
  }
  return safeHumanText(user?.displayName || user?.login || 'iumrah Business', 160) || 'iumrah Business';
}

async function sendChatMessage(request, env, bookingID, user) {
  const payload = await request.json().catch(() => null);
  const body = safeHumanText(payload?.body, 4000);
  if (!body) return json({ ok: false, error: 'EMPTY_MESSAGE' }, 400);
  const clientMessageID = safeID(payload?.clientMessageID) || null;
  if (clientMessageID) {
    const existing = await env.HOTELS_DB.prepare('SELECT id FROM business_chat_messages WHERE booking_id=? AND client_message_id=? LIMIT 1')
      .bind(bookingID, clientMessageID).first();
    if (existing?.id) return chatMessageDetail(env, existing.id, 200);
  }
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const senderName = await staffDisplayName(env, user);
  await env.HOTELS_DB.batch([
    env.HOTELS_DB.prepare(`
      INSERT INTO business_chat_threads (booking_id, created_at, updated_at, last_message_at, last_message_preview, last_sender_type, unread_for_staff)
      VALUES (?, ?, ?, ?, ?, 'staff', 0)
      ON CONFLICT(booking_id) DO UPDATE SET updated_at=excluded.updated_at, last_message_at=excluded.last_message_at,
        last_message_preview=excluded.last_message_preview, last_sender_type='staff', unread_for_staff=0
    `).bind(bookingID, now, now, now, body.slice(0, 240)),
    env.HOTELS_DB.prepare(`
      INSERT INTO business_chat_messages (id, booking_id, sender_type, sender_name, body, created_at, read_by_staff, client_message_id)
      VALUES (?, ?, 'staff', ?, ?, ?, 1, ?)
    `).bind(id, bookingID, senderName, body, now, clientMessageID)
  ]);
  await sendClientPushForBooking(env, bookingID, senderName, body.slice(0, 180), { type: 'chat_message' }).catch(() => {});
  return chatMessageDetail(env, id, 201);
}

async function chatMessageDetail(env, id, status = 200, admin = true) {
  const row = await env.HOTELS_DB.prepare('SELECT * FROM business_chat_messages WHERE id=?').bind(id).first();
  if (!row) return json({ ok: false, error: 'MESSAGE_NOT_FOUND' }, 404);
  return json({ ok: true, message: mapChatMessage(row, admin) }, status);
}

async function handleBusinessPush(request, env, parts, user) {
  if (parts.length === 1 && parts[0] === 'devices' && request.method === 'POST') {
    const payload = await request.json().catch(() => null);
    const token = cleanText(payload?.deviceToken, 256)?.toLowerCase();
    if (!token || !/^[0-9a-f]{32,256}$/.test(token)) return json({ ok: false, error: 'INVALID_DEVICE_TOKEN' }, 400);
    const environment = payload?.environment === 'development' ? 'development' : 'production';
    const now = new Date().toISOString();
    await env.HOTELS_DB.prepare(`
      INSERT INTO business_push_devices (device_token, staff_login, environment, app_bundle_id, enabled, created_at, updated_at, last_error)
      VALUES (?, ?, ?, 'com.iumrah.business', 1, ?, ?, NULL)
      ON CONFLICT(device_token) DO UPDATE SET staff_login=excluded.staff_login, environment=excluded.environment,
        app_bundle_id=excluded.app_bundle_id, enabled=1, updated_at=excluded.updated_at, last_error=NULL
    `).bind(token, cleanText(user?.login, 180), environment, now, now).run();
    return json({ ok: true, ready: apnsConfigured(env) });
  }
  if (parts.length === 1 && parts[0] === 'status' && request.method === 'GET') {
    const row = await env.HOTELS_DB.prepare('SELECT COUNT(*) AS count FROM business_push_devices WHERE enabled=1').first();
    return json({ ok: true, configured: apnsConfigured(env), devices: Number(row?.count || 0) });
  }
  return methodNotAllowed();
}

function apnsConfigured(env) {
  return !!(env.APNS_PRIVATE_KEY && env.APNS_KEY_ID && env.APPLE_TEAM_ID);
}


async function sendPushRows(env, rows, topic, title, body, data, tableName) {
  if (!apnsConfigured(env)) return { ok: false, skipped: 'APNS_NOT_CONFIGURED', sent: 0, total: rows.length };
  if (!rows.length) return { ok: false, skipped: 'NO_DEVICES', sent: 0, total: 0 };
  const jwt = await apnsJWT(env);
  let sent = 0;
  for (const device of rows) {
    const base = device.environment === 'development' ? 'https://api.sandbox.push.apple.com' : 'https://api.push.apple.com';
    const response = await fetch(`${base}/3/device/${device.device_token}`, {
      method: 'POST',
      headers: {
        authorization: `bearer ${jwt}`,
        'apns-topic': topic,
        'apns-push-type': 'alert',
        'apns-priority': '10',
        'content-type': 'application/json'
      },
      body: JSON.stringify({ aps: { alert: { title, body }, sound: 'default' }, ...data })
    }).catch(() => null);
    const now = new Date().toISOString();
    if (response?.ok) {
      sent += 1;
      await env.HOTELS_DB.prepare(`UPDATE ${tableName} SET last_success_at=?, last_error=NULL, updated_at=? WHERE device_token=?`)
        .bind(now, now, device.device_token).run().catch(() => {});
    } else if (response) {
      const text = await response.text().catch(() => '');
      const disable = response.status === 410 || /BadDeviceToken|Unregistered|DeviceTokenNotForTopic/i.test(text);
      await env.HOTELS_DB.prepare(`UPDATE ${tableName} SET enabled=?, last_error=?, updated_at=? WHERE device_token=?`)
        .bind(disable ? 0 : 1, `${response.status}:${text}`.slice(0, 900), now, device.device_token).run().catch(() => {});
    }
  }
  return { ok: sent > 0, sent, total: rows.length };
}

async function sendStaffPush(env, title, body, data = {}) {
  const devices = await env.HOTELS_DB.prepare('SELECT device_token, environment FROM business_push_devices WHERE enabled=1 LIMIT 100').all().catch(() => ({ results: [] }));
  return sendPushRows(env, devices.results || [], 'com.iumrah.business', title, body, data, 'business_push_devices');
}

async function sendClientPushForBooking(env, bookingID, title, body, data = {}) {
  const trip = await env.HOTELS_DB.prepare('SELECT client_user_id FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first().catch(() => null);
  const clientID = cleanText(trip?.client_user_id, 180);
  if (!clientID || clientID.startsWith('legacy-booking:')) return { ok: false, skipped: 'CLIENT_ID_MISSING', sent: 0, total: 0 };
  const devices = await env.HOTELS_DB.prepare('SELECT device_token, environment FROM client_push_devices WHERE client_user_id=? AND enabled=1 LIMIT 20').bind(clientID).all().catch(() => ({ results: [] }));
  return sendPushRows(env, devices.results || [], 'com.iumrah.beta', title, body, { ...data, bookingID }, 'client_push_devices');
}
let cachedAPNSJWT = null;
let cachedAPNSJWTAt = 0;
async function apnsJWT(env) {
  const nowSeconds = Math.floor(Date.now() / 1000);
  if (cachedAPNSJWT && nowSeconds - cachedAPNSJWTAt < 45 * 60) return cachedAPNSJWT;
  const header = base64urlJSON({ alg: 'ES256', kid: env.APNS_KEY_ID });
  const payload = base64urlJSON({ iss: env.APPLE_TEAM_ID, iat: nowSeconds });
  const signingInput = `${header}.${payload}`;
  const key = await crypto.subtle.importKey('pkcs8', pemToArrayBuffer(env.APNS_PRIVATE_KEY), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, new TextEncoder().encode(signingInput));
  cachedAPNSJWT = `${signingInput}.${base64urlBytes(new Uint8Array(signature))}`;
  cachedAPNSJWTAt = nowSeconds;
  return cachedAPNSJWT;
}

function pemToArrayBuffer(pem) {
  const base64 = String(pem || '').replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s+/g, '');
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function base64urlJSON(value) {
  return base64urlBytes(new TextEncoder().encode(JSON.stringify(value)));
}

function base64urlBytes(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}


function bookingAccessToken(request) {
  return String(request.headers.get('x-booking-token') || '').trim();
}

function clientIdentityHeader(request) {
  const value = String(request.headers.get('x-iumrah-client-id') || '').trim();
  return /^[A-Za-z0-9._:-]{16,180}$/.test(value) ? value : '';
}

async function bookingTokenHashHex(value) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

function bookingRowToRaw(row) {
  const payload = parseJSONObject(row?.payload_json);
  return {
    ...payload,
    id: String(row?.id || payload?.id || ''),
    status: row?.status || payload?.status || 'NEW',
    createdAt: row?.created_at || payload?.createdAt || payload?.created_at || null,
    updatedAt: row?.updated_at || payload?.updatedAt || payload?.updated_at || null
  };
}

async function authorizedBookingByToken(request, env, bookingID) {
  if (!env.BOOKINGS_DB) return { ok: false, response: json({ ok: false, error: 'BOOKINGS_DB_NOT_CONFIGURED' }, 503) };
  const token = bookingAccessToken(request);
  if (!bookingID || token.length < 24 || token.length > 256) return { ok: false, response: json({ ok: false, error: 'BOOKING_ACCESS_DENIED' }, 403) };
  const hash = await bookingTokenHashHex(token);
  const row = await env.BOOKINGS_DB.prepare('SELECT * FROM bookings WHERE id=? AND access_token_hash=? LIMIT 1').bind(bookingID, hash).first().catch(() => null);
  if (!row) return { ok: false, response: json({ ok: false, error: 'BOOKING_ACCESS_DENIED' }, 403) };
  return { ok: true, row, raw: bookingRowToRaw(row) };
}

let bookingChildTablesCache = null;
async function bookingChildTables(env) {
  if (!env.BOOKINGS_DB) return [];
  if (bookingChildTablesCache) return bookingChildTablesCache;
  const tables = await env.BOOKINGS_DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
  const output = [];
  for (const row of tables.results || []) {
    const table = String(row?.name || '');
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(table) || table === 'bookings') continue;
    const columns = await env.BOOKINGS_DB.prepare(`PRAGMA table_info("${table}")`).all().catch(() => ({ results: [] }));
    if ((columns.results || []).some(column => column?.name === 'booking_id')) output.push(table);
  }
  bookingChildTablesCache = output;
  return output;
}

async function cleanupPilgrimAfterTripDelete(env, pilgrimID, clientUserID, preserveIdentity = true) {
  if (!pilgrimID) return;
  const now = new Date().toISOString();
  const stats = await env.HOTELS_DB.prepare('SELECT COUNT(*) AS count, MAX(COALESCE(end_date, created_at)) AS last_trip FROM pilgrim_trips WHERE pilgrim_id=?').bind(pilgrimID).first();
  if (Number(stats?.count || 0) === 0) {
    const pilgrim = await env.HOTELS_DB.prepare('SELECT client_user_id FROM pilgrims WHERE id=? LIMIT 1').bind(pilgrimID).first().catch(() => null);
    const stableID = cleanText(pilgrim?.client_user_id || clientUserID, 180) || '';
    const shouldKeep = preserveIdentity && stableID && !stableID.startsWith('legacy-booking:');
    if (!shouldKeep) {
      await env.HOTELS_DB.prepare('DELETE FROM pilgrims WHERE id=?').bind(pilgrimID).run();
      if (stableID) await env.HOTELS_DB.prepare('DELETE FROM client_push_devices WHERE client_user_id=?').bind(stableID).run().catch(() => {});
    } else {
      await env.HOTELS_DB.prepare('UPDATE pilgrims SET total_trips=0, last_trip_at=NULL, updated_at=? WHERE id=?').bind(now, pilgrimID).run();
    }
  } else {
    await env.HOTELS_DB.prepare('UPDATE pilgrims SET total_trips=?, last_trip_at=?, updated_at=? WHERE id=?').bind(Number(stats.count), stats.last_trip || null, now, pilgrimID).run();
  }
}

function tripStatusPreservesIdentity(status) {
  return new Set(['paid','booking_confirmed','documents_ready','ready_to_travel','in_trip','completed']).has(String(status || '').toLowerCase());
}

async function hardDeleteBooking(env, bookingID) {
  if (!env.BOOKINGS_DB) return { ok: false, response: json({ ok: false, error: 'BOOKINGS_DB_NOT_CONFIGURED' }, 503) };
  const booking = await env.BOOKINGS_DB.prepare('SELECT id FROM bookings WHERE id=? LIMIT 1').bind(bookingID).first().catch(() => null);
  const trip = await env.HOTELS_DB.prepare('SELECT pilgrim_id, client_user_id, status FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first().catch(() => null);
  const attachments = await env.HOTELS_DB.prepare('SELECT object_key FROM business_chat_attachments WHERE booking_id=?').bind(bookingID).all().catch(() => ({ results: [] }));
  await env.HOTELS_DB.batch([
    env.HOTELS_DB.prepare('DELETE FROM business_chat_messages WHERE booking_id=?').bind(bookingID),
    env.HOTELS_DB.prepare('DELETE FROM business_chat_attachments WHERE booking_id=?').bind(bookingID),
    env.HOTELS_DB.prepare('DELETE FROM business_chat_threads WHERE booking_id=?').bind(bookingID),
    env.HOTELS_DB.prepare('DELETE FROM booking_status_history WHERE booking_id=?').bind(bookingID),
    env.HOTELS_DB.prepare('DELETE FROM trip_flights WHERE booking_id=?').bind(bookingID),
    env.HOTELS_DB.prepare('DELETE FROM trip_assignments WHERE booking_id=?').bind(bookingID),
    env.HOTELS_DB.prepare('DELETE FROM operation_notification_receipts WHERE booking_id=?').bind(bookingID),
    env.HOTELS_DB.prepare('DELETE FROM pilgrim_trips WHERE booking_id=?').bind(bookingID)
  ]);
  await Promise.allSettled((attachments.results || []).map(row => env.HOTELS_MEDIA.delete(row.object_key)));
  if (trip?.pilgrim_id) await cleanupPilgrimAfterTripDelete(env, trip.pilgrim_id, cleanText(trip.client_user_id, 180), tripStatusPreservesIdentity(trip.status));
  if (booking) {
    const tables = await bookingChildTables(env);
    const statements = tables.map(table => env.BOOKINGS_DB.prepare(`DELETE FROM "${table}" WHERE booking_id=?`).bind(bookingID));
    statements.push(env.BOOKINGS_DB.prepare('DELETE FROM bookings WHERE id=?').bind(bookingID));
    await env.BOOKINGS_DB.batch(statements);
  }
  return { ok: true, existed: !!booking || !!trip };
}

let legacyChatTablesCache = null;
async function legacyChatTables(env) {
  if (!env.BOOKINGS_DB) return [];
  if (legacyChatTablesCache) return legacyChatTablesCache;
  const tables = await env.BOOKINGS_DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().catch(() => ({ results: [] }));
  const output = [];
  for (const row of tables.results || []) {
    const table = String(row?.name || '');
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(table) || !/(chat|message)/i.test(table)) continue;
    const columnsResult = await env.BOOKINGS_DB.prepare(`PRAGMA table_info("${table}")`).all().catch(() => ({ results: [] }));
    const columns = new Set((columnsResult.results || []).map(column => String(column?.name || '')));
    if (['booking_id','sender_type','created_at'].every(name => columns.has(name)) && (columns.has('body') || columns.has('message'))) output.push({ table, columns });
  }
  legacyChatTablesCache = output;
  return output;
}

async function importLegacyChatForBooking(env, bookingID) {
  if (!env.BOOKINGS_DB) return;
  const existing = await env.HOTELS_DB.prepare('SELECT COUNT(*) AS count FROM business_chat_messages WHERE booking_id=?').bind(bookingID).first().catch(() => null);
  if (Number(existing?.count || 0) > 0) return;
  const candidates = await legacyChatTables(env);
  for (const candidate of candidates) {
    const idExpr = candidate.columns.has('id') ? 'id' : 'rowid';
    const bodyExpr = candidate.columns.has('body') ? 'body' : 'message';
    const rows = await env.BOOKINGS_DB.prepare(`SELECT ${idExpr} AS legacy_id, sender_type, ${bodyExpr} AS body, created_at FROM "${candidate.table}" WHERE booking_id=? ORDER BY created_at ASC LIMIT 500`).bind(bookingID).all().catch(() => ({ results: [] }));
    if (!(rows.results || []).length) continue;
    const now = new Date().toISOString();
    const statements = [env.HOTELS_DB.prepare(`INSERT INTO business_chat_threads (booking_id, created_at, updated_at, last_message_at, last_message_preview, last_sender_type, unread_for_staff) VALUES (?, ?, ?, ?, '', NULL, 0) ON CONFLICT(booking_id) DO NOTHING`).bind(bookingID, now, now, now)];
    let last = null;
    for (const row of rows.results || []) {
      const oldType = String(row.sender_type || '').toLowerCase();
      const senderType = ['pilgrim','client','user','customer'].includes(oldType) ? 'client' : oldType === 'system' ? 'system' : 'staff';
      const body = safeHumanText(row.body, 4000) || '';
      const createdAt = cleanText(row.created_at, 80) || now;
      const rawID = String(row.legacy_id || crypto.randomUUID()).replace(/[^A-Za-z0-9._:-]/g, '-').slice(0, 180);
      const id = `legacy-${candidate.table}-${rawID}`;
      const senderName = senderType === 'client' ? 'Паломник' : senderType === 'staff' ? 'iumrah Care' : 'Система';
      statements.push(env.HOTELS_DB.prepare(`INSERT OR IGNORE INTO business_chat_messages (id, booking_id, sender_type, sender_name, body, created_at, read_by_staff, message_type) VALUES (?, ?, ?, ?, ?, ?, ?, 'text')`).bind(id, bookingID, senderType, senderName, body, createdAt, senderType === 'client' ? 0 : 1));
      last = { senderType, body, createdAt };
    }
    if (last) statements.push(env.HOTELS_DB.prepare('UPDATE business_chat_threads SET updated_at=?, last_message_at=?, last_message_preview=?, last_sender_type=?, unread_for_staff=? WHERE booking_id=?').bind(last.createdAt, last.createdAt, last.body.slice(0, 240), last.senderType, last.senderType === 'client' ? 1 : 0, bookingID));
    await env.HOTELS_DB.batch(statements);
    await env.BOOKINGS_DB.prepare(`DELETE FROM "${candidate.table}" WHERE booking_id=?`).bind(bookingID).run().catch(() => {});
  }
}

async function notifyNewBookingIfNeeded(env, bookingID, raw, linked) {
  const eventKey = `new-booking:${bookingID}`;
  const existing = await env.HOTELS_DB.prepare('SELECT event_key FROM operation_notification_receipts WHERE event_key=? LIMIT 1').bind(eventKey).first().catch(() => null);
  if (existing) return;
  const createdRaw = raw?.createdAt || raw?.created_at || null;
  const createdMs = createdRaw ? Date.parse(String(createdRaw)) : NaN;
  const ageMs = Number.isFinite(createdMs) ? Date.now() - createdMs : Number.POSITIVE_INFINITY;
  const isRecent = ageMs >= -2 * 60_000 && ageMs <= 20 * 60_000;
  if (isRecent) {
    const identity = bookingIdentity(raw, bookingID);
    const name = linked?.pilgrim?.display_name || identity.displayName || 'Паломник';
    await sendStaffPush(env, 'Новая заявка iumrah', `${name} · ${bookingID}`, { type: 'new_booking', bookingID }).catch(() => {});
  }
  await env.HOTELS_DB.prepare('INSERT OR IGNORE INTO operation_notification_receipts (event_key, booking_id, event_type, created_at) VALUES (?, ?, ?, ?)').bind(eventKey, bookingID, 'new_booking', new Date().toISOString()).run();
}

async function cleanupLegacyDeletedBookings(env) {
  if (!env.BOOKINGS_DB || !env.HOTELS_DB) return;
  const table = await env.HOTELS_DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='legacy_deleted_bookings_cleanup' LIMIT 1").first().catch(() => null);
  if (!table) return;
  const result = await env.HOTELS_DB.prepare('SELECT booking_id FROM legacy_deleted_bookings_cleanup LIMIT 500').all().catch(() => ({ results: [] }));
  for (const row of result.results || []) {
    const bookingID = cleanText(row?.booking_id, 180);
    if (!bookingID) continue;
    try {
      const deleted = await hardDeleteBooking(env, bookingID);
      if (deleted.ok) await env.HOTELS_DB.prepare('DELETE FROM legacy_deleted_bookings_cleanup WHERE booking_id=?').bind(bookingID).run();
    } catch (error) {
      console.warn('LEGACY_BOOKING_DELETE_RETRY', bookingID, error);
    }
  }
  const remaining = await env.HOTELS_DB.prepare('SELECT COUNT(*) AS count FROM legacy_deleted_bookings_cleanup').first().catch(() => null);
  if (Number(remaining?.count || 0) === 0) await env.HOTELS_DB.prepare('DROP TABLE legacy_deleted_bookings_cleanup').run().catch(() => {});
}

async function syncRecentBookingsAndNotify(env) {
  if (!env.BOOKINGS_DB || !env.HOTELS_DB) return;
  await cleanupLegacyDeletedBookings(env);
  let rows;
  try { rows = await env.BOOKINGS_DB.prepare('SELECT * FROM bookings ORDER BY rowid DESC LIMIT 100').all(); }
  catch { rows = await env.BOOKINGS_DB.prepare('SELECT * FROM bookings LIMIT 100').all(); }
  for (const row of rows.results || []) {
    try {
      const raw = bookingRowToRaw(row);
      const linked = await syncBookingTrip(env, raw);
      if (linked) await notifyNewBookingIfNeeded(env, raw.id, raw, linked);
      await importLegacyChatForBooking(env, raw.id);
    } catch (error) {
      console.warn('BOOKING_CRON_SYNC_FAILED', row?.id, error);
    }
  }
}

async function handleCatalog(request, env, url) {
  const parts = pathParts(url.pathname, '/api/catalog/hotels');

  if (parts.length === 0) {
    if (request.method !== 'GET') return methodNotAllowed();
    return listHotels(env, url, true);
  }

  if (parts.length === 1 && parts[0] === 'health') {
    if (request.method !== 'GET') return methodNotAllowed();
    return health(env, false);
  }

  if (parts[0] === 'team-media') {
    if (parts.length !== 2 || request.method !== 'GET') return methodNotAllowed();
    return serveTeamMemberPhoto(env, parts[1]);
  }

  if (parts[0] === 'team') {
    if (request.method !== 'GET') return methodNotAllowed();
    return publicTeam(env, parts.slice(1));
  }

  if (parts.length === 1 && parts[0] === 'primary') {
    if (request.method !== 'GET') return methodNotAllowed();
    return publicPrimaryHotels(env, url);
  }

  if (parts[0] === 'client') {
    return handleClientOperations(request, env, parts.slice(1));
  }

  const hotelID = safeID(parts[0]);
  if (!hotelID) return json({ ok: false, error: 'INVALID_HOTEL_ID' }, 400);

  if (parts.length === 1) {
    if (request.method !== 'GET') return methodNotAllowed();
    return hotelDetail(env, hotelID, false, url);
  }

  if (parts.length === 3 && parts[1] === 'translations') {
    if (request.method !== 'GET') return methodNotAllowed();
    return hotelTranslation(env, hotelID, parts[2]);
  }

  if (parts.length === 3 && parts[1] === 'images') {
    if (request.method !== 'GET') return methodNotAllowed();
    return serveHotelImage(env, hotelID, parts[2], false);
  }

  return json({ ok: false, error: 'NOT_FOUND' }, 404);
}


const TRIP_STATUSES = new Set([
  'new','availability_check','payment_pending','paid','booking_confirmed',
  'documents_ready','ready_to_travel','in_trip','completed','cancelled'
]);

async function handleBusinessOperations(request, env, url, parts, user) {
  if (parts.length === 1 && parts[0] === 'me') {
    if (request.method === 'GET') return businessProfileMe(env, user);
    if (request.method === 'PUT') return saveBusinessProfileMe(request, env, user);
    return methodNotAllowed();
  }

  if (parts[0] === 'team') {
    if (parts.length === 1 && request.method === 'GET') return adminTeam(env);
    if (parts.length === 1 && request.method === 'POST') return createTeamMember(request, env);
    const memberID = safeID(parts[1]);
    if (!memberID) return json({ ok: false, error: 'INVALID_TEAM_MEMBER_ID' }, 400);
    if (parts.length === 2 && request.method === 'GET') return adminTeamMember(env, memberID);
    if (parts.length === 2 && request.method === 'PUT') return updateTeamMember(request, env, memberID);
    if (parts.length === 2 && request.method === 'DELETE') return deleteTeamMember(env, memberID);
    if (parts.length === 3 && parts[2] === 'photo' && request.method === 'POST') return uploadTeamMemberPhoto(request, env, memberID);
    if (parts.length === 3 && parts[2] === 'photo' && request.method === 'DELETE') return deleteTeamMemberPhoto(env, memberID);
    return methodNotAllowed();
  }

  if (parts[0] === 'flight-verify') {
    if (parts.length !== 1 || request.method !== 'POST') return methodNotAllowed();
    return verifyBusinessFlight(request, env);
  }

  if (parts[0] === 'bookings') {
    if (parts.length === 1 && request.method === 'GET') return operationsBookings(request, env);
    const bookingID = cleanText(parts[1], 180);
    if (!bookingID) return json({ ok: false, error: 'INVALID_BOOKING_ID' }, 400);
    if (parts.length === 2 && request.method === 'GET') return operationsBookingDetail(request, env, bookingID);
    if (parts.length === 2 && request.method === 'PATCH') return updateOperationsBooking(request, env, bookingID, user);
    if (parts.length === 2 && request.method === 'DELETE') return deleteOperationsBooking(request, env, bookingID, user);
    if (parts.length === 3 && parts[2] === 'assignments' && request.method === 'PATCH') return updateBookingAssignments(request, env, bookingID);
    if (parts.length === 4 && parts[2] === 'flights' && request.method === 'PUT') return saveVerifiedBookingFlight(request, env, bookingID, parts[3]);
    if (parts.length === 4 && parts[2] === 'flights' && request.method === 'DELETE') return deleteBookingFlight(env, bookingID, parts[3]);
    return methodNotAllowed();
  }

  if (parts[0] === 'pilgrims') {
    if (parts.length === 1 && request.method === 'GET') return listPilgrims(env, url);
    const publicID = cleanText(parts[1], 80);
    if (!publicID) return json({ ok: false, error: 'INVALID_PILGRIM_ID' }, 400);
    if (parts.length === 2 && request.method === 'GET') return pilgrimDetail(env, publicID);
    return methodNotAllowed();
  }

  if (parts[0] === 'primary-hotels') {
    if (parts.length !== 1) return json({ ok: false, error: 'NOT_FOUND' }, 404);
    if (request.method === 'GET') return adminPrimaryHotels(env, url);
    if (request.method === 'PUT') return savePrimaryHotels(request, env);
    return methodNotAllowed();
  }

  return json({ ok: false, error: 'NOT_FOUND' }, 404);
}


const FLIGHT_DIRECTIONS = new Set(['outbound','return']);

function normalizedFlightNumber(value) {
  const text = String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!/^[A-Z0-9]{2,4}\d{1,4}[A-Z]?$/.test(text)) return '';
  return text;
}

function validLocalDate(value) {
  const text = String(value || '').trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return '';
  const parsed = Date.parse(`${text}T00:00:00Z`);
  return Number.isFinite(parsed) ? text : '';
}

function movementTime(movement, key, utc = false) {
  if (!movement || typeof movement !== 'object') return '';
  const legacyKey = `${key}${utc ? 'Utc' : 'Local'}`;
  const legacy = movement[legacyKey];
  if (typeof legacy === 'string' && legacy.trim()) return legacy.trim();
  const structured = movement[key];
  if (structured && typeof structured === 'object') {
    const value = structured[utc ? 'utc' : 'local'];
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return '';
}

function airportFromMovement(movement) {
  const airport = movement?.airport && typeof movement.airport === 'object' ? movement.airport : {};
  return {
    iata: cleanText(airport.iata, 12) || '',
    icao: cleanText(airport.icao, 12) || '',
    name: safeHumanText(airport.name || airport.shortName || airport.municipalityName || '', 240) || ''
  };
}

function normalizedAeroCandidate(item, index) {
  const departure = item?.departure && typeof item.departure === 'object' ? item.departure : {};
  const arrival = item?.arrival && typeof item.arrival === 'object' ? item.arrival : {};
  const depAirport = airportFromMovement(departure);
  const arrAirport = airportFromMovement(arrival);
  return {
    id: `candidate-${index + 1}`,
    flightNumber: safeHumanText(item?.number || '', 40) || '',
    callSign: safeHumanText(item?.callSign || '', 40) || '',
    airlineName: safeHumanText(item?.airline?.name || '', 180) || '',
    airlineIATA: cleanText(item?.airline?.iata, 12) || '',
    airlineICAO: cleanText(item?.airline?.icao, 12) || '',
    departureAirportIATA: depAirport.iata,
    departureAirportICAO: depAirport.icao,
    departureAirportName: depAirport.name,
    arrivalAirportIATA: arrAirport.iata,
    arrivalAirportICAO: arrAirport.icao,
    arrivalAirportName: arrAirport.name,
    scheduledDepartureLocal: movementTime(departure, 'scheduledTime', false),
    scheduledDepartureUTC: movementTime(departure, 'scheduledTime', true),
    scheduledArrivalLocal: movementTime(arrival, 'scheduledTime', false),
    scheduledArrivalUTC: movementTime(arrival, 'scheduledTime', true),
    departureTerminal: safeHumanText(departure.terminal || '', 40) || '',
    arrivalTerminal: safeHumanText(arrival.terminal || '', 40) || '',
    departureGate: safeHumanText(departure.gate || '', 40) || '',
    arrivalGate: safeHumanText(arrival.gate || '', 40) || '',
    status: safeHumanText(item?.status || '', 80) || '',
    lastUpdatedUTC: cleanText(item?.lastUpdatedUtc || item?.lastUpdatedUTC || '', 80) || ''
  };
}

function flightCacheTTL(dateLocal) {
  const target = Date.parse(`${dateLocal}T00:00:00Z`);
  const delta = Math.abs(target - Date.now());
  return delta <= 2 * 86400_000 ? 5 * 60_000 : 6 * 60 * 60_000;
}

async function verifyFlightWithAeroDataBox(env, flightNumber, dateLocal, force = false) {
  const normalized = normalizedFlightNumber(flightNumber);
  const date = validLocalDate(dateLocal);
  if (!normalized) return { ok: false, response: json({ ok: false, error: 'INVALID_FLIGHT_NUMBER' }, 400) };
  if (!date) return { ok: false, response: json({ ok: false, error: 'INVALID_FLIGHT_DATE' }, 400) };
  const cacheKey = `${normalized}|${date}`;
  const now = new Date();
  if (!force) {
    const cached = await env.HOTELS_DB.prepare('SELECT * FROM flight_verification_cache WHERE cache_key=? LIMIT 1').bind(cacheKey).first();
    if (cached && Date.parse(cached.expires_at) > now.getTime()) {
      return { ok: true, cacheKey, cached: true, checkedAt: cached.checked_at, candidates: parseJSONArray(cached.candidates_json) };
    }
  }
  const apiKey = String(env.AERODATABOX_RAPIDAPI_KEY || '').trim();
  if (!apiKey) return { ok: false, response: json({ ok: false, error: 'AERODATABOX_NOT_CONFIGURED' }, 503) };
  const endpoint = `https://aerodatabox.p.rapidapi.com/flights/number/${encodeURIComponent(normalized)}/${encodeURIComponent(date)}?withAircraftImage=false&withLocation=false&dateLocalRole=Departure`;
  let response;
  try {
    response = await fetch(endpoint, {
      method: 'GET',
      headers: {
        'accept': 'application/json',
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': 'aerodatabox.p.rapidapi.com'
      }
    });
  } catch (error) {
    console.error('AERODATABOX_NETWORK_ERROR', error);
    return { ok: false, response: json({ ok: false, error: 'FLIGHT_PROVIDER_UNAVAILABLE' }, 502) };
  }
  if (response.status === 429) return { ok: false, response: json({ ok: false, error: 'AERODATABOX_QUOTA_EXCEEDED' }, 429) };
  if (response.status === 401 || response.status === 403) return { ok: false, response: json({ ok: false, error: 'AERODATABOX_AUTH_FAILED' }, 502) };
  if (!response.ok) {
    const body = (await response.text().catch(() => '')).slice(0, 500);
    console.warn('AERODATABOX_HTTP_ERROR', response.status, body);
    return { ok: false, response: json({ ok: false, error: `AERODATABOX_HTTP_${response.status}` }, 502) };
  }
  const payload = await response.json().catch(() => null);
  const items = Array.isArray(payload) ? payload : [];
  const candidates = items
    .filter(item => normalizedFlightNumber(item?.number || '') === normalized)
    .slice(0, 8)
    .map((item, index) => normalizedAeroCandidate(item, index));
  const checkedAt = now.toISOString();
  const expiresAt = new Date(now.getTime() + flightCacheTTL(date)).toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO flight_verification_cache (cache_key, flight_number, date_local, candidates_json, checked_at, expires_at, provider)
    VALUES (?, ?, ?, ?, ?, ?, 'aerodatabox')
    ON CONFLICT(cache_key) DO UPDATE SET candidates_json=excluded.candidates_json, checked_at=excluded.checked_at, expires_at=excluded.expires_at, provider='aerodatabox'
  `).bind(cacheKey, normalized, date, JSON.stringify(candidates), checkedAt, expiresAt).run();
  await env.HOTELS_DB.prepare("DELETE FROM flight_verification_cache WHERE julianday(expires_at) < julianday('now','-7 days')").run().catch(() => {});
  return { ok: true, cacheKey, cached: false, checkedAt, candidates };
}

async function verifyBusinessFlight(request, env) {
  const payload = await request.json().catch(() => null);
  if (!payload) return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const result = await verifyFlightWithAeroDataBox(env, payload.flightNumber, payload.dateLocal, payload.force === true);
  if (!result.ok) return result.response;
  if (!result.candidates.length) return json({ ok: false, error: 'FLIGHT_NOT_FOUND', flightNumber: normalizedFlightNumber(payload.flightNumber), dateLocal: validLocalDate(payload.dateLocal) }, 404);
  return json({ ok: true, provider: 'AeroDataBox', verificationKey: result.cacheKey, cached: result.cached, checkedAt: result.checkedAt, candidates: result.candidates });
}

function mapTripFlight(row) {
  if (!row) return null;
  return {
    direction: row.direction,
    flightNumber: row.flight_number || '',
    callSign: row.call_sign || '',
    airlineName: row.airline_name || '',
    airlineIATA: row.airline_iata || '',
    airlineICAO: row.airline_icao || '',
    departureAirportIATA: row.departure_airport_iata || '',
    departureAirportICAO: row.departure_airport_icao || '',
    departureAirportName: row.departure_airport_name || '',
    arrivalAirportIATA: row.arrival_airport_iata || '',
    arrivalAirportICAO: row.arrival_airport_icao || '',
    arrivalAirportName: row.arrival_airport_name || '',
    scheduledDepartureLocal: row.scheduled_departure_local || '',
    scheduledDepartureUTC: row.scheduled_departure_utc || '',
    scheduledArrivalLocal: row.scheduled_arrival_local || '',
    scheduledArrivalUTC: row.scheduled_arrival_utc || '',
    departureTerminal: row.departure_terminal || '',
    arrivalTerminal: row.arrival_terminal || '',
    departureGate: row.departure_gate || '',
    arrivalGate: row.arrival_gate || '',
    status: row.status || '',
    verificationProvider: row.verification_provider || 'aerodatabox',
    verifiedAt: row.verified_at || null,
    lastCheckedAt: row.last_checked_at || null
  };
}

async function saveVerifiedBookingFlight(request, env, bookingID, directionRaw) {
  const direction = String(directionRaw || '').toLowerCase();
  if (!FLIGHT_DIRECTIONS.has(direction)) return json({ ok: false, error: 'INVALID_FLIGHT_DIRECTION' }, 400);
  const trip = await env.HOTELS_DB.prepare('SELECT id FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first();
  if (!trip) return json({ ok: false, error: 'BOOKING_NOT_SYNCED' }, 404);
  const payload = await request.json().catch(() => null);
  const verificationKey = cleanText(payload?.verificationKey, 120);
  const candidateID = cleanText(payload?.candidateID, 80);
  if (!verificationKey || !candidateID) return json({ ok: false, error: 'VERIFICATION_REQUIRED' }, 400);
  const cached = await env.HOTELS_DB.prepare('SELECT * FROM flight_verification_cache WHERE cache_key=? LIMIT 1').bind(verificationKey).first();
  if (!cached || Date.now() - Date.parse(cached.checked_at) > 24 * 60 * 60_000) return json({ ok: false, error: 'FLIGHT_VERIFICATION_EXPIRED' }, 409);
  const candidates = parseJSONArray(cached.candidates_json);
  const candidate = candidates.find(item => item?.id === candidateID);
  if (!candidate) return json({ ok: false, error: 'FLIGHT_CANDIDATE_NOT_FOUND' }, 404);
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO trip_flights (
      booking_id, direction, flight_number, call_sign, airline_name, airline_iata, airline_icao,
      departure_airport_iata, departure_airport_icao, departure_airport_name,
      arrival_airport_iata, arrival_airport_icao, arrival_airport_name,
      scheduled_departure_local, scheduled_departure_utc, scheduled_arrival_local, scheduled_arrival_utc,
      departure_terminal, arrival_terminal, departure_gate, arrival_gate, status,
      verification_provider, verification_key, verified_at, last_checked_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aerodatabox', ?, ?, ?, ?, ?)
    ON CONFLICT(booking_id, direction) DO UPDATE SET
      flight_number=excluded.flight_number, call_sign=excluded.call_sign, airline_name=excluded.airline_name,
      airline_iata=excluded.airline_iata, airline_icao=excluded.airline_icao,
      departure_airport_iata=excluded.departure_airport_iata, departure_airport_icao=excluded.departure_airport_icao,
      departure_airport_name=excluded.departure_airport_name, arrival_airport_iata=excluded.arrival_airport_iata,
      arrival_airport_icao=excluded.arrival_airport_icao, arrival_airport_name=excluded.arrival_airport_name,
      scheduled_departure_local=excluded.scheduled_departure_local, scheduled_departure_utc=excluded.scheduled_departure_utc,
      scheduled_arrival_local=excluded.scheduled_arrival_local, scheduled_arrival_utc=excluded.scheduled_arrival_utc,
      departure_terminal=excluded.departure_terminal, arrival_terminal=excluded.arrival_terminal,
      departure_gate=excluded.departure_gate, arrival_gate=excluded.arrival_gate, status=excluded.status,
      verification_provider='aerodatabox', verification_key=excluded.verification_key,
      verified_at=excluded.verified_at, last_checked_at=excluded.last_checked_at, updated_at=excluded.updated_at
  `).bind(
    bookingID, direction, candidate.flightNumber || '', candidate.callSign || '', candidate.airlineName || '', candidate.airlineIATA || '', candidate.airlineICAO || '',
    candidate.departureAirportIATA || '', candidate.departureAirportICAO || '', candidate.departureAirportName || '',
    candidate.arrivalAirportIATA || '', candidate.arrivalAirportICAO || '', candidate.arrivalAirportName || '',
    candidate.scheduledDepartureLocal || '', candidate.scheduledDepartureUTC || '', candidate.scheduledArrivalLocal || '', candidate.scheduledArrivalUTC || '',
    candidate.departureTerminal || '', candidate.arrivalTerminal || '', candidate.departureGate || '', candidate.arrivalGate || '', candidate.status || '',
    verificationKey, now, now, now, now
  ).run();
  return json({ ok: true, flight: mapTripFlight(await env.HOTELS_DB.prepare('SELECT * FROM trip_flights WHERE booking_id=? AND direction=?').bind(bookingID, direction).first()) });
}

async function deleteBookingFlight(env, bookingID, directionRaw) {
  const direction = String(directionRaw || '').toLowerCase();
  if (!FLIGHT_DIRECTIONS.has(direction)) return json({ ok: false, error: 'INVALID_FLIGHT_DIRECTION' }, 400);
  await env.HOTELS_DB.prepare('DELETE FROM trip_flights WHERE booking_id=? AND direction=?').bind(bookingID, direction).run();
  return json({ ok: true });
}

async function assignmentHotelSummary(env, hotelID) {
  if (!hotelID) return null;
  return hotelSummary(await summaryRow(env, hotelID));
}

async function bookingAssignmentDetail(env, bookingID) {
  const row = await env.HOTELS_DB.prepare('SELECT * FROM trip_assignments WHERE booking_id=? LIMIT 1').bind(bookingID).first();
  const primaryGuide = await env.HOTELS_DB.prepare("SELECT * FROM team_members WHERE role_kind='guide' AND active=1 ORDER BY sort_order ASC, created_at ASC LIMIT 1").first();
  if (!row) {
    return { makkahHotelID: null, madinahHotelID: null, guideID: primaryGuide?.id || null, makkahHotel: null, madinahHotel: null, guide: primaryGuide ? mapTeamMember(primaryGuide, true) : null, guideIsPrimary: !!primaryGuide };
  }
  const guide = row.guide_team_member_id
    ? await env.HOTELS_DB.prepare('SELECT * FROM team_members WHERE id=? LIMIT 1').bind(row.guide_team_member_id).first()
    : primaryGuide;
  return {
    makkahHotelID: row.makkah_hotel_id || null,
    madinahHotelID: row.madinah_hotel_id || null,
    guideID: guide?.id || null,
    makkahHotel: await assignmentHotelSummary(env, row.makkah_hotel_id),
    madinahHotel: await assignmentHotelSummary(env, row.madinah_hotel_id),
    guide: guide ? mapTeamMember(guide, true) : null,
    guideIsPrimary: !row.guide_team_member_id && !!primaryGuide
  };
}

async function updateBookingAssignments(request, env, bookingID) {
  const trip = await env.HOTELS_DB.prepare('SELECT id FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first();
  if (!trip) return json({ ok: false, error: 'BOOKING_NOT_SYNCED' }, 404);
  const payload = await request.json().catch(() => null);
  if (!payload || typeof payload !== 'object') return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const current = await env.HOTELS_DB.prepare('SELECT * FROM trip_assignments WHERE booking_id=? LIMIT 1').bind(bookingID).first();
  const makkahID = payload.makkahHotelID === null ? null : (cleanText(payload.makkahHotelID, 180) || current?.makkah_hotel_id || null);
  const madinahID = payload.madinahHotelID === null ? null : (cleanText(payload.madinahHotelID, 180) || current?.madinah_hotel_id || null);
  const guideID = payload.guideID === null ? null : (cleanText(payload.guideID, 180) || current?.guide_team_member_id || null);
  for (const [id, city] of [[makkahID, 'Makkah'], [madinahID, 'Madinah']]) {
    if (!id) continue;
    const hotel = await env.HOTELS_DB.prepare("SELECT id, city, status FROM hotels WHERE id=? AND status='published' LIMIT 1").bind(id).first();
    if (!hotel) return json({ ok: false, error: 'HOTEL_NOT_AVAILABLE', hotelID: id }, 409);
    if (hotel.city && String(hotel.city).toLowerCase() !== city.toLowerCase()) return json({ ok: false, error: 'HOTEL_CITY_MISMATCH', hotelID: id, expectedCity: city }, 409);
  }
  if (guideID) {
    const guide = await env.HOTELS_DB.prepare("SELECT id FROM team_members WHERE id=? AND role_kind='guide' AND active=1 LIMIT 1").bind(guideID).first();
    if (!guide) return json({ ok: false, error: 'GUIDE_NOT_AVAILABLE' }, 409);
  }
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO trip_assignments (booking_id, makkah_hotel_id, madinah_hotel_id, guide_team_member_id, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(booking_id) DO UPDATE SET makkah_hotel_id=excluded.makkah_hotel_id, madinah_hotel_id=excluded.madinah_hotel_id, guide_team_member_id=excluded.guide_team_member_id, updated_at=excluded.updated_at
  `).bind(bookingID, makkahID, madinahID, guideID, now, now).run();
  return json({ ok: true, assignment: await bookingAssignmentDetail(env, bookingID) });
}


async function deleteOperationsBooking(_request, env, bookingID, _user) {
  const result = await hardDeleteBooking(env, bookingID);
  if (!result.ok) return result.response;
  return json({ ok: true, deleted: true, deletedBookingID: bookingID });
}

function teamMemberPayload(payload, defaults = {}) {
  const firstName = safeHumanText(payload?.firstName ?? defaults.firstName ?? '', 120) || '';
  const lastName = safeHumanText(payload?.lastName ?? defaults.lastName ?? '', 120) || '';
  const roleKindRaw = String(payload?.roleKind ?? defaults.roleKind ?? 'guide').toLowerCase();
  const roleKind = ['owner','guide','manager','operations'].includes(roleKindRaw) ? roleKindRaw : 'guide';
  const publicSlugInput = cleanText(payload?.publicSlug ?? defaults.publicSlug, 120);
  const slugBase = publicSlugInput || `${firstName}-${lastName}` || `team-${crypto.randomUUID().slice(0, 8)}`;
  return {
    firstName,
    lastName,
    roleKind,
    roleTitle: safeHumanText(payload?.roleTitle ?? defaults.roleTitle ?? '', 160) || '',
    phoneUZ: cleanText(payload?.phoneUZ ?? defaults.phoneUZ ?? '', 80) || '',
    phoneSA: cleanText(payload?.phoneSA ?? defaults.phoneSA ?? '', 80) || '',
    telegram: cleanText(payload?.telegram ?? defaults.telegram ?? '', 160) || '',
    whatsapp: cleanText(payload?.whatsapp ?? defaults.whatsapp ?? '', 160) || '',
    instagram: cleanText(payload?.instagram ?? defaults.instagram ?? '', 160) || '',
    bio: safeHumanText(payload?.bio ?? defaults.bio ?? '', 1800) || '',
    publicSlug: slugify(slugBase) || `team-${crypto.randomUUID().slice(0, 8)}`,
    publicVisible: payload?.publicVisible == null ? (defaults.publicVisible ?? true) : !!payload.publicVisible,
    active: payload?.active == null ? (defaults.active ?? true) : !!payload.active
  };
}


function mapTeamMember(row, admin = true) {
  if (!row) return null;
  const base = {
    id: row.id,
    staffLogin: admin ? (row.staff_login || null) : undefined,
    firstName: row.first_name || '',
    lastName: row.last_name || '',
    displayName: [row.first_name, row.last_name].filter(Boolean).join(' ').trim() || row.role_title || 'iumrah',
    roleKind: row.role_kind || 'guide',
    roleTitle: row.role_title || '',
    phoneUZ: row.phone_uz || '',
    phoneSA: row.phone_sa || '',
    telegram: row.telegram || '',
    whatsapp: row.whatsapp || '',
    instagram: row.instagram || '',
    bio: row.bio || '',
    publicSlug: row.public_slug,
    publicVisible: Number(row.public_visible || 0) === 1,
    active: Number(row.active || 0) === 1,
    isOwner: Number(row.is_owner || 0) === 1,
    photoURL: row.photo_object_key ? `/api/catalog/hotels/team-media/${encodeURIComponent(row.id)}?v=${encodeURIComponent(row.photo_object_key)}` : null
  };
  if (!admin) delete base.staffLogin;
  return base;
}

async function ensureOwnerProfile(env, user) {
  const login = cleanText(user?.login, 180) || 'owner';
  let row = await env.HOTELS_DB.prepare('SELECT * FROM team_members WHERE staff_login=? LIMIT 1').bind(login).first();
  if (row) return row;
  const id = `team-${crypto.randomUUID()}`;
  const display = safeHumanText(user?.displayName || '', 200) || '';
  const pieces = display.split(/\s+/).filter(Boolean);
  const firstName = pieces[0] || '';
  const lastName = pieces.slice(1).join(' ');
  let slug = slugify(display || login) || `owner-${crypto.randomUUID().slice(0,8)}`;
  const exists = await env.HOTELS_DB.prepare('SELECT id FROM team_members WHERE public_slug=? LIMIT 1').bind(slug).first();
  if (exists) slug = `${slug}-${crypto.randomUUID().slice(0,6)}`;
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO team_members (id, staff_login, first_name, last_name, role_kind, role_title, public_slug, public_visible, active, is_owner, sort_order, created_at, updated_at)
    VALUES (?, ?, ?, ?, 'owner', 'Owner · iumrah', ?, 1, 1, 1, 0, ?, ?)
  `).bind(id, login, firstName, lastName, slug, now, now).run();
  return env.HOTELS_DB.prepare('SELECT * FROM team_members WHERE id=?').bind(id).first();
}

async function businessProfileMe(env, user) {
  return json({ ok: true, member: mapTeamMember(await ensureOwnerProfile(env, user), true) });
}

async function saveBusinessProfileMe(request, env, user) {
  const existing = await ensureOwnerProfile(env, user);
  const payload = await request.json().catch(() => null);
  if (!payload) return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const value = teamMemberPayload(payload, mapTeamMember(existing, true));
  const duplicate = await env.HOTELS_DB.prepare('SELECT id FROM team_members WHERE public_slug=? AND id<>? LIMIT 1').bind(value.publicSlug, existing.id).first();
  if (duplicate) return json({ ok: false, error: 'PUBLIC_SLUG_TAKEN' }, 409);
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    UPDATE team_members SET first_name=?, last_name=?, role_kind='owner', role_title=?, phone_uz=?, phone_sa=?, telegram=?, whatsapp=?, instagram=?, bio=?, public_slug=?, public_visible=?, active=1, is_owner=1, updated_at=? WHERE id=?
  `).bind(value.firstName, value.lastName, value.roleTitle, value.phoneUZ, value.phoneSA, value.telegram, value.whatsapp, value.instagram, value.bio, value.publicSlug, value.publicVisible ? 1 : 0, now, existing.id).run();
  return businessProfileMe(env, user);
}

async function adminTeam(env) {
  const result = await env.HOTELS_DB.prepare('SELECT * FROM team_members ORDER BY is_owner DESC, sort_order ASC, last_name COLLATE NOCASE, first_name COLLATE NOCASE').all();
  return json({ ok: true, members: (result.results || []).map(row => mapTeamMember(row, true)) });
}

async function adminTeamMember(env, memberID) {
  const row = await env.HOTELS_DB.prepare('SELECT * FROM team_members WHERE id=?').bind(memberID).first();
  if (!row) return json({ ok: false, error: 'TEAM_MEMBER_NOT_FOUND' }, 404);
  return json({ ok: true, member: mapTeamMember(row, true) });
}

async function createTeamMember(request, env) {
  const payload = await request.json().catch(() => null);
  if (!payload) return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const value = teamMemberPayload(payload);
  if (!value.firstName && !value.lastName) return json({ ok: false, error: 'NAME_REQUIRED' }, 400);
  const duplicate = await env.HOTELS_DB.prepare('SELECT id FROM team_members WHERE public_slug=? LIMIT 1').bind(value.publicSlug).first();
  if (duplicate) return json({ ok: false, error: 'PUBLIC_SLUG_TAKEN' }, 409);
  const id = `team-${crypto.randomUUID()}`;
  const now = new Date().toISOString();
  const max = await env.HOTELS_DB.prepare('SELECT COALESCE(MAX(sort_order), 0) AS max_order FROM team_members').first();
  await env.HOTELS_DB.prepare(`
    INSERT INTO team_members (id, first_name, last_name, role_kind, role_title, phone_uz, phone_sa, telegram, whatsapp, instagram, bio, public_slug, public_visible, active, is_owner, sort_order, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)
  `).bind(id, value.firstName, value.lastName, value.roleKind, value.roleTitle, value.phoneUZ, value.phoneSA, value.telegram, value.whatsapp, value.instagram, value.bio, value.publicSlug, value.publicVisible ? 1 : 0, value.active ? 1 : 0, Number(max?.max_order || 0) + 1, now, now).run();
  return adminTeamMember(env, id);
}

async function updateTeamMember(request, env, memberID) {
  const row = await env.HOTELS_DB.prepare('SELECT * FROM team_members WHERE id=?').bind(memberID).first();
  if (!row) return json({ ok: false, error: 'TEAM_MEMBER_NOT_FOUND' }, 404);
  const payload = await request.json().catch(() => null);
  if (!payload) return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const value = teamMemberPayload(payload, mapTeamMember(row, true));
  const duplicate = await env.HOTELS_DB.prepare('SELECT id FROM team_members WHERE public_slug=? AND id<>? LIMIT 1').bind(value.publicSlug, memberID).first();
  if (duplicate) return json({ ok: false, error: 'PUBLIC_SLUG_TAKEN' }, 409);
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    UPDATE team_members SET first_name=?, last_name=?, role_kind=?, role_title=?, phone_uz=?, phone_sa=?, telegram=?, whatsapp=?, instagram=?, bio=?, public_slug=?, public_visible=?, active=?, updated_at=? WHERE id=?
  `).bind(value.firstName, value.lastName, row.is_owner ? 'owner' : value.roleKind, value.roleTitle, value.phoneUZ, value.phoneSA, value.telegram, value.whatsapp, value.instagram, value.bio, value.publicSlug, value.publicVisible ? 1 : 0, value.active ? 1 : 0, now, memberID).run();
  return adminTeamMember(env, memberID);
}


async function deleteTeamMember(env, memberID) {
  const row = await env.HOTELS_DB.prepare('SELECT is_owner, photo_object_key FROM team_members WHERE id=?').bind(memberID).first();
  if (!row) return json({ ok: true });
  if (Number(row.is_owner || 0) === 1) return json({ ok: false, error: 'OWNER_CANNOT_BE_DELETED' }, 409);
  await env.HOTELS_DB.prepare('DELETE FROM team_members WHERE id=?').bind(memberID).run();
  if (row.photo_object_key) await env.HOTELS_MEDIA.delete(row.photo_object_key).catch(() => {});
  return json({ ok: true });
}

async function uploadTeamMemberPhoto(request, env, memberID) {
  const member = await env.HOTELS_DB.prepare('SELECT id, photo_object_key FROM team_members WHERE id=? LIMIT 1').bind(memberID).first();
  if (!member) return json({ ok: false, error: 'TEAM_MEMBER_NOT_FOUND' }, 404);
  const contentType = String(request.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!['image/jpeg','image/jpg','image/png','image/webp','image/avif'].includes(contentType)) return json({ ok: false, error: 'IMAGE_REQUIRED' }, 415);
  const declaredSize = Number(request.headers.get('content-length') || 0);
  if (declaredSize > 8_000_000) return json({ ok: false, error: 'IMAGE_TOO_LARGE' }, 413);
  const bytes = await request.arrayBuffer();
  if (!bytes.byteLength || bytes.byteLength > 8_000_000) return json({ ok: false, error: 'IMAGE_TOO_LARGE' }, 413);
  let transformed;
  try { transformed = await optimizeHotelImageBytes(env, bytes, { category: 'gallery', isCover: false, sourceContentType: contentType }); }
  catch (error) { return json({ ok: false, error: String(error?.message || 'IMAGE_OPTIMIZATION_FAILED') }, 422); }
  const key = `team/${memberID}/${crypto.randomUUID()}.${transformed.extension || 'webp'}`;
  await env.HOTELS_MEDIA.put(key, transformed.bytes, {
    httpMetadata: { contentType: transformed.contentType, cacheControl: 'private, max-age=86400' },
    customMetadata: { memberID, source: 'iumrah-business' }
  });
  const previous = member.photo_object_key || null;
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare('UPDATE team_members SET photo_object_key=?, photo_content_type=?, updated_at=? WHERE id=?')
    .bind(key, transformed.contentType, now, memberID).run();
  if (previous && previous !== key) await env.HOTELS_MEDIA.delete(previous).catch(() => {});
  return adminTeamMember(env, memberID);
}

async function deleteTeamMemberPhoto(env, memberID) {
  const member = await env.HOTELS_DB.prepare('SELECT id, photo_object_key FROM team_members WHERE id=? LIMIT 1').bind(memberID).first();
  if (!member) return json({ ok: false, error: 'TEAM_MEMBER_NOT_FOUND' }, 404);
  const previous = member.photo_object_key || null;
  await env.HOTELS_DB.prepare('UPDATE team_members SET photo_object_key=NULL, photo_content_type=NULL, updated_at=? WHERE id=?')
    .bind(new Date().toISOString(), memberID).run();
  if (previous) await env.HOTELS_MEDIA.delete(previous).catch(() => {});
  return adminTeamMember(env, memberID);
}

async function serveTeamMemberPhoto(env, memberID) {
  const safeMemberID = safeID(memberID);
  if (!safeMemberID) return json({ ok: false, error: 'INVALID_TEAM_MEMBER_ID' }, 400);
  const row = await env.HOTELS_DB.prepare('SELECT photo_object_key, photo_content_type FROM team_members WHERE id=? AND active=1 LIMIT 1').bind(safeMemberID).first();
  if (!row?.photo_object_key) return json({ ok: false, error: 'PHOTO_NOT_FOUND' }, 404);
  const object = await env.HOTELS_MEDIA.get(row.photo_object_key);
  if (!object) return json({ ok: false, error: 'PHOTO_NOT_FOUND' }, 404);
  const headers = new Headers();
  headers.set('content-type', row.photo_content_type || 'image/webp');
  headers.set('cache-control', 'public, max-age=3600, s-maxage=86400');
  return new Response(object.body, { status: 200, headers });
}

async function publicTeam(env, parts) {
  if (parts.length === 0) {
    const result = await env.HOTELS_DB.prepare(`SELECT * FROM team_members WHERE active=1 AND public_visible=1 ORDER BY is_owner DESC, sort_order ASC, last_name COLLATE NOCASE, first_name COLLATE NOCASE`).all();
    return json({ ok: true, members: (result.results || []).map(row => mapTeamMember(row, false)) }, 200, PUBLIC_CACHE_HEADERS);
  }
  const slug = cleanText(parts[0], 120);
  if (!slug) return json({ ok: false, error: 'INVALID_PROFILE' }, 400);
  const row = await env.HOTELS_DB.prepare('SELECT * FROM team_members WHERE public_slug=? AND active=1 AND public_visible=1 LIMIT 1').bind(slug).first();
  if (!row) return json({ ok: false, error: 'PROFILE_NOT_FOUND' }, 404);
  return json({ ok: true, member: mapTeamMember(row, false) }, 200, PUBLIC_CACHE_HEADERS);
}

async function fetchUpstreamBookings(request, env) {
  const cookie = request.headers.get('cookie') || '';
  const response = await fetch(env.BOOKINGS_ADMIN_URL || 'https://iumrah.app/api/admin/bookings', {
    method: 'GET',
    headers: {
      'cookie': cookie,
      'accept': 'application/json',
      'user-agent': request.headers.get('user-agent') || 'iumrah-business'
    },
    redirect: 'manual'
  });
  if (!response.ok) throw new Error(`BOOKINGS_UPSTREAM_${response.status}`);
  const payload = await response.json().catch(() => null);
  return Array.isArray(payload?.bookings) ? payload.bookings : [];
}

function deepScalar(root, candidates) {
  const wanted = new Set(candidates.map(value => value.toLowerCase()));
  const queue = [{ value: root, depth: 0 }];
  const seen = new Set();
  while (queue.length) {
    const { value, depth } = queue.shift();
    if (!value || typeof value !== 'object' || depth > 4 || seen.has(value)) continue;
    seen.add(value);
    for (const [key, child] of Object.entries(value)) {
      if (wanted.has(key.toLowerCase()) && (typeof child === 'string' || typeof child === 'number')) {
        const text = String(child).trim();
        if (text) return text;
      }
    }
    for (const child of Object.values(value)) {
      if (child && typeof child === 'object') queue.push({ value: child, depth: depth + 1 });
    }
  }
  return '';
}


function bookingIdentity(raw, bookingID) {
  const clientUserID = deepScalar(raw, ['clientUserID','client_user_id','userID','userId','profileID','profileId','accountID','accountId','iumrahClientID','iumrah_client_id']);
  const firstName = deepScalar(raw, ['firstName','first_name','givenName']);
  const lastName = deepScalar(raw, ['lastName','last_name','familyName','surname']);
  const explicitName = deepScalar(raw, ['clientName','customerName','travelerName','travellerName','fullName','displayName']);
  const email = deepScalar(raw, ['email','emailAddress']);
  const whatsapp = deepScalar(raw, ['whatsapp','whatsApp','pilgrimWhatsapp']);
  const telegram = deepScalar(raw, ['telegram','telegramUsername','pilgrimTelegram']);
  const phone = deepScalar(raw, ['phone','phoneNumber','mobile']) || whatsapp;
  const displayName = [firstName, lastName].filter(Boolean).join(' ').trim() || explicitName || `Паломник ${bookingID}`;
  return { clientUserID, firstName, lastName, displayName, email, phone, telegram, whatsapp };
}

function extractPricingSnapshot(raw) {
  const candidates = ['pricingSnapshot','pricing_snapshot','pricing','priceBreakdown','pricingBreakdown','costBreakdown','generationReport','packagePricing','quote'];
  for (const key of candidates) {
    if (raw && typeof raw === 'object' && raw[key] && typeof raw[key] === 'object') return raw[key];
  }
  return {};
}

function tripStatusFromBooking(raw) {
  const rawStatus = String(raw?.status || '').toUpperCase();
  const map = {
    NEW: 'new', AVAILABILITY_CHECK: 'availability_check', PAYMENT_PENDING: 'payment_pending', PAID: 'paid',
    BOOKING_CONFIRMED: 'booking_confirmed', DOCUMENTS_READY: 'documents_ready', READY_TO_TRAVEL: 'ready_to_travel',
    IN_TRIP: 'in_trip', COMPLETED: 'completed', CANCELLED: 'cancelled'
  };
  return map[rawStatus] || 'new';
}


async function mergeLegacyPilgrimDuplicates(env, canonical) {
  const stableID = cleanText(canonical?.client_user_id, 180) || '';
  if (!canonical?.id || !stableID || stableID.startsWith('legacy-booking:')) return;
  const candidates = [];
  if (canonical.whatsapp) candidates.push(['whatsapp=?', canonical.whatsapp]);
  if (canonical.telegram) candidates.push(['LOWER(telegram)=LOWER(?)', canonical.telegram]);
  if (canonical.email) candidates.push(['LOWER(email)=LOWER(?)', canonical.email]);
  if (canonical.phone) candidates.push(['phone=?', canonical.phone]);
  const duplicateIDs = new Set();
  for (const [where, value] of candidates) {
    const result = await env.HOTELS_DB.prepare(`SELECT id, client_user_id FROM pilgrims WHERE id<>? AND ${where}`).bind(canonical.id, value).all().catch(() => ({ results: [] }));
    for (const row of result.results || []) {
      const oldID = cleanText(row?.client_user_id, 180) || '';
      if (!oldID || oldID.startsWith('legacy-booking:')) duplicateIDs.add(Number(row.id));
    }
  }
  for (const duplicateID of duplicateIDs) {
    await env.HOTELS_DB.prepare('UPDATE pilgrim_trips SET pilgrim_id=?, client_user_id=? WHERE pilgrim_id=?').bind(canonical.id, stableID, duplicateID).run();
    await env.HOTELS_DB.prepare('DELETE FROM pilgrims WHERE id=?').bind(duplicateID).run();
  }
}

async function ensurePilgrim(env, identity, bookingID) {
  let row = null;
  if (identity.clientUserID) row = await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE client_user_id=? LIMIT 1').bind(identity.clientUserID).first();
  if (!row && identity.whatsapp) row = await env.HOTELS_DB.prepare("SELECT * FROM pilgrims WHERE whatsapp=? AND whatsapp<>'' LIMIT 1").bind(identity.whatsapp).first();
  if (!row && identity.telegram) row = await env.HOTELS_DB.prepare("SELECT * FROM pilgrims WHERE LOWER(telegram)=LOWER(?) AND telegram<>'' LIMIT 1").bind(identity.telegram).first();
  if (!row && identity.email) row = await env.HOTELS_DB.prepare("SELECT * FROM pilgrims WHERE LOWER(email)=LOWER(?) AND email<>'' LIMIT 1").bind(identity.email).first();
  if (!row && identity.phone) row = await env.HOTELS_DB.prepare("SELECT * FROM pilgrims WHERE phone=? AND phone<>'' LIMIT 1").bind(identity.phone).first();
  if (!row) {
    const fallbackUserID = identity.clientUserID || `legacy-booking:${bookingID}`;
    const now = new Date().toISOString();
    const result = await env.HOTELS_DB.prepare(`INSERT INTO pilgrims (client_user_id, first_name, last_name, display_name, phone, email, telegram, whatsapp, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(fallbackUserID, identity.firstName, identity.lastName, identity.displayName, identity.phone, identity.email, identity.telegram || '', identity.whatsapp || '', now, now).run();
    const id = Number(result?.meta?.last_row_id || 0);
    row = id ? await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE id=?').bind(id).first() : await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE client_user_id=?').bind(fallbackUserID).first();
  } else {
    const now = new Date().toISOString();
    const existingClientID = cleanText(row.client_user_id, 180) || '';
    const stableID = identity.clientUserID && (!existingClientID || existingClientID.startsWith('legacy-booking:')) ? identity.clientUserID : existingClientID;
    await env.HOTELS_DB.prepare(`UPDATE pilgrims SET client_user_id=CASE WHEN ?<>'' THEN ? ELSE client_user_id END, first_name=CASE WHEN ?<>'' THEN ? ELSE first_name END, last_name=CASE WHEN ?<>'' THEN ? ELSE last_name END, display_name=CASE WHEN ?<>'' THEN ? ELSE display_name END, phone=CASE WHEN ?<>'' THEN ? ELSE phone END, email=CASE WHEN ?<>'' THEN ? ELSE email END, telegram=CASE WHEN ?<>'' THEN ? ELSE telegram END, whatsapp=CASE WHEN ?<>'' THEN ? ELSE whatsapp END, updated_at=? WHERE id=?`)
      .bind(stableID, stableID, identity.firstName, identity.firstName, identity.lastName, identity.lastName, identity.displayName, identity.displayName, identity.phone, identity.phone, identity.email, identity.email, identity.telegram || '', identity.telegram || '', identity.whatsapp || '', identity.whatsapp || '', now, row.id).run();
    row = await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE id=?').bind(row.id).first();
  }
  if (row) {
    await mergeLegacyPilgrimDuplicates(env, row);
    row = await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE id=?').bind(row.id).first();
  }
  return row;
}

function pilgrimPublicID(id) {
  return `IUMRAH-${String(Number(id || 0)).padStart(6, '0')}`;
}

function tripMap(row) {
  if (!row) return null;
  return {
    tripID: row.id,
    bookingID: row.booking_id,
    pilgrimID: pilgrimPublicID(row.pilgrim_id),
    status: row.status,
    paymentStatus: row.payment_status || '',
    confirmationNumber: row.confirmation_number || '',
    internalNotes: row.internal_notes || '',
    startDate: row.start_date || null,
    endDate: row.end_date || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    completedAt: row.completed_at || null
  };
}


async function syncBookingTrip(env, raw) {
  const bookingID = cleanText(raw?.id, 180);
  if (!bookingID) return null;
  const existing = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first();
  const identity = bookingIdentity(raw, bookingID);
  if (!identity.clientUserID && existing?.client_user_id) identity.clientUserID = String(existing.client_user_id);
  if (existing?.pilgrim_id) {
    const currentPilgrim = await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE id=? LIMIT 1').bind(existing.pilgrim_id).first().catch(() => null);
    if (currentPilgrim) {
      identity.firstName ||= currentPilgrim.first_name || '';
      identity.lastName ||= currentPilgrim.last_name || '';
      identity.displayName = (identity.displayName && !identity.displayName.startsWith('Паломник ')) ? identity.displayName : (currentPilgrim.display_name || identity.displayName);
      identity.email ||= currentPilgrim.email || '';
      identity.phone ||= currentPilgrim.phone || '';
      identity.telegram ||= currentPilgrim.telegram || '';
      identity.whatsapp ||= currentPilgrim.whatsapp || '';
    }
  }
  const pilgrim = await ensurePilgrim(env, identity, bookingID);
  if (!pilgrim) return null;
  const created = !existing;
  const previousPilgrimID = existing?.pilgrim_id || null;
  const now = new Date().toISOString();
  const pricing = extractPricingSnapshot(raw);
  const startDate = cleanText(raw?.startDate, 64);
  const endDate = cleanText(raw?.endDate, 64);
  const stableClientID = identity.clientUserID || pilgrim.client_user_id || null;
  if (!existing) {
    const tripID = `trip-${crypto.randomUUID()}`;
    await env.HOTELS_DB.prepare(`
      INSERT INTO pilgrim_trips (id, booking_id, pilgrim_id, client_user_id, status, start_date, end_date, booking_snapshot_json, pricing_snapshot_json, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(tripID, bookingID, pilgrim.id, stableClientID, tripStatusFromBooking(raw), startDate, endDate, JSON.stringify(raw), JSON.stringify(pricing), now, now).run();
  } else {
    const previousBooking = parseJSONObject(existing.booking_snapshot_json);
    const mergedBooking = { ...previousBooking, ...raw };
    const hasPricing = pricing && typeof pricing === 'object' && Object.keys(pricing).length > 0;
    const pricingJSON = hasPricing ? JSON.stringify(pricing) : (existing.pricing_snapshot_json || '{}');
    await env.HOTELS_DB.prepare(`UPDATE pilgrim_trips SET pilgrim_id=?, client_user_id=COALESCE(?, client_user_id), start_date=COALESCE(?, start_date), end_date=COALESCE(?, end_date), booking_snapshot_json=?, pricing_snapshot_json=?, updated_at=? WHERE booking_id=?`)
      .bind(pilgrim.id, stableClientID, startDate, endDate, JSON.stringify(mergedBooking), pricingJSON, now, bookingID).run();
  }
  const trip = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE booking_id=?').bind(bookingID).first();
  const stats = await env.HOTELS_DB.prepare('SELECT COUNT(*) AS count, MAX(COALESCE(end_date, created_at)) AS last_trip FROM pilgrim_trips WHERE pilgrim_id=?').bind(pilgrim.id).first();
  await env.HOTELS_DB.prepare('UPDATE pilgrims SET total_trips=?, last_trip_at=?, updated_at=? WHERE id=?')
    .bind(Number(stats?.count || 0), stats?.last_trip || null, now, pilgrim.id).run();
  if (previousPilgrimID && Number(previousPilgrimID) !== Number(pilgrim.id)) await cleanupPilgrimAfterTripDelete(env, previousPilgrimID, null);
  return { pilgrim, trip, created };
}

function augmentBooking(raw, linked) {
  const identity = bookingIdentity(raw, raw?.id || '');
  return {
    ...raw,
    clientName: identity.displayName,
    pilgrimID: linked?.pilgrim ? pilgrimPublicID(linked.pilgrim.id) : null,
    tripID: linked?.trip?.id || null,
    operationStatus: linked?.trip?.status || tripStatusFromBooking(raw)
  };
}


async function operationsBookings(request, env) {
  await cleanupLegacyDeletedBookings(env);
  let bookings;
  try { bookings = await fetchUpstreamBookings(request, env); }
  catch (error) { return json({ ok: false, error: String(error?.message || 'BOOKINGS_UNAVAILABLE') }, 502); }
  const source = bookings.slice(0, 500);
  const output = new Array(source.length);
  const chunkSize = 8;
  for (let offset = 0; offset < source.length; offset += chunkSize) {
    const chunk = source.slice(offset, offset + chunkSize);
    const linkedChunk = await Promise.all(chunk.map(async raw => {
      try {
        const linked = await syncBookingTrip(env, raw);
        if (linked) await notifyNewBookingIfNeeded(env, String(raw?.id || ''), raw, linked).catch(() => {});
        return linked;
      } catch (error) {
        console.warn('BOOKING_SYNC_FAILED', raw?.id, error);
        return null;
      }
    }));
    chunk.forEach((raw, index) => { output[offset + index] = augmentBooking(raw, linkedChunk[index]); });
  }
  return json({ bookings: output });
}

function humanizeFieldKey(value) {
  return String(value || '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^./, char => char.toUpperCase());
}

function flattenPricingLines(value) {
  const lines = [];
  const currency = deepScalar(value, ['currency','currencyCode']) || 'USD';
  const walk = (node, path = [], depth = 0) => {
    if (depth > 5 || lines.length >= 120 || node == null) return;
    if (typeof node === 'number' && Number.isFinite(node)) {
      const key = path.join('.');
      if (/(price|cost|fee|commission|margin|visa|hotel|flight|air|guide|transfer|transport|sim|support|total|amount|service)/i.test(key) && !/(count|guests|traveler|rooms|nights|days|year)/i.test(key)) {
        lines.push({ id: key || `value-${lines.length}`, label: humanizeFieldKey(path[path.length - 1] || 'Amount'), group: humanizeFieldKey(path.slice(0, -1).join(' · ') || 'Pricing'), amount: node, currency });
      }
      return;
    }
    if (Array.isArray(node)) {
      node.forEach((child, index) => walk(child, [...path, String(index + 1)], depth + 1));
      return;
    }
    if (typeof node === 'object') Object.entries(node).forEach(([key, child]) => walk(child, [...path, key], depth + 1));
  };
  walk(value);
  return lines;
}

function flattenRequestFields(raw) {
  const fields = [];
  const skip = /(^|\.)(pricing|priceBreakdown|pricingBreakdown|costBreakdown|generationReport|quote)(\.|$)/i;
  const walk = (node, path = [], depth = 0) => {
    if (depth > 4 || fields.length >= 120 || node == null) return;
    if (typeof node === 'string' || typeof node === 'number' || typeof node === 'boolean') {
      const keyPath = path.join('.');
      if (!skip.test(keyPath) && String(node).trim() !== '') fields.push({ id: keyPath, label: humanizeFieldKey(path[path.length - 1] || 'Value'), group: humanizeFieldKey(path.slice(0, -1).join(' · ') || 'Booking'), value: String(node) });
      return;
    }
    if (Array.isArray(node)) {
      node.slice(0, 20).forEach((child, index) => walk(child, [...path, String(index + 1)], depth + 1));
      return;
    }
    if (typeof node === 'object') Object.entries(node).forEach(([key, child]) => walk(child, [...path, key], depth + 1));
  };
  walk(raw);
  return fields;
}

async function rawBookingForDetail(request, env, bookingID) {
  const trip = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first();
  try {
    const bookings = await fetchUpstreamBookings(request, env);
    const raw = bookings.find(item => String(item?.id || '') === bookingID);
    if (raw) return { raw, linked: await syncBookingTrip(env, raw) };
  } catch (error) {
    console.warn('BOOKING_DETAIL_UPSTREAM_FALLBACK', error);
  }
  if (trip) {
    const raw = parseJSONObject(trip.booking_snapshot_json);
    const pilgrim = await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE id=?').bind(trip.pilgrim_id).first();
    return { raw, linked: { trip, pilgrim } };
  }
  return null;
}

async function operationsBookingDetail(request, env, bookingID) {
  const resolved = await rawBookingForDetail(request, env, bookingID);
  if (!resolved) return json({ ok: false, error: 'BOOKING_NOT_FOUND' }, 404);
  const trip = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE booking_id=?').bind(bookingID).first();
  const pilgrim = trip ? await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE id=?').bind(trip.pilgrim_id).first() : null;
  const pricingSnapshot = trip ? parseJSONObject(trip.pricing_snapshot_json) : extractPricingSnapshot(resolved.raw);
  let pricingLines = flattenPricingLines(pricingSnapshot);
  if (!pricingLines.length) pricingLines = flattenPricingLines(resolved.raw);
  const [history, flightRows, assignment] = await Promise.all([
    env.HOTELS_DB.prepare('SELECT old_status, new_status, changed_by, created_at FROM booking_status_history WHERE booking_id=? ORDER BY created_at DESC LIMIT 50').bind(bookingID).all(),
    env.HOTELS_DB.prepare("SELECT * FROM trip_flights WHERE booking_id=? ORDER BY CASE direction WHEN 'outbound' THEN 0 ELSE 1 END").bind(bookingID).all(),
    bookingAssignmentDetail(env, bookingID)
  ]);
  return json({
    ok: true,
    booking: augmentBooking(resolved.raw, { trip, pilgrim }),
    operation: tripMap(trip),
    pilgrim: pilgrim ? { id: pilgrimPublicID(pilgrim.id), displayName: pilgrim.display_name || '', firstName: pilgrim.first_name || '', lastName: pilgrim.last_name || '', phone: pilgrim.phone || '', email: pilgrim.email || '', totalTrips: Number(pilgrim.total_trips || 0) } : null,
    pricingLines,
    requestFields: flattenRequestFields(resolved.raw),
    statusHistory: (history.results || []).map(row => ({ oldStatus: row.old_status || null, newStatus: row.new_status, changedBy: row.changed_by || null, createdAt: row.created_at })),
    flights: (flightRows.results || []).map(mapTripFlight),
    assignment
  });
}

async function updateOperationsBooking(request, env, bookingID, user) {
  const trip = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE booking_id=?').bind(bookingID).first();
  if (!trip) return json({ ok: false, error: 'BOOKING_NOT_SYNCED' }, 404);
  const payload = await request.json().catch(() => null);
  if (!payload) return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const nextStatus = cleanText(payload?.status, 80) || trip.status;
  if (!TRIP_STATUSES.has(nextStatus)) return json({ ok: false, error: 'INVALID_TRIP_STATUS' }, 400);
  const paymentStatus = safeHumanText(payload?.paymentStatus ?? trip.payment_status ?? '', 160) || '';
  const confirmationNumber = safeHumanText(payload?.confirmationNumber ?? trip.confirmation_number ?? '', 200) || '';
  const internalNotes = safeHumanText(payload?.internalNotes ?? trip.internal_notes ?? '', 4000) || '';
  const now = new Date().toISOString();
  const completedAt = nextStatus === 'completed' ? (trip.completed_at || now) : null;
  const statements = [env.HOTELS_DB.prepare(`UPDATE pilgrim_trips SET status=?, payment_status=?, confirmation_number=?, internal_notes=?, completed_at=?, updated_at=? WHERE booking_id=?`).bind(nextStatus, paymentStatus, confirmationNumber, internalNotes, completedAt, now, bookingID)];
  if (nextStatus !== trip.status) {
    statements.push(env.HOTELS_DB.prepare('INSERT INTO booking_status_history (id, booking_id, old_status, new_status, changed_by, created_at) VALUES (?, ?, ?, ?, ?, ?)').bind(crypto.randomUUID(), bookingID, trip.status, nextStatus, cleanText(user?.login, 180), now));
  }
  await env.HOTELS_DB.batch(statements);
  return operationsBookingDetail(request, env, bookingID);
}

async function listPilgrims(env, url) {
  const archiveOnly = url.searchParams.get('archive') === '1';
  const search = cleanText(url.searchParams.get('q'), 120);
  const where = [];
  const values = [];
  if (archiveOnly) where.push("EXISTS (SELECT 1 FROM pilgrim_trips t WHERE t.pilgrim_id=p.id AND t.status='completed')");
  if (search) {
    where.push("(LOWER(p.display_name) LIKE LOWER(?) OR LOWER(p.email) LIKE LOWER(?) OR p.phone LIKE ?)");
    const q = `%${search}%`; values.push(q,q,q);
  }
  const result = await env.HOTELS_DB.prepare(`
    SELECT p.*, (SELECT COUNT(*) FROM pilgrim_trips t WHERE t.pilgrim_id=p.id AND t.status='completed') AS completed_trips
    FROM pilgrims p ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY COALESCE(p.last_trip_at,p.updated_at) DESC LIMIT 500
  `).bind(...values).all();
  return json({ ok: true, pilgrims: (result.results || []).map(row => ({ id: pilgrimPublicID(row.id), displayName: row.display_name || '', firstName: row.first_name || '', lastName: row.last_name || '', phone: row.phone || '', email: row.email || '', totalTrips: Number(row.total_trips || 0), completedTrips: Number(row.completed_trips || 0), lastTripAt: row.last_trip_at || null })) });
}

function parsePilgrimPublicID(value) {
  const match = String(value || '').match(/^PILGRIM-(\d{1,12})$/i);
  return match ? Number(match[1]) : null;
}

async function pilgrimDetail(env, publicID) {
  const numericID = parsePilgrimPublicID(publicID);
  if (!numericID) return json({ ok: false, error: 'INVALID_PILGRIM_ID' }, 400);
  const pilgrim = await env.HOTELS_DB.prepare('SELECT * FROM pilgrims WHERE id=?').bind(numericID).first();
  if (!pilgrim) return json({ ok: false, error: 'PILGRIM_NOT_FOUND' }, 404);
  const trips = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE pilgrim_id=? ORDER BY created_at DESC').bind(numericID).all();
  return json({ ok: true, pilgrim: { id: pilgrimPublicID(pilgrim.id), displayName: pilgrim.display_name || '', firstName: pilgrim.first_name || '', lastName: pilgrim.last_name || '', phone: pilgrim.phone || '', email: pilgrim.email || '', totalTrips: Number(pilgrim.total_trips || 0), lastTripAt: pilgrim.last_trip_at || null }, trips: (trips.results || []).map(tripMap) });
}

async function adminPrimaryHotels(env, url) {
  const city = cleanText(url.searchParams.get('city'), 80);
  const values = [];
  const where = [];
  if (city) { where.push('LOWER(p.city)=LOWER(?)'); values.push(city); }
  const result = await env.HOTELS_DB.prepare(`
    SELECT p.city, p.star_category, p.position, h.id, h.name, h.stars, h.rating, h.review_count, h.status, h.lifecycle_state, h.updated_at,
      (SELECT COUNT(*) FROM hotel_images hi WHERE hi.hotel_id=h.id) AS image_count,
      (SELECT COUNT(*) FROM hotel_rooms hr WHERE hr.hotel_id=h.id) AS room_count,
      (SELECT hi.id FROM hotel_images hi WHERE hi.hotel_id=h.id ORDER BY hi.is_cover DESC, hi.position ASC LIMIT 1) AS cover_image_id
    FROM primary_hotels p JOIN hotels h ON h.id=p.hotel_id
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY p.city, p.star_category, p.position
  `).bind(...values).all();
  return json({ ok: true, assignments: (result.results || []).map(row => ({ city: row.city, stars: Number(row.star_category), position: Number(row.position), hotel: hotelSummary(row) })) });
}

async function savePrimaryHotels(request, env) {
  const payload = await request.json().catch(() => null);
  const city = safeHumanText(payload?.city, 80);
  const stars = Number(payload?.stars);
  const hotelIDs = Array.isArray(payload?.hotelIDs) ? [...new Set(payload.hotelIDs.map(value => safeID(value)).filter(Boolean))].slice(0,3) : [];
  if (!city || !Number.isInteger(stars) || stars < 1 || stars > 5) return json({ ok: false, error: 'INVALID_PRIMARY_CATEGORY' }, 400);
  const valid = [];
  for (const id of hotelIDs) {
    const hotel = await env.HOTELS_DB.prepare("SELECT id, city FROM hotels WHERE id=? AND status='published' LIMIT 1").bind(id).first();
    if (!hotel) return json({ ok: false, error: `HOTEL_NOT_PUBLISHED:${id}` }, 409);
    if (String(hotel.city || '').toLowerCase() !== city.toLowerCase()) return json({ ok: false, error: `HOTEL_CITY_MISMATCH:${id}` }, 409);
    valid.push(id);
  }
  const statements = [env.HOTELS_DB.prepare('DELETE FROM primary_hotels WHERE LOWER(city)=LOWER(?) AND star_category=?').bind(city, stars)];
  const now = new Date().toISOString();
  valid.forEach((id, index) => statements.push(env.HOTELS_DB.prepare('INSERT INTO primary_hotels (city, star_category, position, hotel_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)').bind(city, stars, index + 1, id, now, now)));
  await env.HOTELS_DB.batch(statements);
  return adminPrimaryHotels(env, new URL(`https://iumrah.app/api/admin/hotels/operations/primary-hotels?city=${encodeURIComponent(city)}`));
}

async function publicPrimaryHotels(env, url) {
  const city = safeHumanText(url.searchParams.get('city'), 80);
  const stars = Number(url.searchParams.get('stars'));
  if (!city || !Number.isInteger(stars) || stars < 1 || stars > 5) return json({ ok: false, error: 'CITY_AND_STARS_REQUIRED' }, 400);
  const result = await env.HOTELS_DB.prepare(`
    SELECT p.position, h.id, h.name, h.city, h.stars, h.rating, h.review_count, h.status, h.lifecycle_state, h.updated_at,
      (SELECT COUNT(*) FROM hotel_images hi WHERE hi.hotel_id=h.id) AS image_count,
      (SELECT COUNT(*) FROM hotel_rooms hr WHERE hr.hotel_id=h.id) AS room_count,
      (SELECT hi.id FROM hotel_images hi WHERE hi.hotel_id=h.id ORDER BY hi.is_cover DESC, hi.position ASC LIMIT 1) AS cover_image_id
    FROM primary_hotels p JOIN hotels h ON h.id=p.hotel_id
    WHERE LOWER(p.city)=LOWER(?) AND p.star_category=? AND h.status='published'
    ORDER BY p.position ASC
  `).bind(city, stars).all();
  return json({ ok: true, city, stars, recommendationLabel: 'Рекомендует iumrah', hotels: (result.results || []).map(row => ({ ...hotelSummary(row), primaryPosition: Number(row.position) })) }, 200, PUBLIC_CACHE_HEADERS);
}


async function handleClientOperations(request, env, parts) {
  if (parts[0] === 'bookings') {
    const bookingID = cleanText(parts[1], 180);
    if (!bookingID) return json({ ok: false, error: 'INVALID_BOOKING_ID' }, 400);
    if (parts.length === 3 && parts[2] === 'sync' && request.method === 'POST') return syncClientBookingByToken(request, env, bookingID);
    if (parts.length === 3 && parts[2] === 'push' && request.method === 'POST') return registerClientPushDevice(request, env, bookingID);
    if (parts.length === 2 && request.method === 'DELETE') {
      const auth = await authorizedBookingByToken(request, env, bookingID);
      if (!auth.ok) {
        const exists = env.BOOKINGS_DB ? await env.BOOKINGS_DB.prepare('SELECT id FROM bookings WHERE id=? LIMIT 1').bind(bookingID).first().catch(() => null) : null;
        if (exists) return auth.response;
        const trip = await env.HOTELS_DB.prepare('SELECT client_user_id FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first().catch(() => null);
        if (trip) {
          const stableID = clientIdentityHeader(request);
          if (!stableID || String(trip.client_user_id || '') !== stableID) return auth.response;
        } else {
          return json({ ok: true, deleted: true, deletedBookingID: bookingID });
        }
      }
      const result = await hardDeleteBooking(env, bookingID);
      if (!result.ok) return result.response;
      return json({ ok: true, deleted: true, deletedBookingID: bookingID });
    }
    return methodNotAllowed();
  }

  if (parts[0] === 'trips') {
    const auth = await requireClientSession(request, env);
    if (!auth.ok) return auth.response;
    if (parts.length === 2 && parts[1] === 'sync' && request.method === 'POST') return syncClientTrip(request, env, auth.user);
    if (parts.length === 1 && request.method === 'GET') return listClientTrips(env, auth.user.id);
    const bookingID = cleanText(parts[1], 180);
    if (parts.length === 2 && bookingID && request.method === 'GET') {
      const access = await authorizeClientTrip(env, bookingID, auth.user.id);
      if (!access.ok) return access.response;
      return json({ ok: true, trip: tripMap(access.trip) });
    }
    return methodNotAllowed();
  }

  if (parts[0] !== 'chats') return json({ ok: false, error: 'NOT_FOUND' }, 404);
  const bookingID = cleanText(parts[1], 180);
  if (!bookingID) return json({ ok: false, error: 'INVALID_BOOKING_ID' }, 400);
  const auth = await requireClientBooking(request, env, bookingID);
  if (!auth.ok) return auth.response;
  if (parts.length === 3 && parts[2] === 'messages') {
    if (request.method === 'GET') return chatMessages(env, bookingID, false);
    if (request.method === 'POST') return sendClientChatMessage(request, env, bookingID, auth.user);
  }
  if (parts.length === 3 && parts[2] === 'attachments' && request.method === 'POST') return sendChatAttachment(request, env, bookingID, auth.user, false);
  if (parts.length === 3 && parts[2] === 'read' && request.method === 'POST') return markClientChatRead(env, bookingID);
  if (parts.length === 4 && parts[2] === 'media' && request.method === 'GET') return serveChatAttachment(env, bookingID, parts[3]);
  return methodNotAllowed();
}

async function requireClientSession(request, env) {
  const cookie = request.headers.get('cookie') || '';
  const authorization = request.headers.get('authorization') || '';
  if (!cookie && !authorization) return { ok: false, response: json({ ok: false, error: 'UNAUTHORIZED' }, 401) };
  let response;
  try {
    response = await fetch(env.CLIENT_SESSION_URL || 'https://iumrah.app/api/auth/session', {
      method: 'GET',
      headers: { 'cookie': cookie, 'authorization': authorization, 'accept': 'application/json', 'user-agent': request.headers.get('user-agent') || 'iumrah-client' },
      redirect: 'manual'
    });
  } catch {
    return { ok: false, response: json({ ok: false, error: 'CLIENT_AUTH_UNAVAILABLE' }, 503) };
  }
  if (!response.ok) return { ok: false, response: json({ ok: false, error: 'UNAUTHORIZED' }, 401) };
  const payload = await response.json().catch(() => null);
  const user = payload?.user || payload?.profile || payload;
  const userID = cleanText(user?.id || user?.userID || user?.userId, 180);
  if (!userID) return { ok: false, response: json({ ok: false, error: 'CLIENT_ID_MISSING' }, 403) };
  return { ok: true, user: { ...user, id: userID } };
}

async function authorizeClientTrip(env, bookingID, userID) {
  const trip = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE booking_id=? LIMIT 1').bind(bookingID).first();
  if (!trip || String(trip.client_user_id || '') !== userID) return { ok: false, response: json({ ok: false, error: 'BOOKING_ACCESS_DENIED' }, 403) };
  return { ok: true, trip };
}


async function requireClientBooking(request, env, bookingID) {
  if (bookingAccessToken(request)) {
    const access = await authorizedBookingByToken(request, env, bookingID);
    if (!access.ok) return access;
    const stableID = clientIdentityHeader(request) || `legacy-booking:${bookingID}`;
    const raw = { ...access.raw, clientUserID: stableID };
    const linked = await syncBookingTrip(env, raw);
    const displayName = linked?.pilgrim?.display_name || bookingIdentity(raw, bookingID).displayName || 'Паломник';
    return { ok: true, user: { id: stableID, displayName }, trip: linked?.trip, raw };
  }
  const auth = await requireClientSession(request, env);
  if (!auth.ok) return auth;
  const access = await authorizeClientTrip(env, bookingID, auth.user.id);
  if (!access.ok) return access;
  return { ...auth, trip: access.trip };
}

async function listClientTrips(env, userID) {
  const result = await env.HOTELS_DB.prepare('SELECT * FROM pilgrim_trips WHERE client_user_id=? ORDER BY created_at DESC LIMIT 200').bind(userID).all();
  return json({ ok: true, trips: (result.results || []).map(tripMap) });
}


function clientSyncPayload(raw, payload, bookingID, clientUserID) {
  const profile = payload?.pilgrimProfile && typeof payload.pilgrimProfile === 'object' ? payload.pilgrimProfile : {};
  const bookingSnapshot = payload?.bookingSnapshot && typeof payload.bookingSnapshot === 'object' ? payload.bookingSnapshot : {};
  return {
    ...raw,
    ...bookingSnapshot,
    id: bookingID,
    clientUserID,
    firstName: payload?.firstName || profile.firstName || deepScalar(raw, ['firstName','first_name','givenName']),
    lastName: payload?.lastName || profile.lastName || deepScalar(raw, ['lastName','last_name','familyName','surname']),
    displayName: payload?.displayName || profile.displayName || deepScalar(raw, ['clientName','customerName','travelerName','travellerName','fullName','displayName']),
    telegram: payload?.telegram || profile.telegram || deepScalar(raw, ['telegram','telegramUsername','pilgrimTelegram']),
    whatsapp: payload?.whatsapp || profile.whatsapp || deepScalar(raw, ['whatsapp','whatsApp','pilgrimWhatsapp']),
    email: payload?.email || profile.email || deepScalar(raw, ['email','emailAddress']),
    phone: payload?.phone || profile.phone || deepScalar(raw, ['phone','phoneNumber','mobile'])
  };
}

async function syncClientBookingByToken(request, env, bookingID, bodyOverride = null) {
  const access = await authorizedBookingByToken(request, env, bookingID);
  if (!access.ok) return access.response;
  let payload = bodyOverride;
  if (payload == null) {
    const parsed = await readJSON(request, 750_000);
    if (!parsed.ok) return parsed.response;
    payload = parsed.value;
  }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const clientUserID = clientIdentityHeader(request) || cleanText(payload.clientUserID || payload.clientUserId, 180) || `legacy-booking:${bookingID}`;
  const raw = clientSyncPayload(access.raw, payload, bookingID, clientUserID);
  const linked = await syncBookingTrip(env, raw);
  if (!linked?.pilgrim || !linked?.trip) return json({ ok: false, error: 'BOOKING_SYNC_FAILED' }, 500);
  await importLegacyChatForBooking(env, bookingID).catch(() => {});
  await notifyNewBookingIfNeeded(env, bookingID, raw, linked).catch(() => {});
  return json({ ok: true, pilgrimID: pilgrimPublicID(linked.pilgrim.id), iumrahID: pilgrimPublicID(linked.pilgrim.id), trip: tripMap(linked.trip) });
}

async function registerClientPushDevice(request, env, bookingID) {
  const access = await authorizedBookingByToken(request, env, bookingID);
  if (!access.ok) return access.response;
  const parsed = await readJSON(request, 100_000);
  if (!parsed.ok) return parsed.response;
  const payload = parsed.value || {};
  const token = cleanText(payload.deviceToken, 256)?.toLowerCase();
  if (!token || !/^[0-9a-f]{32,256}$/.test(token)) return json({ ok: false, error: 'INVALID_DEVICE_TOKEN' }, 400);
  const clientUserID = clientIdentityHeader(request) || cleanText(payload.clientUserID || payload.clientUserId, 180) || `legacy-booking:${bookingID}`;
  const raw = clientSyncPayload(access.raw, payload, bookingID, clientUserID);
  const linked = await syncBookingTrip(env, raw);
  if (!linked?.pilgrim) return json({ ok: false, error: 'BOOKING_SYNC_FAILED' }, 500);
  const environment = payload?.environment === 'development' ? 'development' : 'production';
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO client_push_devices (device_token, client_user_id, platform, environment, app_bundle_id, enabled, created_at, updated_at, last_error)
    VALUES (?, ?, 'ios', ?, 'com.iumrah.beta', 1, ?, ?, NULL)
    ON CONFLICT(device_token) DO UPDATE SET client_user_id=excluded.client_user_id, platform='ios', environment=excluded.environment,
      app_bundle_id='com.iumrah.beta', enabled=1, updated_at=excluded.updated_at, last_error=NULL
  `).bind(token, clientUserID, environment, now, now).run();
  return json({ ok: true, ready: apnsConfigured(env), pilgrimID: pilgrimPublicID(linked.pilgrim.id), iumrahID: pilgrimPublicID(linked.pilgrim.id) });
}


async function syncClientTrip(request, env, user) {
  const parsed = await readJSON(request, 750_000);
  if (!parsed.ok) return parsed.response;
  const payload = parsed.value;
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return json({ ok: false, error: 'INVALID_JSON' }, 400);
  const bookingID = cleanText(payload.bookingID || payload.bookingId || payload?.bookingSnapshot?.id, 180);
  if (!bookingID) return json({ ok: false, error: 'BOOKING_ID_REQUIRED' }, 400);
  const clientUserID = cleanText(payload.clientUserID || payload.clientUserId || user.id, 180);
  if (!clientUserID || clientUserID !== user.id) return json({ ok: false, error: 'CLIENT_ID_MISMATCH' }, 403);
  const raw = clientSyncPayload(payload.bookingSnapshot || { id: bookingID }, payload, bookingID, clientUserID);
  const linked = await syncBookingTrip(env, raw);
  if (!linked?.pilgrim || !linked?.trip) return json({ ok: false, error: 'BOOKING_SYNC_FAILED' }, 500);
  await notifyNewBookingIfNeeded(env, bookingID, raw, linked).catch(() => {});
  return json({ ok: true, pilgrimID: pilgrimPublicID(linked.pilgrim.id), iumrahID: pilgrimPublicID(linked.pilgrim.id), trip: tripMap(linked.trip) });
}

async function sendClientChatMessage(request, env, bookingID, user) {
  const payload = await request.json().catch(() => null);
  const body = safeHumanText(payload?.body, 4000);
  if (!body) return json({ ok: false, error: 'EMPTY_MESSAGE' }, 400);
  const clientMessageID = safeID(payload?.clientMessageID) || null;
  if (clientMessageID) {
    const existing = await env.HOTELS_DB.prepare('SELECT id FROM business_chat_messages WHERE booking_id=? AND client_message_id=? LIMIT 1').bind(bookingID, clientMessageID).first();
    if (existing?.id) return chatMessageDetail(env, existing.id, 200, false);
  }
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const senderName = safeHumanText(user?.displayName || user?.name || 'Паломник', 160) || 'Паломник';
  await env.HOTELS_DB.batch([
    env.HOTELS_DB.prepare(`INSERT INTO business_chat_threads (booking_id, created_at, updated_at, last_message_at, last_message_preview, last_sender_type, unread_for_staff) VALUES (?, ?, ?, ?, ?, 'client', 1) ON CONFLICT(booking_id) DO UPDATE SET updated_at=excluded.updated_at, last_message_at=excluded.last_message_at, last_message_preview=excluded.last_message_preview, last_sender_type='client', unread_for_staff=1`).bind(bookingID, now, now, now, body.slice(0,240)),
    env.HOTELS_DB.prepare(`INSERT INTO business_chat_messages (id, booking_id, sender_type, sender_name, body, created_at, read_by_staff, client_message_id, message_type) VALUES (?, ?, 'client', ?, ?, ?, 0, ?, 'text')`).bind(id, bookingID, senderName, body, now, clientMessageID)
  ]);
  await sendStaffPush(env, senderName, body.slice(0, 180), { type: 'chat_message', bookingID }).catch(() => {});
  return chatMessageDetail(env, id, 201, false);
}

async function markClientChatRead(env, bookingID) {
  return json({ ok: true });
}

async function sendChatAttachment(request, env, bookingID, user, staff = true) {
  const contentType = String(request.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!contentType.startsWith('image/')) return json({ ok: false, error: 'IMAGE_REQUIRED' }, 415);
  const sourceBytes = await request.arrayBuffer();
  if (!sourceBytes.byteLength || sourceBytes.byteLength > 12_000_000) return json({ ok: false, error: 'IMAGE_TOO_LARGE' }, 413);
  let transformed;
  try { transformed = await optimizeHotelImageBytes(env, sourceBytes, { category: 'gallery', isCover: false, sourceContentType: contentType }); }
  catch (error) { return json({ ok: false, error: String(error?.message || 'IMAGE_OPTIMIZATION_FAILED') }, 422); }
  const attachmentID = crypto.randomUUID();
  const extension = transformed.extension || 'webp';
  const objectKey = `chat/${bookingID}/${attachmentID}.${extension}`;
  await env.HOTELS_MEDIA.put(objectKey, transformed.bytes, { httpMetadata: { contentType: transformed.contentType } });
  const now = new Date().toISOString();
  const messageID = crypto.randomUUID();
  const senderType = staff ? 'staff' : 'client';
  const senderName = staff
    ? await staffDisplayName(env, user)
    : (safeHumanText(user?.displayName || user?.name || 'Паломник', 160) || 'Паломник');
  const preview = 'Фотография';
  try {
    await env.HOTELS_DB.batch([
      env.HOTELS_DB.prepare(`INSERT INTO business_chat_threads (booking_id, created_at, updated_at, last_message_at, last_message_preview, last_sender_type, unread_for_staff) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(booking_id) DO UPDATE SET updated_at=excluded.updated_at, last_message_at=excluded.last_message_at, last_message_preview=excluded.last_message_preview, last_sender_type=excluded.last_sender_type, unread_for_staff=excluded.unread_for_staff`).bind(bookingID, now, now, now, preview, senderType, staff ? 0 : 1),
      env.HOTELS_DB.prepare('INSERT INTO business_chat_attachments (id, booking_id, object_key, content_type, byte_size, width, height, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(attachmentID, bookingID, objectKey, transformed.contentType, transformed.bytes.byteLength, transformed.width, transformed.height, now),
      env.HOTELS_DB.prepare(`INSERT INTO business_chat_messages (id, booking_id, sender_type, sender_name, body, created_at, read_by_staff, message_type, attachment_id) VALUES (?, ?, ?, ?, '', ?, ?, 'image', ?)`).bind(messageID, bookingID, senderType, senderName, now, staff ? 1 : 0, attachmentID)
    ]);
  } catch (error) {
    await env.HOTELS_MEDIA.delete(objectKey).catch(() => {});
    throw error;
  }
  if (!staff) await sendStaffPush(env, senderName, 'Фотография', { type: 'chat_image', bookingID }).catch(() => {});
  else await sendClientPushForBooking(env, bookingID, senderName, 'Фотография', { type: 'chat_image' }).catch(() => {});
  return chatMessageDetail(env, messageID, 201, staff);
}

async function serveChatAttachment(env, bookingID, attachmentID) {
  const safeAttachmentID = safeID(attachmentID);
  if (!safeAttachmentID) return json({ ok: false, error: 'INVALID_ATTACHMENT_ID' }, 400);
  const row = await env.HOTELS_DB.prepare('SELECT * FROM business_chat_attachments WHERE id=? AND booking_id=? LIMIT 1').bind(safeAttachmentID, bookingID).first();
  if (!row) return json({ ok: false, error: 'ATTACHMENT_NOT_FOUND' }, 404);
  const object = await env.HOTELS_MEDIA.get(row.object_key);
  if (!object) return json({ ok: false, error: 'ATTACHMENT_NOT_FOUND' }, 404);
  const headers = new Headers();
  headers.set('content-type', row.content_type || 'image/webp');
  headers.set('cache-control', 'private, max-age=3600');
  return new Response(object.body, { status: 200, headers });
}


async function requireStaff(request, env) {
  const cookie = request.headers.get('cookie') || '';
  if (!cookie) {
    return { ok: false, response: json({ ok: false, error: 'UNAUTHORIZED' }, 401) };
  }

  let response;
  try {
    response = await fetch(env.AUTH_SESSION_URL || 'https://iumrah.app/api/auth/staff/session', {
      method: 'GET',
      headers: {
        'cookie': cookie,
        'accept': 'application/json',
        'user-agent': request.headers.get('user-agent') || 'iumrah-business'
      },
      redirect: 'manual'
    });
  } catch (error) {
    console.error('AUTH_PROXY_FAILED', error);
    return { ok: false, response: json({ ok: false, error: 'AUTH_SERVICE_UNAVAILABLE' }, 503) };
  }

  if (!response.ok) {
    return { ok: false, response: json({ ok: false, error: 'UNAUTHORIZED' }, 401) };
  }

  const payload = await response.json().catch(() => null);
  const user = payload?.user;
  const role = String(user?.role || '').toLowerCase();
  if (!user || !['superadmin', 'admin'].includes(role)) {
    return { ok: false, response: json({ ok: false, error: 'FORBIDDEN' }, 403) };
  }

  return { ok: true, user };
}

async function health(env, admin) {
  const row = await env.HOTELS_DB.prepare(
    admin
      ? 'SELECT COUNT(*) AS count FROM hotels'
      : "SELECT COUNT(*) AS count FROM hotels WHERE status = 'published'"
  ).first();

  return json({
    ok: true,
    database: 'iumrah-hotels',
    storage: 'iumrah-hotels-media',
    hotels: Number(row?.count || 0)
  }, 200, PUBLIC_CACHE_HEADERS);
}

async function listHotels(env, url, publishedOnly) {
  const city = cleanText(url.searchParams.get('city'), 80);
  const values = [];
  const where = [];

  if (publishedOnly) where.push("h.status = 'published'");
  if (city) {
    where.push('LOWER(h.city) = LOWER(?)');
    values.push(city);
  }

  const sql = `
    SELECT
      h.id,
      h.name,
      h.city,
      h.stars,
      h.rating,
      h.review_count,
      h.status,
      h.lifecycle_state,
      h.updated_at,
      (SELECT COUNT(*) FROM hotel_images hi WHERE hi.hotel_id = h.id) AS image_count,
      (SELECT COUNT(*) FROM hotel_rooms hr WHERE hr.hotel_id = h.id) AS room_count,
      (
        SELECT hi.id
        FROM hotel_images hi
        WHERE hi.hotel_id = h.id
        ORDER BY hi.is_cover DESC, hi.position ASC, hi.created_at ASC
        LIMIT 1
      ) AS cover_image_id
    FROM hotels h
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY
      CASE LOWER(h.city) WHEN 'makkah' THEN 0 WHEN 'madinah' THEN 1 ELSE 2 END,
      h.name COLLATE NOCASE ASC
    LIMIT 500
  `;

  const result = await env.HOTELS_DB.prepare(sql).bind(...values).all();
  const hotels = (result.results || []).map(row => hotelSummary(row));
  return json({ hotels }, 200, publishedOnly ? PUBLIC_CACHE_HEADERS : undefined);
}

async function hotelDetail(env, hotelID, admin, url = null) {
  const hotel = await env.HOTELS_DB.prepare(
    `SELECT * FROM hotels WHERE id = ? ${admin ? '' : "AND status = 'published'"}`
  ).bind(hotelID).first();

  if (!hotel) return json({ ok: false, error: 'HOTEL_NOT_FOUND' }, 404);

  const [amenitiesResult, roomsResult, imagesResult, sourcesResult] = await Promise.all([
    env.HOTELS_DB.prepare('SELECT amenity FROM hotel_amenities WHERE hotel_id = ? ORDER BY position ASC, amenity ASC').bind(hotelID).all(),
    env.HOTELS_DB.prepare('SELECT id, name, max_guests, size_m2, beds, view, description, amenities_json, smoking, accessibility_json, category, bathroom_json FROM hotel_rooms WHERE hotel_id = ? ORDER BY position ASC, name ASC').bind(hotelID).all(),
    env.HOTELS_DB.prepare('SELECT id, source_provider, category, label, room_name, position, is_cover, width, height, byte_size, original_byte_size, content_type, transform_version FROM hotel_images WHERE hotel_id = ? ORDER BY is_cover DESC, position ASC, created_at ASC').bind(hotelID).all(),
    admin
      ? env.HOTELS_DB.prepare('SELECT * FROM hotel_sources WHERE hotel_id = ? ORDER BY provider ASC').bind(hotelID).all()
      : Promise.resolve({ results: [] })
  ]);

  const images = (imagesResult.results || []).map(row => ({
    id: row.id,
    provider: row.source_provider,
    category: row.category || 'gallery',
    label: row.label || null,
    roomName: row.room_name || null,
    position: Number(row.position || 0),
    isCover: Number(row.is_cover || 0) === 1,
    width: row.width == null ? null : Number(row.width),
    height: row.height == null ? null : Number(row.height),
    byteSize: Number(row.byte_size || 0),
    originalByteSize: Number(row.original_byte_size || 0),
    contentType: row.content_type || 'image/webp',
    transformVersion: row.transform_version || null,
    url: publicImagePath(hotelID, row.id)
  }));

  const detail = {
    id: hotel.id,
    name: hotel.name,
    city: hotel.city,
    country: hotel.country,
    propertyType: hotel.property_type || null,
    brand: hotel.brand || null,
    chain: hotel.chain_name || null,
    postalCode: hotel.postal_code || null,
    stars: hotel.stars == null ? null : Number(hotel.stars),
    rating: hotel.rating == null ? null : Number(hotel.rating),
    ratingScale: hotel.rating_scale == null ? null : Number(hotel.rating_scale),
    reviewCount: hotel.review_count == null ? null : Number(hotel.review_count),
    address: hotel.address || '',
    description: hotel.description || '',
    latitude: hotel.latitude == null ? null : Number(hotel.latitude),
    longitude: hotel.longitude == null ? null : Number(hotel.longitude),
    checkIn: hotel.check_in || null,
    checkOut: hotel.check_out || null,
    policies: parseJSONArray(hotel.policies_json),
    nearby: parseJSONArray(hotel.nearby_json),
    facts: parseJSONArray(hotel.facts_json),
    fees: parseJSONArray(hotel.fees_json),
    services: parseJSONArray(hotel.services_json),
    highlights: parseJSONArray(hotel.highlights_json),
    importantInformation: parseJSONArray(hotel.important_information_json),
    food: parseJSONArray(hotel.food_json),
    parkingTransport: parseJSONArray(hotel.parking_transport_json),
    accessibility: parseJSONArray(hotel.accessibility_json),
    googleMapsURL: hotel.google_maps_url || googleMapsURL(hotel.latitude, hotel.longitude, hotel.address),
    canonicalKey: hotel.canonical_key || null,
    status: hotel.status,
    lifecycleState: hotel.lifecycle_state || hotel.status,
    dataQuality: parseJSONObject(hotel.data_quality_json),
    lastVerifiedAt: hotel.last_verified_at || null,
    amenities: (amenitiesResult.results || []).map(row => row.amenity),
    rooms: (roomsResult.results || []).map(row => ({
      id: row.id,
      name: row.name,
      maxGuests: row.max_guests == null ? null : Number(row.max_guests),
      sizeM2: row.size_m2 == null ? null : Number(row.size_m2),
      beds: row.beds,
      view: row.view,
      description: row.description || null,
      amenities: parseJSONArray(row.amenities_json),
      smoking: row.smoking || null,
      accessibility: parseJSONArray(row.accessibility_json),
      category: row.category || null,
      bathroom: parseJSONArray(row.bathroom_json)
    })),
    images,
    sources: admin ? (sourcesResult.results || []).map(sourceRow) : [],
    createdAt: hotel.created_at,
    updatedAt: hotel.updated_at
  };

  if (!admin && url) {
    const requestedLocale = normalizeLocale(url.searchParams.get('locale') || 'en');
    if (requestedLocale && requestedLocale !== 'en') {
      try {
        const source = await hotelDataForTranslation(env, hotelID);
        if (source) {
          const translated = await getOrCreateHotelTranslation(env, hotelID, requestedLocale, source);
          applyHotelTranslation(detail, translated.translation);
          detail.locale = requestedLocale;
          detail.translationStatus = translated.cached ? 'cached' : 'generated';
        }
      } catch (error) {
        console.error('HOTEL_DETAIL_TRANSLATION_FAILED', { hotelID, locale: requestedLocale, error: String(error?.message || error) });
        detail.locale = 'en';
        detail.translationStatus = 'fallback';
      }
    } else {
      detail.locale = 'en';
      detail.translationStatus = 'canonical';
    }
  }

  return json({ ok: true, hotel: detail }, 200, admin ? undefined : PUBLIC_CACHE_HEADERS);
}

function applyHotelTranslation(detail, translated) {
  if (!translated || typeof translated !== 'object') return detail;
  const fields = [
    'propertyType','address','description','checkIn','checkOut','amenities','policies',
    'nearby','facts','fees','services','highlights','importantInformation','food',
    'parkingTransport','accessibility','rooms'
  ];
  for (const field of fields) {
    if (translated[field] != null) detail[field] = translated[field];
  }
  return detail;
}

async function saveHotel(request, env, user) {
  const payload = await readJSON(request, 4_000_000);
  if (!payload.ok) return payload.response;

  // Direct admin saves are always server-side drafts. Publishing is reserved for
  // the import workflow after media/data integrity checks have completed.
  const safeDraft = { ...(payload.value || {}), status: 'draft', lifecycleState: 'draft' };
  const allowPossibleDuplicate = request.headers.get('x-iumrah-allow-possible-duplicate') === '1';
  const duplicate = await findDuplicateHotel(env, safeDraft, safeID(safeDraft.id));
  if (duplicate?.certainty === 'definitive') return json({ ok: false, error: 'HOTEL_ALREADY_EXISTS', duplicate }, 409);
  if (duplicate?.certainty === 'possible' && !allowPossibleDuplicate) return json({ ok: false, error: 'POSSIBLE_DUPLICATE', duplicate }, 409);
  const result = await persistHotelDraft(safeDraft, env, user, { checkDuplicate: false });
  if (!result.ok) return result.response;
  return json({ ok: true, hotel: result.hotel }, 200);
}

async function persistHotelDraft(draft, env, user, options = {}) {
  const id = safeID(draft?.id);
  const name = cleanText(draft?.name, 180);
  const city = canonicalCity(draft?.city);

  if (!id || !name || !city) {
    return { ok: false, response: json({ ok: false, error: 'INVALID_HOTEL_PAYLOAD' }, 400) };
  }

  if (options.checkDuplicate) {
    const duplicate = await findDuplicateHotel(env, draft, id);
    if (duplicate) {
      return {
        ok: false,
        duplicate,
        response: json({ ok: false, error: 'HOTEL_ALREADY_EXISTS', duplicate }, 409)
      };
    }
  }

  const country = cleanText(draft.country, 120) || 'Saudi Arabia';
  const propertyType = safeHumanText(draft.propertyType, 120);
  const stars = nullableInteger(draft.stars, 1, 5);
  const rating = nullableNumber(draft.rating, 0, 10);
  const ratingScale = nullableNumber(draft.ratingScale, 1, 10);
  const reviewCount = nullableInteger(draft.reviewCount, 0, 100000000);
  const address = safeHumanText(draft.address, 900) || '';
  const description = safeHumanText(draft.description, 3_500) || '';
  const latitude = nullableNumber(draft.latitude, -90, 90);
  const longitude = nullableNumber(draft.longitude, -180, 180);
  const checkIn = safeHumanText(draft.checkIn, 120);
  const checkOut = safeHumanText(draft.checkOut, 120);
  const policies = []; // provider policies are intentionally not part of the core catalog
  const nearby = safeObjectArray(draft.nearby, 24, 24_000);
  const facts = []; // noisy provider facts are omitted from the canonical selection object
  const fees = [];
  const services = []; // canonical amenities are stored in hotel_amenities
  const brand = safeHumanText(draft.brand, 180);
  const chainName = safeHumanText(draft.chain, 180) || safeHumanText(draft.chainName, 180);
  const postalCode = safeHumanText(draft.postalCode, 40);
  const highlights = uniqueStrings(draft.highlights, 16, 420);
  const importantInformation = [];
  const food = safeObjectArray(draft.food, 16, 24_000);
  const parkingTransport = safeObjectArray(draft.parkingTransport, 16, 24_000);
  const accessibility = uniqueStrings(draft.accessibility, 16, 360);
  const dataQuality = sanitizeObject(draft.dataQuality, 24_000);
  const googleMaps = cleanURL(draft.googleMapsURL) || googleMapsURL(latitude, longitude, address);
  const canonicalKey = canonicalHotelKey(name, city, address, latitude, longitude);
  // Persisting code never elevates an incoming payload to published. The workflow
  // is the only publication authority.
  const status = draft.status === 'archived' ? 'archived' : 'draft';
  const lifecycleState = cleanLifecycleState(draft.lifecycleState) || (status === 'archived' ? 'archived' : 'draft');
  const slug = await uniqueSlug(env, id, `${name}-${city}`);
  const now = new Date().toISOString();

  const statements = [
    env.HOTELS_DB.prepare(`
      INSERT INTO hotels (
        id, slug, name, city, country, property_type, stars, rating, rating_scale,
        review_count, address, description, latitude, longitude, check_in, check_out,
        policies_json, canonical_key, google_maps_url, nearby_json, facts_json, fees_json,
        services_json, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name = excluded.name,
        city = excluded.city,
        country = excluded.country,
        property_type = excluded.property_type,
        stars = excluded.stars,
        rating = excluded.rating,
        rating_scale = excluded.rating_scale,
        review_count = excluded.review_count,
        address = excluded.address,
        description = excluded.description,
        latitude = excluded.latitude,
        longitude = excluded.longitude,
        check_in = excluded.check_in,
        check_out = excluded.check_out,
        policies_json = excluded.policies_json,
        canonical_key = excluded.canonical_key,
        google_maps_url = excluded.google_maps_url,
        nearby_json = excluded.nearby_json,
        facts_json = excluded.facts_json,
        fees_json = excluded.fees_json,
        services_json = excluded.services_json,
        status = excluded.status,
        updated_at = excluded.updated_at
    `).bind(
      id, slug, name, city, country, propertyType, stars, rating, ratingScale, reviewCount,
      address, description, latitude, longitude, checkIn, checkOut, JSON.stringify(policies),
      canonicalKey, googleMaps, JSON.stringify(nearby), JSON.stringify(facts), JSON.stringify(fees),
      JSON.stringify(services), status, now, now
    ),
    env.HOTELS_DB.prepare('DELETE FROM hotel_amenities WHERE hotel_id = ?').bind(id),
    env.HOTELS_DB.prepare('DELETE FROM hotel_rooms WHERE hotel_id = ?').bind(id),
    env.HOTELS_DB.prepare('DELETE FROM hotel_sources WHERE hotel_id = ?').bind(id),
    env.HOTELS_DB.prepare('DELETE FROM hotel_translations WHERE hotel_id = ?').bind(id)
  ];

  const amenities = canonicalAmenities(draft.amenities, 120);
  amenities.forEach((amenity, index) => {
    statements.push(
      env.HOTELS_DB.prepare('INSERT INTO hotel_amenities (hotel_id, amenity, position) VALUES (?, ?, ?)')
        .bind(id, amenity, index)
    );
  });

  const rooms = Array.isArray(draft.rooms) ? draft.rooms.slice(0, 200) : [];
  rooms.forEach((room, index) => {
    const roomID = safeID(room?.id) || crypto.randomUUID();
    const roomName = cleanText(room?.name, 240);
    if (!roomName || !isPlausibleRoomName(roomName)) return;
    statements.push(
      env.HOTELS_DB.prepare(`
        INSERT INTO hotel_rooms (
          id, hotel_id, name, max_guests, size_m2, beds, view, description, amenities_json,
          smoking, accessibility_json, category, bathroom_json, position
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        roomID,
        id,
        roomName,
        nullableInteger(room?.maxGuests, 1, 30),
        nullableNumber(room?.sizeM2, 1, 3000),
        safeHumanText(room?.beds, 300),
        safeHumanText(room?.view, 300),
        safeHumanText(room?.description, 1200),
        JSON.stringify(uniqueStrings(room?.amenities, 60, 180)),
        safeHumanText(room?.smoking, 160),
        JSON.stringify(uniqueStrings(room?.accessibility, 24, 220)),
        safeHumanText(room?.category, 160),
        JSON.stringify(uniqueStrings(room?.bathroom, 24, 220)),
        index
      )
    );
  });

  const sources = Array.isArray(draft.sources) ? draft.sources.slice(0, 10) : [];
  sources.forEach(source => {
    const sourceURL = cleanURL(source?.sourceURL);
    const provider = cleanText(source?.provider, 80);
    if (!sourceURL || !provider) return;
    const sourceNearby = safeObjectArray(source?.nearby, 220, 64_000);
    const sourceFacts = safeObjectArray(source?.facts, 420, 160_000);
    const sourceFees = safeObjectArray(source?.fees, 220, 80_000);
    const sourceServices = uniqueStrings(source?.services, 300, 240);
    statements.push(
      env.HOTELS_DB.prepare(`
        INSERT INTO hotel_sources (
          id, hotel_id, provider, source_url, source_name, city, country, property_type,
          address, description, stars, rating, rating_scale, review_count, latitude, longitude,
          check_in, check_out, images_json, amenities_json, room_names_json, room_details_json,
          policies_json, provider_hotel_id, canonical_url, google_maps_url, nearby_json, facts_json,
          fees_json, services_json, checked_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        safeID(source?.id) || crypto.randomUUID(),
        id,
        provider,
        sourceURL,
        safeHumanText(source?.name, 300),
        canonicalCity(source?.city) || cleanText(source?.city, 80),
        safeHumanText(source?.country, 120),
        safeHumanText(source?.propertyType, 120),
        safeHumanText(source?.address, 900),
        null,
        nullableInteger(source?.stars, 1, 5),
        nullableNumber(source?.rating, 0, 10),
        nullableNumber(source?.ratingScale, 1, 10),
        nullableInteger(source?.reviewCount, 0, 100000000),
        nullableNumber(source?.latitude, -90, 90),
        nullableNumber(source?.longitude, -180, 180),
        safeHumanText(source?.checkIn, 120),
        safeHumanText(source?.checkOut, 120),
        '[]',
        '[]',
        '[]',
        '[]',
        '[]',
        cleanText(source?.providerHotelID, 220),
        cleanURL(source?.canonicalURL),
        cleanURL(source?.googleMapsURL) || googleMapsURL(source?.latitude, source?.longitude, source?.address),
        '[]',
        '[]',
        '[]',
        '[]',
        now
      )
    );
  });

  await env.HOTELS_DB.batch(statements);

  await env.HOTELS_DB.prepare(`
    UPDATE hotels
    SET brand=?, chain_name=?, postal_code=?, highlights_json=?, important_information_json=?,
        food_json=?, parking_transport_json=?, accessibility_json=?, lifecycle_state=?,
        data_quality_json=?, last_verified_at=?, catalog_profile='core-v1', source_room_count=?, updated_at=?
    WHERE id=?
  `).bind(
    brand,
    chainName,
    postalCode,
    JSON.stringify(highlights),
    JSON.stringify(importantInformation),
    JSON.stringify(food),
    JSON.stringify(parkingTransport),
    JSON.stringify(accessibility),
    lifecycleState,
    JSON.stringify(dataQuality),
    now,
    rooms.filter(room => isPlausibleRoomName(room?.name)).length,
    now,
    id
  ).run();

  for (const source of sources) {
    const sourceURL = cleanURL(source?.sourceURL);
    const provider = cleanText(source?.provider, 80);
    if (!sourceURL || !provider) continue;
    await env.HOTELS_DB.prepare(`
      UPDATE hotel_sources
      SET brand=?, chain_name=?, postal_code=?, highlights_json=?, important_information_json=?,
          food_json=?, parking_transport_json=?, accessibility_json=?, raw_identity_json=?
      WHERE hotel_id=? AND LOWER(provider)=LOWER(?) AND source_url=?
    `).bind(
      safeHumanText(source?.brand, 180),
      safeHumanText(source?.chain, 180) || safeHumanText(source?.chainName, 180),
      safeHumanText(source?.postalCode, 40),
      '[]',
      '[]',
      '[]',
      '[]',
      '[]',
      '{}',
      id,
      provider,
      sourceURL
    ).run();
  }

  console.log('HOTEL_SAVED', {
    hotelID: id,
    status,
    actor: user?.login || user?.email || 'staff',
    amenities: amenities.length,
    rooms: rooms.length,
    sources: sources.length,
    nearby: nearby.length,
    facts: facts.length
  });

  const row = await summaryRow(env, id);
  return { ok: true, hotel: hotelSummary(row), hotelID: id };
}


async function checkDuplicateRequest(request, env) {
  const payload = await readJSON(request, 600_000);
  if (!payload.ok) return payload.response;
  const duplicate = await findDuplicateHotel(env, payload.value || {}, null);
  if (isRepairableDuplicate(duplicate)) {
    return json({ ok: true, duplicate: null, repairable: duplicate });
  }
  return json({ ok: true, duplicate: duplicate || null });
}

async function findDuplicateHotel(env, draft, excludeID = null) {
  const sourceURLs = [];
  if (cleanURL(draft?.sourceURL)) sourceURLs.push(cleanURL(draft.sourceURL));
  for (const source of Array.isArray(draft?.sources) ? draft.sources : []) {
    const url = cleanURL(source?.sourceURL);
    if (url) sourceURLs.push(url);
  }

  for (const sourceURL of [...new Set(sourceURLs)]) {
    const canonicalSource = canonicalSourceURL(sourceURL);
    const row = await env.HOTELS_DB.prepare(`
      SELECT h.id, h.name, h.city, h.address, h.latitude, h.longitude, h.brand, h.chain_name, h.status, h.lifecycle_state, hs.provider, hs.source_url
      FROM hotel_sources hs JOIN hotels h ON h.id = hs.hotel_id
      WHERE (hs.source_url = ? OR hs.canonical_url = ?) ${excludeID ? 'AND h.id != ?' : ''}
      LIMIT 1
    `).bind(...(excludeID ? [sourceURL, canonicalSource, excludeID] : [sourceURL, canonicalSource])).first();
    if (row) return duplicateSummary(row, 'same_source', 'definitive', 1);
  }

  for (const source of Array.isArray(draft?.sources) ? draft.sources : []) {
    const provider = cleanText(source?.provider, 80);
    const providerHotelID = cleanText(source?.providerHotelID, 220);
    if (!provider || !providerHotelID) continue;
    const row = await env.HOTELS_DB.prepare(`
      SELECT h.id, h.name, h.city, h.address, h.latitude, h.longitude, h.brand, h.chain_name, h.status, h.lifecycle_state, hs.provider, hs.source_url
      FROM hotel_sources hs JOIN hotels h ON h.id = hs.hotel_id
      WHERE LOWER(hs.provider) = LOWER(?) AND hs.provider_hotel_id = ? ${excludeID ? 'AND h.id != ?' : ''}
      LIMIT 1
    `).bind(...(excludeID ? [provider, providerHotelID, excludeID] : [provider, providerHotelID])).first();
    if (row) return duplicateSummary(row, 'provider_id', 'definitive', 1);
  }

  const name = cleanText(draft?.name, 180);
  const city = canonicalCity(draft?.city);
  if (!name || !city) return null;

  const latitude = nullableNumber(draft?.latitude, -90, 90);
  const longitude = nullableNumber(draft?.longitude, -180, 180);
  const address = cleanText(draft?.address, 900) || '';
  const requestedBrand = cleanText(draft?.brand, 180) || cleanText(draft?.chain, 180) || '';
  const candidates = await env.HOTELS_DB.prepare(`
    SELECT id, name, city, address, latitude, longitude, brand, chain_name, status, lifecycle_state
    FROM hotels
    WHERE LOWER(city) = LOWER(?) ${excludeID ? 'AND id != ?' : ''}
    ORDER BY updated_at DESC
    LIMIT 600
  `).bind(...(excludeID ? [city, excludeID] : [city])).all();

  const requestedTokens = hotelNameTokens(name);
  const requestedAddress = normalizedAddress(address);
  const requestedBrandTokens = hotelNameTokens(requestedBrand);
  let bestPossible = null;

  for (const row of candidates.results || []) {
    const nameScore = tokenSimilarity(requestedTokens, hotelNameTokens(row.name));
    const addressScore = requestedAddress && row.address
      ? tokenSimilarity(addressTokens(requestedAddress), addressTokens(normalizedAddress(row.address)))
      : 0;
    const candidateBrand = `${row.brand || ''} ${row.chain_name || ''}`.trim();
    const brandScore = requestedBrandTokens.size && candidateBrand
      ? tokenSimilarity(requestedBrandTokens, hotelNameTokens(candidateBrand))
      : 0;
    const geoMeters = latitude != null && longitude != null && row.latitude != null && row.longitude != null
      ? haversineMeters(latitude, longitude, Number(row.latitude), Number(row.longitude))
      : null;

    // Definitive physical-property matches require two strong independent signals.
    if (geoMeters != null && geoMeters <= 80 && nameScore >= 0.55) {
      const confidence = Math.min(0.99, 0.90 + nameScore * 0.08 + (brandScore > 0.6 ? 0.01 : 0));
      return duplicateSummary(row, 'same_property_geo', 'definitive', confidence, { nameScore, addressScore, brandScore, geoMeters });
    }
    if (nameScore >= 0.88 && addressScore >= 0.70) {
      const confidence = Math.min(0.99, 0.88 + nameScore * 0.06 + addressScore * 0.05);
      return duplicateSummary(row, 'same_property_address', 'definitive', confidence, { nameScore, addressScore, brandScore, geoMeters });
    }

    // A similar name alone is never enough to auto-block; surface it for human review.
    let possibleConfidence = 0;
    let possibleMatch = null;
    if (geoMeters != null && geoMeters <= 250 && nameScore >= 0.45) {
      possibleConfidence = 0.72 + Math.min(0.12, nameScore * 0.10) + (geoMeters <= 120 ? 0.05 : 0);
      possibleMatch = 'possible_property_geo';
    } else if (nameScore >= 0.70 && addressScore >= 0.40) {
      possibleConfidence = 0.68 + nameScore * 0.10 + addressScore * 0.08;
      possibleMatch = 'possible_property_address';
    } else if (nameScore >= 0.90) {
      possibleConfidence = 0.72 + nameScore * 0.08 + (brandScore >= 0.60 ? 0.04 : 0);
      possibleMatch = 'possible_property_name';
    }

    if (possibleMatch) {
      const candidate = duplicateSummary(row, possibleMatch, 'possible', Math.min(0.89, possibleConfidence), { nameScore, addressScore, brandScore, geoMeters });
      if (!bestPossible || candidate.confidence > bestPossible.confidence) bestPossible = candidate;
    }
  }

  return bestPossible;
}

function duplicateSummary(row, match, certainty = 'definitive', confidence = 1, signals = null) {
  return {
    id: row.id,
    name: row.name,
    city: row.city,
    address: row.address || '',
    latitude: row.latitude == null ? null : Number(row.latitude),
    longitude: row.longitude == null ? null : Number(row.longitude),
    brand: row.brand || null,
    chain: row.chain_name || null,
    provider: row.provider || null,
    sourceURL: row.source_url || null,
    status: row.status || null,
    lifecycleState: row.lifecycle_state || row.status || null,
    match,
    certainty,
    confidence: Math.round(Math.max(0, Math.min(1, Number(confidence) || 0)) * 1000) / 1000,
    signals: signals || null
  };
}

function isRepairableDuplicate(duplicate) {
  if (!duplicate || duplicate.certainty !== 'definitive') return false;
  const status = String(duplicate.status || '').toLowerCase();
  const lifecycle = String(duplicate.lifecycleState || status).toLowerCase();
  if (status === 'published' || lifecycle === 'published' || lifecycle === 'importing') return false;
  return ['draft','failed','ready','archived'].includes(status) || ['draft','failed','ready','archived'].includes(lifecycle);
}


async function recoverSourceRooms(request, env) {
  const payload = await readJSON(request, 100_000);
  if (!payload.ok) return payload.response;
  const sourceURL = cleanURL(payload.value?.sourceURL);
  if (!sourceURL) return json({ ok: false, error: 'INVALID_SOURCE_URL' }, 400);

  let input;
  try { input = new URL(sourceURL); } catch (_) { return json({ ok: false, error: 'INVALID_SOURCE_URL' }, 400); }
  const inputHost = input.hostname.toLowerCase();
  const hintedProvider = inputHost === 'expe.onelink.me' || inputHost.endsWith('.expe.onelink.me')
    ? 'Expedia'
    : detectRoomProvider(input);
  if (!hintedProvider) return json({ ok: false, error: 'UNSUPPORTED_SOURCE_PROVIDER' }, 400);

  const headers = new Headers({
    'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache'
  });

  let response;
  try {
    response = await fetch(sourceURL, { headers, redirect: 'follow', cf: { cacheTtl: 0 } });
  } catch (error) {
    return json({ ok: false, error: 'SOURCE_ROOM_FETCH_FAILED', detail: String(error?.message || error).slice(0, 500) }, 502);
  }
  if (!response.ok) return json({ ok: false, error: `SOURCE_ROOM_HTTP_${response.status}` }, 502);

  const finalURL = response.url || sourceURL;
  let finalParsed;
  try { finalParsed = new URL(finalURL); } catch (_) { return json({ ok: false, error: 'SOURCE_ROOM_BAD_REDIRECT' }, 502); }
  const provider = detectRoomProvider(finalParsed) || hintedProvider;
  if (!provider || !providerRoomHostAllowed(finalParsed, provider)) {
    return json({ ok: false, error: 'SOURCE_REDIRECT_OUTSIDE_PROVIDER' }, 400);
  }
  const expectedPropertyID = providerPropertyIDFromURL(finalParsed, provider)
    || providerPropertyIDFromURL(input, provider);
  if (provider === 'Expedia' && !expectedPropertyID) {
    return json({ ok: false, error: 'SOURCE_PROPERTY_ID_MISSING', detail: 'Resolved Expedia URL has no stable .h<propertyID> identity.' }, 422);
  }

  const html = await response.text();
  if (!html || html.length < 500) return json({ ok: false, error: 'SOURCE_ROOM_EMPTY_PAGE' }, 502);
  if (html.length > 8_000_000) return json({ ok: false, error: 'SOURCE_ROOM_PAGE_TOO_LARGE' }, 502);
  if (isProviderChallengeHTML(html)) {
    return json({ ok: false, error: 'SOURCE_PROVIDER_CHALLENGE', detail: 'Provider returned an anti-bot verification page instead of the hotel property.' }, 409);
  }

  let rooms = extractProviderRoomsFromHTML(html, provider, expectedPropertyID);
  let recoveryURL = finalURL;
  let method = rooms.length ? 'server-property-page-v3' : 'server-property-page-no-room-match';

  // Room cards are availability-driven on both Expedia and Booking. Probe only the
  // exact resolved property URL with deterministic future dates; this never searches
  // by hotel name and therefore cannot drift to a different physical hotel.
  if (rooms.length < 4) {
    const candidates = roomRecoveryProbeURLs(finalParsed, provider);
    for (const fallbackURL of candidates) {
      try {
        const fallbackResponse = await fetch(fallbackURL, { headers, redirect: 'follow', cf: { cacheTtl: 0 } });
        if (!fallbackResponse.ok) continue;
        const fallbackFinal = new URL(fallbackResponse.url || fallbackURL);
        if (!providerRoomHostAllowed(fallbackFinal, provider)) continue;
        if (!sameProviderPropertyIdentity(fallbackFinal, finalParsed, provider)) continue;
        const fallbackHTML = await fallbackResponse.text();
        if (!fallbackHTML || fallbackHTML.length > 8_000_000) continue;
        const recovered = extractProviderRoomsFromHTML(fallbackHTML, provider, expectedPropertyID);
        if (!recovered.length) continue;
        rooms = mergeRecoveredRooms(rooms, recovered);
        recoveryURL = fallbackResponse.url || fallbackURL;
        method = 'server-property-page-dated-probe-v3';
        if (rooms.length >= 4) break;
      } catch (_) {}
    }
  }

  return json({
    ok: true,
    provider,
    sourceURL: recoveryURL,
    roomCount: rooms.length,
    rooms,
    method,
    propertyID: expectedPropertyID || null
  });
}

function isProviderChallengeHTML(html) {
  const text = String(html || '').toLowerCase();
  return [
    'bot or not', 'verify you are human', 'are you a robot', 'security check',
    'robot check', 'unusual traffic', 'captcha', 'access denied'
  ].some(marker => text.includes(marker));
}

function detectRoomProvider(url) {
  const host = String(url?.hostname || '').toLowerCase();
  if (host === 'booking.com' || host.endsWith('.booking.com')) return 'Booking';
  if (host === 'expedia.com' || host.endsWith('.expedia.com') || host.includes('expedia.')) return 'Expedia';
  return null;
}

function providerPropertyIDFromURL(url, provider) {
  if (provider !== 'Expedia') return null;
  try {
    const explicit = url.searchParams.get('expediaPropertyId') || url.searchParams.get('propertyId');
    if (explicit && /^[0-9]{4,}$/.test(explicit)) return explicit;
    const match = String(url.pathname || '').match(/\.h([0-9]{4,})\.Hotel-Information/i);
    return match ? match[1] : null;
  } catch (_) {
    return null;
  }
}

function sameProviderPropertyIdentity(candidateURL, expectedURL, provider) {
  if (!providerRoomHostAllowed(candidateURL, provider)) return false;
  if (provider !== 'Expedia') return true;
  const expected = providerPropertyIDFromURL(expectedURL, provider);
  const actual = providerPropertyIDFromURL(candidateURL, provider);
  return !!expected && actual === expected;
}

function providerRoomHostAllowed(url, provider) {
  const host = String(url?.hostname || '').toLowerCase();
  return provider === 'Booking'
    ? host === 'booking.com' || host.endsWith('.booking.com')
    : host === 'expedia.com' || host.endsWith('.expedia.com') || host.includes('expedia.');
}

function roomRecoveryProbeURLs(propertyURL, provider) {
  const offsets = [14, 45];
  const output = [];
  const seen = new Set();
  const dateFor = offset => new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10);
  const push = url => {
    const value = url.toString();
    if (!seen.has(value)) { seen.add(value); output.push(value); }
  };

  for (const offset of offsets) {
    const url = new URL(propertyURL.toString());
    const checkIn = dateFor(offset);
    const checkOut = dateFor(offset + 2);
    if (provider === 'Expedia') {
      url.searchParams.set('chkin', checkIn);
      url.searchParams.set('chkout', checkOut);
      url.searchParams.set('rm1', 'a2');
      url.searchParams.set('useRewards', 'false');
      push(url);

      // Regional Expedia properties share the same .h<propertyID> identity/path.
      // The .com render is often richer server-side, but the path is never changed.
      const canonical = new URL(url.toString());
      canonical.hostname = 'www.expedia.com';
      push(canonical);
    } else {
      url.searchParams.set('checkin', checkIn);
      url.searchParams.set('checkout', checkOut);
      url.searchParams.set('group_adults', '2');
      url.searchParams.set('group_children', '0');
      url.searchParams.set('no_rooms', '1');
      push(url);
    }
  }
  return output.slice(0, 6);
}

function mergeRecoveredRooms(primary, recovered) {
  const out = [];
  const seen = new Set();
  for (const room of [...(primary || []), ...(recovered || [])]) {
    if (!room || !isPlausibleRoomName(room.name)) continue;
    const key = normalizeRoomIdentity(room.name);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(room);
    if (out.length >= 140) break;
  }
  return out;
}

function extractProviderRoomsFromHTML(html, provider, expectedPropertyID = null) {
  const visible = htmlToReadableText(html);
  const roomStart = visible.search(/\b(?:room options|rooms and rates|available rooms|choose your room|room types)\b/i);
  let roomText = roomStart >= 0 ? visible.slice(roomStart, roomStart + 180_000) : visible;
  const end = roomText.slice(800).search(/\b(?:about this property|property amenities|location|policies|reviews|getting around|you may also like|similar properties|recommended)\b/i);
  if (end >= 0) roomText = roomText.slice(0, Math.max(2_500, end + 800));

  const anchors = [];
  const patterns = provider === 'Expedia' ? [
    { source: 'photo', regex: /View all photos for\s+([^\n]{3,220})/gi },
    { source: 'detail', regex: /More details(?:\s+More details)? for\s+([^\n]{3,220})/gi },
    { source: 'price', regex: /View prices(?: for your dates)?(?: for)?\s+([^\n]{3,220})/gi }
  ] : [
    { source: 'room', regex: /(?:Room type|Room name)\s*[:\-]?\s*([^\n]{3,220})/gi }
  ];
  for (const entry of patterns) {
    let match;
    while ((match = entry.regex.exec(roomText)) !== null && anchors.length < 500) {
      anchors.push({ name: cleanRoomAnchor(match[1]), index: match.index, source: entry.source });
    }
  }
  anchors.sort((a, b) => a.index - b.index);

  // Expedia repeats the room name in “More details …” / “View prices …”. When a
  // photo anchor exists for that name, use the photo anchor because the sellable
  // details live between it and the action footer. This prevents details from the
  // next room card leaking into the previous room.
  const photoNames = new Set(anchors.filter(a => a.source === 'photo').map(a => normalizeRoomIdentity(a.name)));
  const visibleAnchors = anchors.filter(a => !['detail','price'].includes(a.source) || !photoNames.has(normalizeRoomIdentity(a.name)));

  // Explicit room-name keys from application state are useful only as a fallback
  // for names not already represented by visible room cards.
  const rawJSONAnchors = [];
  const rawJSONPatterns = [
    /["']roomTypeName["']\s*:\s*["']([^"']{3,220})["']/gi,
    /["']roomName["']\s*:\s*["']([^"']{3,220})["']/gi,
    /["']unitName["']\s*:\s*["']([^"']{3,220})["']/gi
  ];
  // Expedia SSR/app-state contains other properties on the same HTML document. Do not
  // accept unscoped room-name JSON; the visible Room options/action labels are the safe
  // property-specific source. Booking keeps the legacy structured fallback.
  if (provider !== 'Expedia') {
    for (const pattern of rawJSONPatterns) {
      let match;
      while ((match = pattern.exec(html)) !== null && rawJSONAnchors.length < 300) {
        rawJSONAnchors.push({ name: cleanRoomAnchor(decodeHTMLEntities(match[1])), index: -1, source: 'json' });
      }
    }
  }

  // SSR room cards frequently expose the room name only through aria-label/title
  // attributes. htmlToReadableText intentionally removes tags, so capture those
  // attributes directly before the markup is stripped. Expedia appends cross-sell
  // properties after the current property's room section, so never scan those cards.
  const recommendationBoundary = provider === 'Expedia'
    ? String(html || '').search(/(?:You may also like|Similar properties|Recommended properties)/i)
    : -1;
  const propertyScopedHTML = recommendationBoundary >= 0 ? String(html || '').slice(0, recommendationBoundary) : String(html || '');
  const rawAttributePatterns = provider === 'Expedia' ? [
    /aria-label=["'][^"']*View all photos for\s+([^"']{3,220})["']/gi,
    /aria-label=["'][^"']*More details(?:\s+More details)? for\s+([^"']{3,220})["']/gi,
    /title=["'][^"']*View all photos for\s+([^"']{3,220})["']/gi
  ] : [
    /data-testid=["'][^"']*room[^"']*["'][^>]*>\s*([^<]{3,220})</gi,
    /aria-label=["'][^"']*(?:room|suite)\s*[:\-]?\s*([^"']{3,220})["']/gi
  ];
  for (const pattern of rawAttributePatterns) {
    let match;
    while ((match = pattern.exec(propertyScopedHTML)) !== null && rawJSONAnchors.length < 420) {
      rawJSONAnchors.push({ name: cleanRoomAnchor(decodeHTMLEntities(match[1])), index: -1, source: 'attribute' });
    }
  }

  // Expedia application state is often JSON-escaped inside another script string.
  // Normalize only quoting/unicode escapes and then reuse the strict room-name keys.
  const normalizedStructuredHTML = String(html || '')
    .replace(/\\u([0-9a-f]{4})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\\"/g, '"');
  if (provider !== 'Expedia' && normalizedStructuredHTML !== html) {
    for (const pattern of rawJSONPatterns) {
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(normalizedStructuredHTML)) !== null && rawJSONAnchors.length < 500) {
        rawJSONAnchors.push({ name: cleanRoomAnchor(decodeHTMLEntities(match[1])), index: -1, source: 'escaped-json' });
      }
    }
  }

  const processAnchors = [...visibleAnchors];
  const visibleNames = new Set(processAnchors.map(a => normalizeRoomIdentity(a.name)));
  for (const anchor of rawJSONAnchors) {
    if (!visibleNames.has(normalizeRoomIdentity(anchor.name))) processAnchors.push(anchor);
  }

  const result = [];
  const seen = new Set();
  for (let i = 0; i < processAnchors.length; i += 1) {
    const anchor = processAnchors[i];
    const name = safeHumanText(anchor.name, 240);
    if (!name || !isPlausibleRoomName(name)) continue;

    let context = name;
    if (anchor.index >= 0) {
      const nextVisible = anchors.find(other => other.index > anchor.index);
      const endIndex = nextVisible ? Math.min(nextVisible.index, anchor.index + 2_200) : Math.min(roomText.length, anchor.index + 2_200);
      context = roomText.slice(Math.max(0, anchor.index), endIndex);
    }
    const room = roomFromTextContext(name, context);
    const key = [normalizeRoomIdentity(room.name), room.beds || '', room.maxGuests || '', room.sizeM2 || '', room.view || '']
      .join('|').toLowerCase().replace(/\s+/g, ' ');
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(room);
    if (result.length >= 140) break;
  }
  return result;
}

function normalizeRoomIdentity(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9\u0400-\u04ff\u0600-\u06ff]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function roomFromTextContext(name, context) {
  const compact = String(context || '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n');
  const guest = compact.match(/\bSleeps?\s*(\d{1,2})\b/i) || compact.match(/\b(?:up to|max(?:imum)?)\s*(\d{1,2})\s*(?:guests?|people)\b/i);
  const metricSize = compact.match(/\b(\d{1,4}(?:\.\d+)?)\s*(?:sq\s*m|m²|square meters?)\b/i);
  const imperialSize = compact.match(/\b(\d{2,5}(?:\.\d+)?)\s*(?:sq\s*ft|ft²|square feet)\b/i);
  const sizeM2 = metricSize ? Number(metricSize[1]) : imperialSize ? Math.round(Number(imperialSize[1]) * 0.092903 * 10) / 10 : null;
  const bed = compact.match(/\b(?:\d+\s+)?(?:King|Queen|Twin|Double|Single|Large Twin|Sofa)\s+Beds?(?:\s+(?:and|or)\s+(?:\d+\s+)?(?:King|Queen|Twin|Double|Single|Large Twin|Sofa)\s+Beds?)*/i);
  const view = compact.match(/\b(?:city|kaaba|kabba|haram|landmark|mountain|courtyard|garden|sea)\s+view\b/i);
  const category = name.match(/\b(standard|superior|deluxe|executive|premier|classic|family|studio|junior suite|suite|presidential|royal)\b/i);
  return {
    id: crypto.randomUUID(),
    name,
    maxGuests: guest ? Number(guest[1]) : null,
    sizeM2: Number.isFinite(sizeM2) ? sizeM2 : null,
    beds: bed ? cleanText(bed[0], 260) : null,
    view: view ? cleanText(view[0], 180) : null,
    description: null,
    amenities: /free wi[- ]?fi/i.test(compact) ? ['Free WiFi'] : [],
    smoking: /non[- ]smoking|smoke[- ]free/i.test(compact) ? 'Non-smoking' : null,
    accessibility: [],
    category: category ? category[1] : null,
    bathroom: []
  };
}

function cleanRoomAnchor(value) {
  return String(value || '')
    .replace(/\\u002F/gi, '/')
    .replace(/\\u0026/gi, '&')
    .replace(/\\"/g, '"')
    .replace(/\s+(?:image|photo)\s*:\s*.*$/i, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 240);
}

function htmlToReadableText(html) {
  return decodeHTMLEntities(String(html || '')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '\n')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '\n')
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, '\n')
    .replace(/<br\s*\/?\s*>/gi, '\n')
    .replace(/<\/(?:p|div|section|article|li|h1|h2|h3|h4|button|a)>/gi, '\n')
    .replace(/<[^>]+>/g, ' '))
    .replace(/\r/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function decodeHTMLEntities(value) {
  return String(value || '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, num) => String.fromCodePoint(parseInt(num, 10)));
}



function prioritizeImportImages(images, limit = 48) {
  const input = Array.isArray(images) ? images : [];
  const output = [];
  const seenURL = new Set();
  const take = image => {
    if (!image?.url || output.length >= limit) return;
    const key = canonicalImageSourceKey(image.url) || image.url;
    if (seenURL.has(key)) return;
    seenURL.add(key);
    output.push({ ...image, position: output.length });
  };

  input.filter(image => image.isCover).forEach(take);

  // First preserve room diversity: one photo per named room, then a second pass.
  const namedRooms = new Map();
  for (const image of input) {
    const room = cleanText(image?.roomName, 260);
    if (!room) continue;
    if (!namedRooms.has(room)) namedRooms.set(room, []);
    namedRooms.get(room).push(image);
  }
  for (let pass = 0; pass < 2 && output.length < limit; pass += 1) {
    for (const roomImages of namedRooms.values()) {
      if (roomImages[pass]) take(roomImages[pass]);
      if (output.length >= limit) break;
    }
  }

  const categoryOrder = ['exterior','lobby','room','bathroom','restaurant','breakfast','view','pool','gym','spa','lounge','facility','gallery'];
  for (const category of categoryOrder) {
    const candidate = input.find(image => image.category === category);
    if (candidate) take(candidate);
  }

  for (const image of input) take(image);
  if (output.length && !output.some(image => image.isCover)) output[0].isCover = true;
  return output;
}

function compactHotelImportSnapshot(draft, images) {
  const source = Array.isArray(draft?.sources) ? draft.sources[0] : null;
  const rooms = Array.isArray(draft?.rooms)
    ? draft.rooms.filter(room => isPlausibleRoomName(room?.name)).slice(0, 140).map(room => ({
        id: safeID(room?.id) || crypto.randomUUID(),
        name: safeHumanText(room?.name, 240),
        maxGuests: nullableInteger(room?.maxGuests, 1, 30),
        sizeM2: nullableNumber(room?.sizeM2, 1, 3000),
        beds: safeHumanText(room?.beds, 260),
        view: safeHumanText(room?.view, 220),
        category: safeHumanText(room?.category, 160),
        amenities: uniqueStrings(room?.amenities, 40, 180)
      }))
    : [];
  return {
    version: 'core-v1',
    id: safeID(draft?.id),
    name: safeHumanText(draft?.name, 180),
    city: canonicalCity(draft?.city),
    country: safeHumanText(draft?.country, 120),
    propertyType: safeHumanText(draft?.propertyType, 120),
    brand: safeHumanText(draft?.brand, 180),
    chain: safeHumanText(draft?.chain, 180),
    postalCode: safeHumanText(draft?.postalCode, 40),
    stars: nullableInteger(draft?.stars, 1, 5),
    rating: nullableNumber(draft?.rating, 0, 10),
    ratingScale: nullableNumber(draft?.ratingScale, 1, 10),
    reviewCount: nullableInteger(draft?.reviewCount, 0, 100000000),
    address: safeHumanText(draft?.address, 900),
    latitude: nullableNumber(draft?.latitude, -90, 90),
    longitude: nullableNumber(draft?.longitude, -180, 180),
    checkIn: safeHumanText(draft?.checkIn, 120),
    checkOut: safeHumanText(draft?.checkOut, 120),
    amenities: canonicalAmenities(draft?.amenities, 120),
    nearby: safeObjectArray(draft?.nearby, 24, 24_000),
    food: safeObjectArray(draft?.food, 16, 24_000),
    parkingTransport: safeObjectArray(draft?.parkingTransport, 16, 24_000),
    rooms,
    images: (Array.isArray(images) ? images : []).slice(0, 240).map(image => ({
      url: cleanURL(image?.url),
      provider: cleanText(image?.provider, 80),
      sourcePageURL: cleanURL(image?.sourcePageURL),
      category: validImageCategory(image?.category) || validImageCategory(image?.kind) || 'gallery',
      roomName: safeHumanText(image?.roomName, 260),
      isCover: image?.isCover === true,
      position: boundedInteger(image?.position, 0, 10000, 0)
    })).filter(image => image.url),
    source: source ? {
      provider: cleanText(source?.provider, 80),
      sourceURL: cleanURL(source?.sourceURL),
      canonicalURL: cleanURL(source?.canonicalURL),
      providerHotelID: cleanText(source?.providerHotelID, 220),
      checkedAt: new Date().toISOString()
    } : null
  };
}

async function createImportJob(request, env, user) {
  const payload = await readJSON(request, 4_000_000);
  if (!payload.ok) return payload.response;
  const draft = payload.value?.hotel || payload.value;
  const selectedImages = Array.isArray(payload.value?.images)
    ? payload.value.images
    : Array.isArray(draft?.images) ? draft.images.filter(image => image?.selected !== false) : [];
  const idempotencyKey = cleanText(payload.value?.idempotencyKey || request.headers.get('idempotency-key'), 180);
  const allowPossibleDuplicate = payload.value?.allowPossibleDuplicate === true;

  if (idempotencyKey) {
    const existing = await env.HOTELS_DB.prepare('SELECT id FROM hotel_import_jobs WHERE idempotency_key=? LIMIT 1').bind(idempotencyKey).first();
    if (existing?.id) return importJobDetail(env, existing.id, 200);
  }

  const duplicate = await findDuplicateHotel(env, draft, null);
  const repairDuplicate = isRepairableDuplicate(duplicate) ? duplicate : null;
  if (duplicate?.certainty === 'definitive' && !repairDuplicate) {
    return json({ ok: false, error: 'HOTEL_ALREADY_EXISTS', duplicate }, 409);
  }
  if (duplicate?.certainty === 'possible' && !allowPossibleDuplicate) {
    return json({ ok: false, error: 'POSSIBLE_DUPLICATE', duplicate }, 409);
  }

  const cleanedImages = selectedImages.slice(0, 240).map((image, index) => ({
    url: cleanURL(image?.url),
    provider: cleanText(image?.provider, 80) || 'unknown',
    sourcePageURL: cleanURL(image?.sourcePageURL),
    category: validImageCategory(image?.kind) || validImageCategory(image?.category) || 'gallery',
    label: cleanText(image?.label, 600),
    roomName: cleanText(image?.roomName, 260),
    isCover: image?.isCover === true,
    position: index
  })).filter(image => image.url && image.category !== 'other');
  const images = prioritizeImportImages(cleanedImages, 48);

  if (!images.length) return json({ ok: false, error: 'NO_IMAGES_SELECTED' }, 400);

  const plausibleRooms = Array.isArray(draft?.rooms) ? draft.rooms.filter(room => isPlausibleRoomName(room?.name)) : [];
  if (payload.value?.publishWhenComplete === true && plausibleRooms.length === 0) {
    return json({ ok: false, error: 'ROOM_TYPES_REQUIRED', detail: 'Published hotel requires at least one confirmed room type.' }, 422);
  }
  const trustedImageCount = images.filter(image => image.category !== 'other').length;
  const canPublish = Boolean(payload.value?.publishWhenComplete) && trustedImageCount >= 4 && plausibleRooms.length > 0;
  const safeDraft = { ...draft, id: repairDuplicate?.id || draft?.id, status: 'draft', lifecycleState: 'importing' };
  const persisted = await persistHotelDraft(safeDraft, env, user, { checkDuplicate: false });
  if (!persisted.ok) return persisted.response;

  const hotelID = persisted.hotelID;
  if (repairDuplicate) {
    // Re-importing a failed/draft record repairs the same canonical hotel instead of
    // creating a duplicate. Old partial media is removed before the immutable new job starts.
    await deleteAllHotelImagesInternal(env, hotelID);
  }
  const jobID = `hotel-import-${crypto.randomUUID()}`;
  const snapshotJSON = JSON.stringify(compactHotelImportSnapshot(safeDraft, images));
  const snapshotHash = await sha256Hex(snapshotJSON);
  const now = new Date().toISOString();

  try {
    await env.HOTELS_DB.prepare(`
      INSERT INTO hotel_import_jobs (
        id, hotel_id, hotel_name, source_provider, source_url, status, stage, progress,
        total_images, stored_images, failed_images, images_json, publish_when_complete, updated_at,
        idempotency_key, hotel_snapshot_json, snapshot_hash, retry_count, possible_duplicate_json
      ) VALUES (?, ?, ?, ?, ?, 'queued', 'queued', 0, ?, 0, 0, ?, ?, ?, ?, ?, ?, 0, ?)
    `).bind(
      jobID,
      hotelID,
      cleanText(draft?.name, 180) || hotelID,
      cleanText(draft?.sources?.[0]?.provider, 80),
      cleanURL(draft?.sources?.[0]?.sourceURL),
      images.length,
      JSON.stringify(images),
      canPublish ? 1 : 0,
      now,
      idempotencyKey,
      snapshotJSON,
      snapshotHash,
      duplicate?.certainty === 'possible' ? JSON.stringify(duplicate) : null
    ).run();
  } catch (error) {
    if (idempotencyKey) {
      const existing = await env.HOTELS_DB.prepare('SELECT id FROM hotel_import_jobs WHERE idempotency_key=? LIMIT 1').bind(idempotencyKey).first();
      if (existing?.id) return importJobDetail(env, existing.id, 200);
    }
    throw error;
  }

  await env.HOTELS_DB.prepare("UPDATE hotels SET lifecycle_state='importing', status='draft', updated_at=? WHERE id=?")
    .bind(now, hotelID).run();

  try {
    const instance = await env.HOTEL_IMPORT_WORKFLOW.create({
      id: jobID,
      params: { jobID, hotelID, images, publishWhenComplete: canPublish, snapshotHash }
    });
    await env.HOTELS_DB.prepare(`
      UPDATE hotel_import_jobs SET workflow_instance_id = ?, updated_at = ?, heartbeat_at = ? WHERE id = ?
    `).bind(instance.id, new Date().toISOString(), new Date().toISOString(), jobID).run();
  } catch (error) {
    console.error('HOTEL_WORKFLOW_START_FAILED', error);
    const failedAt = new Date().toISOString();
    await env.HOTELS_DB.batch([
      env.HOTELS_DB.prepare(`
        UPDATE hotel_import_jobs SET status = 'failed', stage = 'start_failed', error = ?, last_error_code='WORKFLOW_START_FAILED', completed_at = ?, updated_at = ?, heartbeat_at = ? WHERE id = ?
      `).bind(String(error?.message || error).slice(0, 1200), failedAt, failedAt, failedAt, jobID),
      env.HOTELS_DB.prepare("UPDATE hotels SET lifecycle_state='failed', status='draft', updated_at=? WHERE id=?").bind(failedAt, hotelID)
    ]);
    return json({ ok: false, error: 'IMPORT_WORKFLOW_START_FAILED', jobID }, 503);
  }

  return importJobDetail(env, jobID, 202);
}


async function reconcileStaleImportJobs(env) {
  const cutoffMs = Date.now() - 15 * 60 * 1000;
  const result = await env.HOTELS_DB.prepare(`
    SELECT id, hotel_id, workflow_instance_id, status, stage, updated_at, heartbeat_at
    FROM hotel_import_jobs
    WHERE status IN ('queued','running')
    ORDER BY updated_at ASC
    LIMIT 40
  `).all();

  for (const row of result.results || []) {
    const heartbeat = Date.parse(row.heartbeat_at || row.updated_at || '');
    if (Number.isFinite(heartbeat) && heartbeat >= cutoffMs) continue;

    let workflowStatus = 'unknown';
    let workflowError = null;
    if (row.workflow_instance_id) {
      try {
        const instance = await env.HOTEL_IMPORT_WORKFLOW.get(row.workflow_instance_id);
        const details = await instance.status();
        workflowStatus = details?.status || 'unknown';
        workflowError = details?.error?.message || null;
        if (['running','queued','waiting','waitingForPause','paused'].includes(workflowStatus)) {
          await instance.terminate().catch(() => {});
          workflowStatus = 'terminated';
        }
      } catch (error) {
        workflowError = String(error?.message || error).slice(0, 500);
      }
    }

    const now = new Date().toISOString();
    const reason = workflowError
      ? `STALE_IMPORT_RECOVERED: ${workflowError}`
      : `STALE_IMPORT_RECOVERED: workflow=${workflowStatus}`;
    await env.HOTELS_DB.batch([
      env.HOTELS_DB.prepare(`
        UPDATE hotel_import_jobs
        SET status='failed', stage='stale_recovered', progress=MIN(progress, 99), error=?, last_error_code='STALE_IMPORT',
            completed_at=COALESCE(completed_at, ?), updated_at=?, heartbeat_at=?
        WHERE id=? AND status IN ('queued','running')
      `).bind(reason.slice(0, 1200), now, now, now, row.id),
      env.HOTELS_DB.prepare(`
        UPDATE hotels SET status='draft', lifecycle_state='failed', updated_at=?
        WHERE id=? AND status!='published'
      `).bind(now, row.hotel_id)
    ]);
  }
}

async function terminateWorkflowForJob(env, row) {
  if (!row?.workflow_instance_id) return;
  try {
    const instance = await env.HOTEL_IMPORT_WORKFLOW.get(row.workflow_instance_id);
    const status = await instance.status().catch(() => null);
    if (!status || !['complete','errored','terminated'].includes(status.status)) {
      await instance.terminate().catch(() => {});
    }
  } catch (_) {}
}

async function cancelImportJob(env, jobID) {
  const row = await env.HOTELS_DB.prepare('SELECT * FROM hotel_import_jobs WHERE id=?').bind(jobID).first();
  if (!row) return json({ ok: false, error: 'IMPORT_JOB_NOT_FOUND' }, 404);
  if (!['queued','running'].includes(row.status)) return importJobDetail(env, jobID, 200);

  await terminateWorkflowForJob(env, row);
  const now = new Date().toISOString();
  await env.HOTELS_DB.batch([
    env.HOTELS_DB.prepare(`
      UPDATE hotel_import_jobs
      SET status='failed', stage='cancelled', error='Импорт остановлен пользователем.', last_error_code='CANCELLED',
          cancel_requested_at=?, completed_at=?, updated_at=?, heartbeat_at=?
      WHERE id=?
    `).bind(now, now, now, now, jobID),
    env.HOTELS_DB.prepare(`
      UPDATE hotels SET status='draft', lifecycle_state='failed', updated_at=?
      WHERE id=? AND status!='published'
    `).bind(now, row.hotel_id)
  ]);
  return importJobDetail(env, jobID, 200);
}

async function deleteImportJob(env, jobID) {
  const row = await env.HOTELS_DB.prepare('SELECT * FROM hotel_import_jobs WHERE id=?').bind(jobID).first();
  if (!row) return json({ ok: false, error: 'IMPORT_JOB_NOT_FOUND' }, 404);
  await terminateWorkflowForJob(env, row);
  await env.HOTELS_DB.prepare('DELETE FROM hotel_import_jobs WHERE id=?').bind(jobID).run();
  return json({ ok: true, deletedJobID: jobID, hotelID: row.hotel_id });
}

async function listImportJobs(env, url) {
  await reconcileStaleImportJobs(env);
  const activeOnly = url.searchParams.get('active') === '1';
  const sql = `
    SELECT * FROM hotel_import_jobs
    ${activeOnly ? "WHERE status IN ('queued','running')" : ''}
    ORDER BY created_at DESC
    LIMIT 80
  `;
  const result = await env.HOTELS_DB.prepare(sql).all();
  return json({ ok: true, jobs: (result.results || []).map(importJobRow) });
}

async function importJobDetail(env, jobID, status = 200) {
  await reconcileStaleImportJobs(env);
  const row = await env.HOTELS_DB.prepare('SELECT * FROM hotel_import_jobs WHERE id = ?').bind(jobID).first();
  if (!row) return json({ ok: false, error: 'IMPORT_JOB_NOT_FOUND' }, 404);
  return json({ ok: true, job: importJobRow(row) }, status);
}

async function retryImportJob(env, jobID) {
  const row = await env.HOTELS_DB.prepare('SELECT * FROM hotel_import_jobs WHERE id = ?').bind(jobID).first();
  if (!row) return json({ ok: false, error: 'IMPORT_JOB_NOT_FOUND' }, 404);
  if (!['failed'].includes(row.status)) return json({ ok: false, error: 'IMPORT_JOB_NOT_RETRYABLE' }, 409);

  const images = prioritizeImportImages(parseJSONArray(row.images_json), 48);
  const retryAt = new Date().toISOString();
  await env.HOTELS_DB.batch([
    env.HOTELS_DB.prepare(`
      UPDATE hotel_import_jobs
      SET status='queued', stage='retry_queued', progress=0, stored_images=0, failed_images=0, error=NULL, warning=NULL,
          current_image=0, current_image_label=NULL, compression_mode=NULL, last_error_code=NULL, cancel_requested_at=NULL,
          retry_count=retry_count+1, started_at=NULL, completed_at=NULL, updated_at=?, heartbeat_at=? WHERE id=?
    `).bind(retryAt, retryAt, jobID),
    env.HOTELS_DB.prepare("UPDATE hotels SET status='draft', lifecycle_state='importing', updated_at=? WHERE id=?")
      .bind(retryAt, row.hotel_id)
  ]);
  await deleteAllHotelImagesInternal(env, row.hotel_id);

  try {
    const instance = await env.HOTEL_IMPORT_WORKFLOW.create({
      id: `${jobID}-retry-${crypto.randomUUID().slice(0, 8)}`,
      params: { jobID, hotelID: row.hotel_id, images, publishWhenComplete: Number(row.publish_when_complete) === 1, snapshotHash: row.snapshot_hash || null }
    });
    await env.HOTELS_DB.prepare('UPDATE hotel_import_jobs SET workflow_instance_id=?, updated_at=?, heartbeat_at=? WHERE id=?')
      .bind(instance.id, new Date().toISOString(), new Date().toISOString(), jobID).run();
  } catch (error) {
    const failedAt = new Date().toISOString();
    await env.HOTELS_DB.batch([
      env.HOTELS_DB.prepare("UPDATE hotel_import_jobs SET status='failed', stage='start_failed', error=?, last_error_code='WORKFLOW_START_FAILED', updated_at=?, heartbeat_at=? WHERE id=?")
        .bind(String(error?.message || error).slice(0, 1200), failedAt, failedAt, jobID),
      env.HOTELS_DB.prepare("UPDATE hotels SET lifecycle_state='failed', status='draft', updated_at=? WHERE id=?")
        .bind(failedAt, row.hotel_id)
    ]);
    return json({ ok: false, error: 'IMPORT_WORKFLOW_START_FAILED' }, 503);
  }
  return importJobDetail(env, jobID, 202);
}

function importJobRow(row) {
  return {
    id: row.id,
    hotelID: row.hotel_id,
    hotelName: row.hotel_name,
    sourceProvider: row.source_provider || null,
    sourceURL: row.source_url || null,
    status: row.status,
    stage: row.stage,
    progress: Number(row.progress || 0),
    totalImages: Number(row.total_images || 0),
    storedImages: Number(row.stored_images || 0),
    failedImages: Number(row.failed_images || 0),
    publishWhenComplete: Number(row.publish_when_complete || 0) === 1,
    error: row.error || null,
    createdAt: row.created_at,
    startedAt: row.started_at || null,
    completedAt: row.completed_at || null,
    updatedAt: row.updated_at,
    retryCount: Number(row.retry_count || 0),
    snapshotHash: row.snapshot_hash || null,
    possibleDuplicate: parseJSONObject(row.possible_duplicate_json),
    currentImage: Number(row.current_image || 0),
    currentImageLabel: row.current_image_label || null,
    warning: row.warning || null,
    compressionMode: row.compression_mode || null,
    heartbeatAt: row.heartbeat_at || row.updated_at || null,
    lastErrorCode: row.last_error_code || null,
    cancelRequestedAt: row.cancel_requested_at || null
  };
}

export class HotelImportWorkflow extends WorkflowEntrypoint {
  async run(event, step) {
    const { jobID, hotelID, images = [], publishWhenComplete = false, snapshotHash = null } = event.payload || {};
    if (!safeID(jobID) || !safeID(hotelID) || !Array.isArray(images)) {
      throw new Error('INVALID_IMPORT_WORKFLOW_PAYLOAD');
    }

    await step.do('validate immutable snapshot', async () => {
      const row = await this.env.HOTELS_DB.prepare('SELECT snapshot_hash, hotel_snapshot_json FROM hotel_import_jobs WHERE id=? AND hotel_id=?')
        .bind(jobID, hotelID).first();
      if (!row) throw new Error('IMPORT_JOB_NOT_FOUND');
      const storedHash = cleanText(row.snapshot_hash, 128);
      if (snapshotHash && storedHash && snapshotHash !== storedHash) throw new Error('IMPORT_SNAPSHOT_MISMATCH');
      if (storedHash) {
        const recomputed = await sha256Hex(String(row.hotel_snapshot_json || '{}'));
        if (recomputed !== storedHash) throw new Error('IMPORT_SNAPSHOT_CORRUPTED');
      }
      return { ok: true, snapshotHash: storedHash || null };
    });

    await step.do('mark job running', async () => {
      const now = new Date().toISOString();
      await this.env.HOTELS_DB.batch([
        this.env.HOTELS_DB.prepare(`
          UPDATE hotel_import_jobs
          SET status='running', stage='preparing_media', progress=1, current_image=0, current_image_label=NULL, warning=NULL, started_at=COALESCE(started_at, ?), updated_at=?, heartbeat_at=?
          WHERE id=?
        `).bind(now, now, now, jobID),
        this.env.HOTELS_DB.prepare("UPDATE hotels SET status='draft', lifecycle_state='importing', updated_at=? WHERE id=?")
          .bind(now, hotelID)
      ]);
      return { ok: true };
    });

    let stored = 0;
    let failed = 0;
    const total = images.length;

    for (let index = 0; index < total; index += 1) {
      const item = images[index];
      const itemLabel = cleanText(item?.label || item?.roomName || item?.category || `Фото ${index + 1}`, 220);
      const startProgress = Math.min(92, Math.max(2, Math.round((index / Math.max(total, 1)) * 90)));
      await step.do(`announce image ${String(index + 1).padStart(3, '0')}`, async () => {
        await this.env.HOTELS_DB.prepare(`
          UPDATE hotel_import_jobs
          SET stage='downloading_image', progress=?, current_image=?, current_image_label=?, error=NULL, updated_at=?, heartbeat_at=?
          WHERE id=?
        `).bind(startProgress, index + 1, itemLabel, new Date().toISOString(), new Date().toISOString(), jobID).run();
        return { index: index + 1, label: itemLabel };
      });

      let result;
      try {
        result = await step.do(
          `store image ${String(index + 1).padStart(3, '0')}`,
          { retries: { limit: 2, delay: '3 seconds', backoff: 'exponential' }, timeout: '45 seconds' },
          async () => storeRemoteHotelImage(this.env, jobID, hotelID, item, index)
        );
      } catch (error) {
        result = { ok: false, error: String(error?.message || error).slice(0, 900) };
      }

      if (result?.ok) stored += 1;
      else failed += 1;

      const progress = Math.min(96, Math.max(3, Math.round(((index + 1) / Math.max(total, 1)) * 94)));
      await step.do(`record progress ${String(index + 1).padStart(3, '0')}`, async () => {
        await this.env.HOTELS_DB.prepare(`
          UPDATE hotel_import_jobs
          SET stored_images=?, failed_images=?, progress=?, stage=?, error=?, compression_mode=COALESCE(?, compression_mode), updated_at=?, heartbeat_at=?
          WHERE id=?
        `).bind(
          stored,
          failed,
          progress,
          result?.ok ? 'media_progress' : 'image_retry_exhausted',
          result?.ok ? null : result?.error || 'IMAGE_FAILED',
          result?.compressionMode || null,
          new Date().toISOString(),
          new Date().toISOString(),
          jobID
        ).run();
        return { stored, failed, progress };
      });
    }

    const finalState = await step.do('finalize hotel import', async () => {
      const now = new Date().toISOString();
      const [roomRow, coverRow] = await Promise.all([
        this.env.HOTELS_DB.prepare('SELECT COUNT(*) AS count FROM hotel_rooms WHERE hotel_id=?').bind(hotelID).first(),
        this.env.HOTELS_DB.prepare('SELECT COUNT(*) AS count FROM hotel_images WHERE hotel_id=? AND is_cover=1').bind(hotelID).first()
      ]);
      const roomCount = Number(roomRow?.count || 0);
      const coverCount = Number(coverRow?.count || 0);
      const requiredImages = Math.min(4, total);
      const mediaReady = total > 0 && stored >= requiredImages && coverCount > 0;
      const roomsReady = !publishWhenComplete || roomCount > 0;
      const completed = mediaReady && roomsReady;
      const withWarnings = completed && failed > 0;
      const warning = withWarnings ? `${failed} из ${total} фотографий недоступны у источника; сохранено ${stored}.` : null;
      let failureReason = null;
      if (!mediaReady) failureReason = `Сохранено только ${stored} из ${total} фотографий; для готовой карточки требуется минимум ${requiredImages} и обложка.`;
      else if (!roomsReady) failureReason = 'Не найдено ни одного подтверждённого типа номера; публикация остановлена.';

      if (completed && publishWhenComplete) {
        await this.env.HOTELS_DB.prepare("UPDATE hotels SET status='published', lifecycle_state='published', updated_at=? WHERE id=?")
          .bind(now, hotelID).run();
      } else if (completed) {
        await this.env.HOTELS_DB.prepare("UPDATE hotels SET status='draft', lifecycle_state='ready', updated_at=? WHERE id=?")
          .bind(now, hotelID).run();
      } else {
        await this.env.HOTELS_DB.prepare("UPDATE hotels SET status='draft', lifecycle_state='failed', updated_at=? WHERE id=?")
          .bind(now, hotelID).run();
      }
      await this.env.HOTELS_DB.prepare(`
        UPDATE hotel_import_jobs
        SET status=?, stage=?, progress=100, stored_images=?, failed_images=?, current_image=?, current_image_label=NULL,
            completed_at=?, updated_at=?, heartbeat_at=?, error=?, warning=?
        WHERE id=?
      `).bind(
        completed ? 'completed' : 'failed',
        completed ? (withWarnings ? 'completed_with_warnings' : 'completed') : 'integrity_failed',
        stored,
        failed,
        total,
        now,
        now,
        now,
        completed ? null : failureReason || 'IMPORT_INTEGRITY_FAILED',
        warning,
        jobID
      ).run();
      return { completed, stored, failed, total, hotelID, roomCount, coverCount, warning };
    });

    if (finalState.completed && publishWhenComplete) {
      await step.do('prewarm hotel translations', { retries: { limit: 2, delay: '5 seconds', backoff: 'exponential' }, timeout: '2 minutes' }, async () => {
        try {
          await prewarmHotelTranslations(this.env, hotelID);
          return { ok: true };
        } catch (error) {
          console.error('HOTEL_TRANSLATION_PREWARM_FAILED', { hotelID, error: String(error?.message || error) });
          return { ok: false };
        }
      });
    }

    await step.do('notify business device', async () => {
      try {
        const row = await this.env.HOTELS_DB.prepare('SELECT hotel_name FROM hotel_import_jobs WHERE id=?').bind(jobID).first();
        const title = finalState.completed ? 'Импорт отеля завершён' : 'Ошибка импорта отеля';
        const body = finalState.completed
          ? `${row?.hotel_name || 'Отель'} · сохранено ${finalState.stored} фото${finalState.warning ? ' · есть предупреждение' : ''}.`
          : `${row?.hotel_name || 'Отель'} · импорт требует проверки.`;
        return await sendStaffPush(this.env, title, body, { event: 'hotel_import', jobID, hotelID });
      } catch (error) {
        console.error('BUSINESS_PUSH_FAILED', String(error?.message || error));
        return { ok: false };
      }
    });

    return finalState;
  }
}

async function storeRemoteHotelImage(env, jobID, hotelID, item, fallbackPosition) {
  const sourceURL = cleanURL(item?.url);
  if (!sourceURL) throw new Error('INVALID_IMAGE_URL');
  const category = validImageCategory(item?.category) || 'gallery';
  const isCover = item?.isCover === true ? 1 : 0;
  const optimizedSourceURL = optimizeProviderImageURL(sourceURL, category, isCover === 1);
  const headers = new Headers({
    'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) AppleWebKit/605.1.15 Version/17.6 Mobile/15E148 Safari/604.1',
    'accept': 'image/avif,image/webp,image/jpeg,image/png,image/*;q=0.8',
    'accept-language': 'en-US,en;q=0.9'
  });
  if (cleanURL(item?.sourcePageURL)) headers.set('referer', item.sourcePageURL);

  const response = await fetch(optimizedSourceURL, { headers, redirect: 'follow' });
  if (!response.ok) throw new Error(`IMAGE_HTTP_${response.status}`);
  const sourceContentType = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!['image/jpeg','image/jpg','image/png','image/webp','image/avif'].includes(sourceContentType)) {
    throw new Error(`UNSUPPORTED_IMAGE_TYPE_${sourceContentType || 'unknown'}`);
  }
  const announced = Number(response.headers.get('content-length') || 0);
  if (announced > 12 * 1024 * 1024) throw new Error('IMAGE_TOO_LARGE');
  const sourceBytes = await response.arrayBuffer();
  if (!sourceBytes.byteLength) throw new Error('EMPTY_IMAGE');
  if (sourceBytes.byteLength > 12 * 1024 * 1024) throw new Error('IMAGE_TOO_LARGE');

  const provider = cleanText(item?.provider, 80) || 'unknown';
  const label = cleanText(item?.label, 600);
  const roomName = cleanText(item?.roomName, 260);
  const position = boundedInteger(item?.position, 0, 10000, fallbackPosition);
  const sourceDedupeKey = canonicalImageSourceKey(sourceURL);

  await updateImportJobStage(env, jobID, 'optimizing_image');
  const transformed = await optimizeHotelImageBytes(env, sourceBytes, { category, isCover: isCover === 1, sourceContentType });
  await updateImportJobStage(env, jobID, 'saving_to_r2');
  const contentHash = await sha256HexBytes(transformed.bytes);

  const existing = await env.HOTELS_DB.prepare(`
    SELECT id, object_key FROM hotel_images
    WHERE hotel_id=? AND (content_hash=? OR (? IS NOT NULL AND source_dedupe_key=?))
    LIMIT 1
  `).bind(hotelID, contentHash, sourceDedupeKey, sourceDedupeKey).first();
  if (existing?.id) {
    if (isCover) {
      await env.HOTELS_DB.batch([
        env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=0 WHERE hotel_id=?').bind(hotelID),
        env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=1, category=?, label=COALESCE(?, label), room_name=COALESCE(?, room_name), position=? WHERE id=?')
          .bind(category, label, roomName, position, existing.id)
      ]);
    }
    return { ok: true, imageID: existing.id, byteSize: transformed.bytes.byteLength, deduplicated: true, compressionMode: transformed.transformVersion };
  }

  const imageID = crypto.randomUUID();
  const objectKey = `hotels/${hotelID}/${contentHash.slice(0, 32)}.${transformed.extension}`;
  await env.HOTELS_MEDIA.put(objectKey, transformed.bytes, {
    httpMetadata: {
      contentType: transformed.contentType,
      cacheControl: 'public, max-age=31536000, immutable'
    },
    customMetadata: {
      hotelID,
      provider,
      category,
      roomName: roomName || '',
      source: 'background-import',
      contentHash,
      transformVersion: transformed.transformVersion
    }
  });

  try {
    const statements = [];
    if (isCover) statements.push(env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=0 WHERE hotel_id=?').bind(hotelID));
    statements.push(env.HOTELS_DB.prepare(`
      INSERT INTO hotel_images (
        id, hotel_id, object_key, source_provider, source_url, category, label, room_name,
        content_type, byte_size, position, is_cover, content_hash, width, height,
        original_byte_size, transform_version, source_dedupe_key
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      imageID,
      hotelID,
      objectKey,
      provider,
      sourceURL,
      category,
      label,
      roomName,
      transformed.contentType,
      transformed.bytes.byteLength,
      position,
      isCover,
      contentHash,
      transformed.width,
      transformed.height,
      sourceBytes.byteLength,
      transformed.transformVersion,
      sourceDedupeKey
    ));
    await env.HOTELS_DB.batch(statements);
  } catch (error) {
    // Concurrent imports can legitimately race on the deterministic content-hash object key.
    // If another transaction already claimed the same optimized image, treat this write as
    // an idempotent success and never delete the shared R2 object out from under the winner.
    const concurrent = await env.HOTELS_DB.prepare(`
      SELECT id FROM hotel_images
      WHERE hotel_id=? AND (content_hash=? OR object_key=?)
      LIMIT 1
    `).bind(hotelID, contentHash, objectKey).first().catch(() => null);
    if (concurrent?.id) {
      if (isCover) {
        await env.HOTELS_DB.batch([
          env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=0 WHERE hotel_id=?').bind(hotelID),
          env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=1, category=?, label=COALESCE(?, label), room_name=COALESCE(?, room_name), position=? WHERE id=?')
            .bind(category, label, roomName, position, concurrent.id)
        ]).catch(() => {});
      }
      return { ok: true, imageID: concurrent.id, byteSize: transformed.bytes.byteLength, deduplicated: true, raced: true, compressionMode: transformed.transformVersion };
    }
    await env.HOTELS_MEDIA.delete(objectKey).catch(() => {});
    throw error;
  }

  return {
    ok: true,
    imageID,
    byteSize: transformed.bytes.byteLength,
    originalByteSize: sourceBytes.byteLength,
    width: transformed.width,
    height: transformed.height,
    contentHash,
    compressionMode: transformed.transformVersion
  };
}

async function updateImportJobStage(env, jobID, stage) {
  if (!safeID(jobID)) return;
  await env.HOTELS_DB.prepare('UPDATE hotel_import_jobs SET stage=?, updated_at=?, heartbeat_at=? WHERE id=?')
    .bind(stage, new Date().toISOString(), new Date().toISOString(), jobID).run().catch(() => {});
}

async function optimizeHotelImageBytes(env, sourceBytes, { category = 'gallery', isCover = false, sourceContentType = 'image/jpeg' } = {}) {
  const primary = imageTransformProfile(category, isCover, false);
  if (env.IMAGES) {
    try {
      let result = await runImageTransform(env, sourceBytes, primary);
      if (result.bytes.byteLength > primary.maxBytes) {
        const fallback = imageTransformProfile(category, isCover, true);
        result = await runImageTransform(env, sourceBytes, fallback);
        if (result.bytes.byteLength > fallback.maxBytes) throw new Error('OPTIMIZED_IMAGE_TOO_LARGE');
      }
      return { ...result, contentType: 'image/webp', extension: 'webp' };
    } catch (error) {
      console.warn('CLOUDFLARE_IMAGE_TRANSFORM_FALLBACK', String(error?.message || error));
    }
  }

  // Resilient fallback: the source URL itself is requested at a bounded provider
  // resolution. If that already-compressed representation fits our R2 budget, keep
  // it; never fall back to a multi-megabyte original.
  const fallback = imageTransformProfile(category, isCover, true);
  if (sourceBytes.byteLength > fallback.maxBytes) throw new Error('IMAGE_COMPRESSION_UNAVAILABLE_AND_SOURCE_TOO_LARGE');
  const normalizedType = sourceContentType === 'image/jpg' ? 'image/jpeg' : sourceContentType;
  const extension = normalizedType === 'image/png' ? 'png' : normalizedType === 'image/webp' ? 'webp' : normalizedType === 'image/avif' ? 'avif' : 'jpg';
  return {
    bytes: sourceBytes,
    width: null,
    height: null,
    transformVersion: 'provider-sized-fallback-v1',
    contentType: normalizedType,
    extension
  };
}

function imageTransformProfile(category, isCover, fallback) {
  const detailed = ['room','bathroom','restaurant','breakfast','lobby','view','spa','gym','pool','lounge'].includes(category);
  if (isCover) {
    return fallback
      ? { width: 1440, height: 1080, quality: 74, maxBytes: 700_000, transformVersion: 'cf-webp-cover-v3' }
      : { width: 1600, height: 1200, quality: 80, maxBytes: 900_000, transformVersion: 'cf-webp-cover-v3' };
  }
  return fallback
    ? { width: detailed ? 1120 : 1024, height: detailed ? 840 : 768, quality: 70, maxBytes: 480_000, transformVersion: 'cf-webp-standard-v3' }
    : { width: detailed ? 1280 : 1120, height: detailed ? 960 : 840, quality: 76, maxBytes: 650_000, transformVersion: 'cf-webp-standard-v3' };
}

async function runImageTransform(env, sourceBytes, profile) {
  const sourceStream = new Blob([sourceBytes]).stream();
  const transformedResponse = (
    await env.IMAGES
      .input(sourceStream)
      .transform({ width: profile.width, height: profile.height, fit: 'scale-down' })
      .output({ format: 'image/webp', quality: profile.quality, anim: false })
  ).response();

  if (!transformedResponse.ok) throw new Error(`IMAGE_TRANSFORM_HTTP_${transformedResponse.status}`);
  const bytes = await transformedResponse.arrayBuffer();
  if (!bytes.byteLength) throw new Error('IMAGE_TRANSFORM_EMPTY');
  const info = await env.IMAGES.info(new Blob([bytes], { type: 'image/webp' }).stream()).catch(() => null);
  return {
    bytes,
    width: nullableInteger(info?.width, 1, 20000),
    height: nullableInteger(info?.height, 1, 20000),
    transformVersion: profile.transformVersion
  };
}

function optimizeProviderImageURL(value, category = 'gallery', isCover = false) {
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    const detailed = ['room','bathroom','restaurant','breakfast','lobby','view','spa','gym','pool','lounge'].includes(category);
    const width = isCover ? 1600 : (detailed ? 1280 : 1120);
    const height = isCover ? 1200 : (detailed ? 960 : 840);
    if (host.includes('trvl-media.com') || host.includes('expedia')) {
      url.searchParams.set('impolicy', 'resizecrop');
      url.searchParams.set('rw', String(width));
      url.searchParams.set('ra', 'fit');
    }
    if (host.includes('bstatic.com') || host.includes('booking.com')) {
      url.pathname = url.pathname.replace(/\/(?:max|square|smart)[0-9x_-]+\//ig, `/max${width}x${height}/`);
    }
    return url.toString();
  } catch {
    return value;
  }
}

function canonicalImageSourceKey(value) {
  try {
    const url = new URL(String(value || ''));
    url.hash = '';
    url.hostname = url.hostname.toLowerCase();
    url.pathname = url.pathname.replace(/\/(?:max|square|smart)[0-9x_-]+\//ig, '/SIZE/');
    for (const key of [...url.searchParams.keys()]) {
      if (['rw','ra','quality','impolicy','w','h','width','height'].includes(key.toLowerCase())) url.searchParams.delete(key);
    }
    return cleanText(url.toString(), 3000);
  } catch {
    return null;
  }
}

async function deleteAllHotelImagesInternal(env, hotelID) {
  const rows = await env.HOTELS_DB.prepare('SELECT object_key FROM hotel_images WHERE hotel_id=?').bind(hotelID).all();
  await Promise.allSettled((rows.results || []).map(row => env.HOTELS_MEDIA.delete(row.object_key)));
  await env.HOTELS_DB.prepare('DELETE FROM hotel_images WHERE hotel_id=?').bind(hotelID).run();
}

async function hotelTranslation(env, hotelID, rawLocale) {
  const locale = normalizeLocale(rawLocale);
  if (!locale) return json({ ok: false, error: 'UNSUPPORTED_LOCALE' }, 400);
  const hotelResponse = await hotelDataForTranslation(env, hotelID);
  if (!hotelResponse) return json({ ok: false, error: 'HOTEL_NOT_FOUND' }, 404);

  try {
    const result = await getOrCreateHotelTranslation(env, hotelID, locale, hotelResponse);
    return json({ ok: true, locale, cached: result.cached, translation: result.translation }, 200, PUBLIC_CACHE_HEADERS);
  } catch (error) {
    console.error('HOTEL_TRANSLATION_FAILED', { hotelID, locale, error: String(error?.message || error) });
    return json({ ok: false, error: 'TRANSLATION_UNAVAILABLE' }, 503);
  }
}

async function getOrCreateHotelTranslation(env, hotelID, locale, hotelResponse) {
  if (locale === 'en') return { cached: true, translation: hotelResponse };

  const version = locale === 'uz-Cyrl' ? 'uz-cyrl-deterministic-v1' : 'ai-json-v2';
  const sourceHash = await sha256Hex(`${version}|${JSON.stringify(hotelResponse)}`);
  const cached = await env.HOTELS_DB.prepare('SELECT source_hash, payload_json FROM hotel_translations WHERE hotel_id=? AND locale=?')
    .bind(hotelID, locale).first();
  if (cached?.source_hash === sourceHash) {
    try {
      return { cached: true, translation: JSON.parse(cached.payload_json) };
    } catch {}
  }

  let translated;
  if (locale === 'uz-Cyrl') {
    // Uzbek Cyrillic is derived from the cached/validated Uzbek Latin payload so
    // we do not spend a second LLM request and do not get two semantically
    // divergent Uzbek translations for one hotel.
    const latin = await getOrCreateHotelTranslation(env, hotelID, 'uz-Latn', hotelResponse);
    translated = transliterateUzbekObject(latin.translation);
  } else {
    const languageName = locale === 'ru' ? 'Russian' : 'Uzbek in Latin script';
    const system = `You are a hotel localization engine. Translate all human-readable hotel content in the supplied JSON into ${languageName}. Preserve JSON keys, IDs, URLs, numbers, measurements, times, hotel/brand/chain names and source provenance. Never invent missing information, amenities, fees, room data or distances. Do not summarize. Return ONLY valid JSON with exactly the same structure.`;
    const ai = await env.AI.run('@cf/zai-org/glm-4.7-flash', {
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: JSON.stringify(hotelResponse) }
      ],
      max_tokens: 14000,
      temperature: 0.03
    });
    const answer = ai?.response ?? ai?.result?.response ?? ai?.choices?.[0]?.message?.content;
    translated = parseJSONEnvelope(answer);
    if (!translated || typeof translated !== 'object') throw new Error('TRANSLATION_INVALID');
  }

  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO hotel_translations (hotel_id, locale, source_hash, payload_json, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(hotel_id, locale) DO UPDATE SET source_hash=excluded.source_hash, payload_json=excluded.payload_json, updated_at=excluded.updated_at
  `).bind(hotelID, locale, sourceHash, JSON.stringify(translated), now, now).run();
  return { cached: false, translation: translated };
}

async function prewarmHotelTranslations(env, hotelID) {
  const hotelResponse = await hotelDataForTranslation(env, hotelID);
  if (!hotelResponse) return;
  await getOrCreateHotelTranslation(env, hotelID, 'ru', hotelResponse);
  await getOrCreateHotelTranslation(env, hotelID, 'uz-Latn', hotelResponse);
  await getOrCreateHotelTranslation(env, hotelID, 'uz-Cyrl', hotelResponse);
}

function transliterateUzbekObject(value, key = '') {
  if (Array.isArray(value)) return value.map(item => transliterateUzbekObject(item, key));
  if (value && typeof value === 'object') {
    const out = {};
    for (const [childKey, child] of Object.entries(value)) out[childKey] = transliterateUzbekObject(child, childKey);
    return out;
  }
  if (typeof value !== 'string') return value;
  const preserveKeys = new Set(['id','url','sourceURL','canonicalURL','googleMapsURL','name','brand','chain','postalCode']);
  if (preserveKeys.has(key) || /^https?:\/\//i.test(value)) return value;
  return uzbekLatinToCyrillic(value);
}

function uzbekLatinToCyrillic(input) {
  const replacements = [
    [/O[‘’ʻʼ'`]/g, 'Ў'], [/o[‘’ʻʼ'`]/g, 'ў'],
    [/G[‘’ʻʼ'`]/g, 'Ғ'], [/g[‘’ʻʼ'`]/g, 'ғ'],
    [/Sh/g, 'Ш'], [/SH/g, 'Ш'], [/sh/g, 'ш'],
    [/Ch/g, 'Ч'], [/CH/g, 'Ч'], [/ch/g, 'ч'],
    [/Yo/g, 'Ё'], [/YO/g, 'Ё'], [/yo/g, 'ё'],
    [/Yu/g, 'Ю'], [/YU/g, 'Ю'], [/yu/g, 'ю'],
    [/Ya/g, 'Я'], [/YA/g, 'Я'], [/ya/g, 'я'],
    [/Ts/g, 'Ц'], [/TS/g, 'Ц'], [/ts/g, 'ц']
  ];
  let text = String(input || '');
  for (const [pattern, replacement] of replacements) text = text.replace(pattern, replacement);
  const map = {
    A:'А', B:'Б', C:'С', D:'Д', E:'Е', F:'Ф', G:'Г', H:'Ҳ', I:'И', J:'Ж', K:'К', L:'Л', M:'М', N:'Н', O:'О', P:'П', Q:'Қ', R:'Р', S:'С', T:'Т', U:'У', V:'В', W:'В', X:'Х', Y:'Й', Z:'З',
    a:'а', b:'б', c:'с', d:'д', e:'е', f:'ф', g:'г', h:'ҳ', i:'и', j:'ж', k:'к', l:'л', m:'м', n:'н', o:'о', p:'п', q:'қ', r:'р', s:'с', t:'т', u:'у', v:'в', w:'в', x:'х', y:'й', z:'з'
  };
  return [...text].map(ch => map[ch] || ch).join('');
}

async function hotelDataForTranslation(env, hotelID) {
  const hotel = await env.HOTELS_DB.prepare("SELECT * FROM hotels WHERE id=? AND status='published'").bind(hotelID).first();
  if (!hotel) return null;
  const [amenities, rooms] = await Promise.all([
    env.HOTELS_DB.prepare('SELECT amenity FROM hotel_amenities WHERE hotel_id=? ORDER BY position').bind(hotelID).all(),
    env.HOTELS_DB.prepare('SELECT id,name,max_guests,size_m2,beds,view,description,amenities_json,smoking,accessibility_json,category,bathroom_json FROM hotel_rooms WHERE hotel_id=? ORDER BY position').bind(hotelID).all()
  ]);
  return {
    name: hotel.name,
    city: hotel.city,
    country: hotel.country,
    propertyType: hotel.property_type || null,
    brand: hotel.brand || null,
    chain: hotel.chain_name || null,
    postalCode: hotel.postal_code || null,
    address: hotel.address || '',
    description: hotel.description || '',
    checkIn: hotel.check_in || null,
    checkOut: hotel.check_out || null,
    amenities: (amenities.results || []).map(x => x.amenity),
    policies: parseJSONArray(hotel.policies_json),
    nearby: parseJSONArray(hotel.nearby_json),
    facts: parseJSONArray(hotel.facts_json),
    fees: parseJSONArray(hotel.fees_json),
    services: parseJSONArray(hotel.services_json),
    highlights: parseJSONArray(hotel.highlights_json),
    importantInformation: parseJSONArray(hotel.important_information_json),
    food: parseJSONArray(hotel.food_json),
    parkingTransport: parseJSONArray(hotel.parking_transport_json),
    accessibility: parseJSONArray(hotel.accessibility_json),
    rooms: (rooms.results || []).map(row => ({
      id: row.id,
      name: row.name,
      maxGuests: row.max_guests == null ? null : Number(row.max_guests),
      sizeM2: row.size_m2 == null ? null : Number(row.size_m2),
      beds: row.beds || null,
      view: row.view || null,
      description: row.description || null,
      amenities: parseJSONArray(row.amenities_json),
      smoking: row.smoking || null,
      accessibility: parseJSONArray(row.accessibility_json),
      category: row.category || null,
      bathroom: parseJSONArray(row.bathroom_json)
    }))
  };
}

function normalizeLocale(value) {
  const raw = String(value || '').trim().replace('_', '-').toLowerCase();
  if (raw === 'en' || raw.startsWith('en-')) return 'en';
  if (raw === 'ru' || raw.startsWith('ru-')) return 'ru';
  if (['uz','uz-latn','uz-latin'].includes(raw)) return 'uz-Latn';
  if (['uz-cyrl','uz-cyrillic','uz-uz-cyrl'].includes(raw)) return 'uz-Cyrl';
  return null;
}

async function sha256Hex(value) {
  const bytes = new TextEncoder().encode(value);
  return sha256HexBytes(bytes);
}

async function sha256HexBytes(value) {
  const bytes = value instanceof ArrayBuffer
    ? value
    : ArrayBuffer.isView(value)
      ? value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength)
      : new Uint8Array(value).buffer;
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, '0')).join('');
}

function parseJSONEnvelope(value) {
  if (typeof value !== 'string') return value;
  const trimmed = value.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  try { return JSON.parse(trimmed); } catch {}
  const start = Math.min(...['{','['].map(ch => trimmed.indexOf(ch)).filter(i => i >= 0));
  const end = Math.max(trimmed.lastIndexOf('}'), trimmed.lastIndexOf(']'));
  if (Number.isFinite(start) && start >= 0 && end > start) {
    try { return JSON.parse(trimmed.slice(start, end + 1)); } catch {}
  }
  return null;
}

async function deleteAllHotelImages(env, hotelID) {
  const hotel = await env.HOTELS_DB.prepare('SELECT id FROM hotels WHERE id = ?').bind(hotelID).first();
  if (!hotel) return json({ ok: false, error: 'HOTEL_NOT_FOUND' }, 404);

  const rows = await env.HOTELS_DB.prepare(
    'SELECT object_key FROM hotel_images WHERE hotel_id = ?'
  ).bind(hotelID).all();

  await Promise.allSettled((rows.results || []).map(row => env.HOTELS_MEDIA.delete(row.object_key)));
  await env.HOTELS_DB.batch([
    env.HOTELS_DB.prepare('DELETE FROM hotel_images WHERE hotel_id = ?').bind(hotelID),
    env.HOTELS_DB.prepare("UPDATE hotels SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").bind(hotelID)
  ]);

  return json({ ok: true, deleted: (rows.results || []).length }, 200);
}

async function uploadHotelImage(request, env, hotelID) {
  const hotel = await env.HOTELS_DB.prepare('SELECT id, status FROM hotels WHERE id = ?').bind(hotelID).first();
  if (!hotel) return json({ ok: false, error: 'HOTEL_NOT_FOUND' }, 404);

  const contentType = (request.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/avif'].includes(contentType)) {
    return json({ ok: false, error: 'UNSUPPORTED_IMAGE_TYPE' }, 415);
  }

  const sourceBytes = await request.arrayBuffer();
  if (!sourceBytes.byteLength) return json({ ok: false, error: 'EMPTY_IMAGE' }, 400);
  if (sourceBytes.byteLength > 12 * 1024 * 1024) return json({ ok: false, error: 'IMAGE_TOO_LARGE' }, 413);

  const provider = cleanText(request.headers.get('x-iumrah-source'), 80) || 'manual';
  const category = validImageCategory(request.headers.get('x-iumrah-category')) || 'gallery';
  const sourceURL = cleanURL(request.headers.get('x-iumrah-source-url'));
  const label = cleanText(request.headers.get('x-iumrah-label'), 600);
  const roomName = cleanText(request.headers.get('x-iumrah-room'), 260);
  const position = boundedInteger(request.headers.get('x-iumrah-position'), 0, 10000, 0);
  const isCover = request.headers.get('x-iumrah-cover') === '1' ? 1 : 0;

  const transformed = await optimizeHotelImageBytes(env, sourceBytes, { category, isCover: isCover === 1, sourceContentType: contentType });
  const contentHash = await sha256HexBytes(transformed.bytes);
  const sourceDedupeKey = sourceURL ? canonicalImageSourceKey(sourceURL) : null;
  const existing = await env.HOTELS_DB.prepare('SELECT id FROM hotel_images WHERE hotel_id=? AND content_hash=? LIMIT 1')
    .bind(hotelID, contentHash).first();
  if (existing?.id) {
    if (isCover) {
      await env.HOTELS_DB.batch([
        env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=0 WHERE hotel_id=?').bind(hotelID),
        env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=1, category=?, label=COALESCE(?, label), room_name=COALESCE(?, room_name), position=? WHERE id=?')
          .bind(category, label, roomName, position, existing.id)
      ]);
    }
    return json({ ok: true, deduplicated: true, image: { id: existing.id, url: publicImagePath(hotelID, existing.id) } }, 200);
  }

  const imageID = crypto.randomUUID();
  const objectKey = `hotels/${hotelID}/${contentHash.slice(0, 32)}.${transformed.extension}`;
  await env.HOTELS_MEDIA.put(objectKey, transformed.bytes, {
    httpMetadata: { contentType: transformed.contentType, cacheControl: 'public, max-age=31536000, immutable' },
    customMetadata: { hotelID, provider, category, roomName: roomName || '', contentHash, transformVersion: transformed.transformVersion }
  });

  const statements = [];
  if (isCover) statements.push(env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover = 0 WHERE hotel_id = ?').bind(hotelID));
  statements.push(
    env.HOTELS_DB.prepare(`
      INSERT INTO hotel_images (
        id, hotel_id, object_key, source_provider, source_url, category, label, room_name, content_type,
        byte_size, position, is_cover, content_hash, width, height, original_byte_size, transform_version, source_dedupe_key
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      imageID, hotelID, objectKey, provider, sourceURL, category, label, roomName, transformed.contentType,
      transformed.bytes.byteLength, position, isCover, contentHash, transformed.width, transformed.height,
      sourceBytes.byteLength, transformed.transformVersion, sourceDedupeKey
    )
  );
  statements.push(env.HOTELS_DB.prepare("UPDATE hotels SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").bind(hotelID));

  try {
    await env.HOTELS_DB.batch(statements);
  } catch (error) {
    // Same race protection as the background workflow: a unique content-hash collision
    // means the optimized object is already owned by this hotel, not that R2 should delete it.
    const concurrent = await env.HOTELS_DB.prepare(`
      SELECT id FROM hotel_images
      WHERE hotel_id=? AND (content_hash=? OR object_key=?)
      LIMIT 1
    `).bind(hotelID, contentHash, objectKey).first().catch(() => null);
    if (concurrent?.id) {
      if (isCover) {
        await env.HOTELS_DB.batch([
          env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=0 WHERE hotel_id=?').bind(hotelID),
          env.HOTELS_DB.prepare('UPDATE hotel_images SET is_cover=1, category=?, label=COALESCE(?, label), room_name=COALESCE(?, room_name), position=? WHERE id=?')
            .bind(category, label, roomName, position, concurrent.id)
        ]).catch(() => {});
      }
      return json({ ok: true, deduplicated: true, raced: true, image: { id: concurrent.id, url: publicImagePath(hotelID, concurrent.id) } }, 200);
    }
    await env.HOTELS_MEDIA.delete(objectKey).catch(() => {});
    throw error;
  }

  return json({
    ok: true,
    image: {
      id: imageID,
      url: publicImagePath(hotelID, imageID),
      position,
      isCover: isCover === 1,
      category,
      roomName: roomName || '',
      width: transformed.width,
      height: transformed.height,
      byteSize: transformed.bytes.byteLength,
      originalByteSize: sourceBytes.byteLength,
      format: transformed.extension
    }
  }, 201);
}

async function serveHotelImage(env, hotelID, imageID, admin) {
  const row = await env.HOTELS_DB.prepare(`
    SELECT hi.object_key, hi.content_type, h.status
    FROM hotel_images hi
    JOIN hotels h ON h.id = hi.hotel_id
    WHERE hi.hotel_id = ? AND hi.id = ?
  `).bind(hotelID, imageID).first();

  if (!row) return new Response('Not Found', { status: 404 });
  if (!admin && row.status !== 'published') return new Response('Not Found', { status: 404 });

  const object = await env.HOTELS_MEDIA.get(row.object_key);
  if (!object) return new Response('Not Found', { status: 404 });

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set('content-type', row.content_type || headers.get('content-type') || 'image/jpeg');
  headers.set('cache-control', admin ? 'private, max-age=60' : 'public, max-age=86400, s-maxage=604800');
  if (object.httpEtag) headers.set('etag', object.httpEtag);
  return new Response(object.body, { headers });
}

async function deleteHotel(env, hotelID) {
  const hotel = await env.HOTELS_DB.prepare('SELECT id FROM hotels WHERE id=?').bind(hotelID).first();
  if (!hotel) return json({ ok: false, error: 'HOTEL_NOT_FOUND' }, 404);

  const [images, jobs] = await Promise.all([
    env.HOTELS_DB.prepare('SELECT object_key FROM hotel_images WHERE hotel_id = ?').bind(hotelID).all(),
    env.HOTELS_DB.prepare("SELECT * FROM hotel_import_jobs WHERE hotel_id=? AND status IN ('queued','running')").bind(hotelID).all()
  ]);

  // Never delete a canonical row while a workflow can still write into it.
  for (const job of jobs.results || []) await terminateWorkflowForJob(env, job);

  const result = await env.HOTELS_DB.prepare('DELETE FROM hotels WHERE id = ?').bind(hotelID).run();
  if (!result.meta?.changes) return json({ ok: false, error: 'HOTEL_NOT_FOUND' }, 404);

  await Promise.allSettled((images.results || []).map(row => env.HOTELS_MEDIA.delete(row.object_key)));
  return json({ ok: true, deletedHotelID: hotelID });
}

async function summaryRow(env, hotelID) {
  return env.HOTELS_DB.prepare(`
    SELECT
      h.id,
      h.name,
      h.city,
      h.stars,
      h.rating,
      h.review_count,
      h.status,
      h.lifecycle_state,
      h.updated_at,
      (SELECT COUNT(*) FROM hotel_images hi WHERE hi.hotel_id = h.id) AS image_count,
      (SELECT COUNT(*) FROM hotel_rooms hr WHERE hr.hotel_id = h.id) AS room_count,
      (
        SELECT hi.id FROM hotel_images hi
        WHERE hi.hotel_id = h.id
        ORDER BY hi.is_cover DESC, hi.position ASC, hi.created_at ASC
        LIMIT 1
      ) AS cover_image_id
    FROM hotels h
    WHERE h.id = ?
  `).bind(hotelID).first();
}

function hotelSummary(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    city: row.city,
    stars: row.stars == null ? null : Number(row.stars),
    rating: row.rating == null ? null : Number(row.rating),
    reviewCount: row.review_count == null ? null : Number(row.review_count),
    status: row.status,
    lifecycleState: row.lifecycle_state || row.status,
    coverImageURL: row.cover_image_id ? publicImagePath(row.id, row.cover_image_id) : null,
    imageCount: Number(row.image_count || 0),
    roomCount: Number(row.room_count || 0),
    updatedAt: row.updated_at
  };
}

function sourceRow(row) {
  return {
    id: row.id,
    provider: row.provider,
    sourceURL: row.source_url,
    name: row.source_name,
    city: row.city,
    country: row.country,
    propertyType: row.property_type,
    brand: row.brand || null,
    chain: row.chain_name || null,
    postalCode: row.postal_code || null,
    address: row.address,
    description: row.description,
    stars: row.stars == null ? null : Number(row.stars),
    rating: row.rating == null ? null : Number(row.rating),
    ratingScale: row.rating_scale == null ? null : Number(row.rating_scale),
    reviewCount: row.review_count == null ? null : Number(row.review_count),
    latitude: row.latitude == null ? null : Number(row.latitude),
    longitude: row.longitude == null ? null : Number(row.longitude),
    checkIn: row.check_in,
    checkOut: row.check_out,
    images: parseJSONArray(row.images_json),
    amenities: parseJSONArray(row.amenities_json),
    roomNames: parseJSONArray(row.room_names_json),
    rooms: parseJSONArray(row.room_details_json),
    policies: parseJSONArray(row.policies_json),
    providerHotelID: row.provider_hotel_id || null,
    canonicalURL: row.canonical_url || null,
    googleMapsURL: row.google_maps_url || null,
    nearby: parseJSONArray(row.nearby_json),
    facts: parseJSONArray(row.facts_json),
    fees: parseJSONArray(row.fees_json),
    services: parseJSONArray(row.services_json),
    highlights: parseJSONArray(row.highlights_json),
    importantInformation: parseJSONArray(row.important_information_json),
    food: parseJSONArray(row.food_json),
    parkingTransport: parseJSONArray(row.parking_transport_json),
    accessibility: parseJSONArray(row.accessibility_json),
    rawIdentity: parseJSONObject(row.raw_identity_json),
    checkedAt: row.checked_at
  };
}

async function uniqueSlug(env, hotelID, seed) {
  const base = slugify(seed) || `hotel-${hotelID.toLowerCase()}`;
  let candidate = base;
  for (let index = 0; index < 20; index += 1) {
    const row = await env.HOTELS_DB.prepare('SELECT id FROM hotels WHERE slug = ? AND id != ? LIMIT 1').bind(candidate, hotelID).first();
    if (!row) return candidate;
    candidate = `${base}-${index + 2}`;
  }
  return `${base}-${crypto.randomUUID().slice(0, 8)}`;
}

function publicImagePath(hotelID, imageID) {
  return `/api/catalog/hotels/${encodeURIComponent(hotelID)}/images/${encodeURIComponent(imageID)}`;
}

function pathParts(pathname, prefix) {
  const suffix = pathname.slice(prefix.length).replace(/^\/+|\/+$/g, '');
  return suffix ? suffix.split('/').map(decodeURIComponent) : [];
}

function safeID(value) {
  const text = String(value || '').trim();
  return /^[A-Za-z0-9._:-]{1,128}$/.test(text) ? text : null;
}

function cleanText(value, maxLength = 1000) {
  if (value == null) return null;
  const text = String(value).replace(/\u0000/g, '').trim();
  if (!text) return null;
  return text.slice(0, maxLength);
}

function canonicalCity(value) {
  const text = String(value || '').trim().toLowerCase();
  if (['makkah', 'mecca', 'makkah al mukarramah'].includes(text)) return 'Makkah';
  if (['madinah', 'medina', 'al madinah'].includes(text)) return 'Madinah';
  return cleanText(value, 80);
}

function cleanURL(value) {
  try {
    const url = new URL(String(value || ''));
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    return url.toString().slice(0, 3000);
  } catch {
    return null;
  }
}

function nullableInteger(value, min, max) {
  if (value == null || value === '') return null;
  const number = Number(value);
  if (!Number.isFinite(number)) return null;
  const integer = Math.trunc(number);
  return integer >= min && integer <= max ? integer : null;
}

function boundedInteger(value, min, max, fallback) {
  const parsed = nullableInteger(value, min, max);
  return parsed == null ? fallback : parsed;
}

function nullableNumber(value, min, max) {
  if (value == null || value === '') return null;
  const number = Number(value);
  if (!Number.isFinite(number) || number < min || number > max) return null;
  return number;
}


function isStructuredNoiseText(value) {
  const text = String(value || '').trim();
  if (!text) return false;
  const lower = text.toLowerCase();
  const tokens = [
    '\\"', '__typename', 'agencybusinessmodels', 'availability_group',
    'bedroomfilter', 'bed_type_group', 'startdate', 'trip-type',
    'shoppingproductcontent', 'egdsplaintext'
  ];
  if (tokens.some(token => lower.includes(token))) return true;
  if (text.includes('{') && (text.includes('"') || text.includes(':'))) return true;
  if (text.includes('[') && text.includes('"')) return true;
  if (lower.includes('see all about this property') && lower.includes('explore the area')) return true;
  if (lower.includes('free wififree cribs') || lower.includes('breakfast for a feerestaurant')) return true;
  return false;
}

function safeHumanText(value, maxLength = 1200) {
  const text = cleanText(value, maxLength);
  if (!text || isStructuredNoiseText(text)) return null;
  return text.replace(/\s+/g, ' ').trim();
}

function canonicalAmenity(value) {
  const text = safeHumanText(value, 240);
  if (!text) return null;
  const lower = text.toLowerCase();
  if (/free wi[- ]?fi|complimentary wi[- ]?fi/.test(lower)) return 'Free WiFi';
  if (/wi[- ]?fi|wireless internet/.test(lower)) return 'Wi‑Fi';
  if (/restaurants?/.test(lower)) return 'Restaurant';
  if (/coffee shop|café|cafe/.test(lower)) return 'Coffee shop';
  if (/24[- ]hour front desk|24 hour front desk/.test(lower)) return '24-hour front desk';
  if (/fitness cent(?:er|re)|\bgym\b/.test(lower)) return 'Fitness center';
  if (/swimming pool|outdoor pool|indoor pool/.test(lower)) return 'Swimming pool';
  if (/airport shuttle|shuttle service/.test(lower)) return 'Airport shuttle';
  if (/valet parking/.test(lower)) return 'Valet parking';
  if (/luggage storage|baggage storage/.test(lower)) return 'Luggage storage';
  return text;
}

function canonicalAmenities(value, maxItems = 320) {
  if (!Array.isArray(value)) return [];
  const result = [];
  const seen = new Set();
  for (const raw of value) {
    const item = canonicalAmenity(raw);
    if (!item) continue;
    const key = item.toLowerCase();
    if (key === 'wi‑fi' && seen.has('free wifi')) continue;
    if (key === 'free wifi') {
      const index = result.findIndex(x => x.toLowerCase() === 'wi‑fi');
      if (index >= 0) result.splice(index, 1);
      seen.delete('wi‑fi');
    }
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(item);
    if (result.length >= maxItems) break;
  }
  return result;
}

function uniqueStrings(value, maxItems, maxLength) {
  if (!Array.isArray(value)) return [];
  const result = [];
  const seen = new Set();
  for (const item of value) {
    const text = safeHumanText(item, maxLength);
    if (!text) continue;
    const key = text.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(text);
    if (result.length >= maxItems) break;
  }
  return result;
}


function safeObjectArray(value, maxItems = 120, maxBytes = 30_000) {
  if (!Array.isArray(value)) return [];
  const result = [];
  const seen = new Set();
  let used = 2;
  for (const item of value) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
    const clean = {};
    let rejected = false;
    for (const [key, raw] of Object.entries(item)) {
      const safeKey = String(key).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
      if (!safeKey) continue;
      if (typeof raw === 'string') {
        const text = safeHumanText(raw, 1200);
        if (!text && String(raw || '').trim()) { rejected = true; break; }
        clean[safeKey] = text;
      } else if (typeof raw === 'number' && Number.isFinite(raw)) clean[safeKey] = raw;
      else if (typeof raw === 'boolean') clean[safeKey] = raw;
      else if (raw == null) clean[safeKey] = null;
    }
    if (rejected) continue;
    const encoded = JSON.stringify(clean);
    if (encoded === '{}' || used + encoded.length > maxBytes) continue;
    const signature = encoded.toLowerCase();
    if (seen.has(signature)) continue;
    seen.add(signature);
    result.push(clean);
    used += encoded.length + 1;
    if (result.length >= maxItems) break;
  }
  return result;
}

function sanitizeObject(value, maxBytes = 30_000) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const clean = {};
  for (const [key, raw] of Object.entries(value)) {
    const safeKey = String(key).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
    if (!safeKey) continue;
    if (typeof raw === 'string') clean[safeKey] = cleanText(raw, 2000);
    else if (typeof raw === 'number' && Number.isFinite(raw)) clean[safeKey] = raw;
    else if (typeof raw === 'boolean') clean[safeKey] = raw;
    else if (raw == null) clean[safeKey] = null;
  }
  const encoded = JSON.stringify(clean);
  return encoded.length <= maxBytes ? clean : {};
}

function cleanLifecycleState(value) {
  const state = cleanText(value, 40);
  return ['draft','importing','ready','published','failed','archived'].includes(state) ? state : null;
}

function parseJSONObject(value) {
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value || '{}') : value;
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function validImageCategory(value) {
  const category = cleanText(typeof value === 'string' ? value : value?.rawValue, 30);
  return ['exterior','room','bathroom','lobby','restaurant','breakfast','gym','spa','pool','lounge','facility','amenity','view','gallery','other'].includes(category) ? category : null;
}

function isPlausibleRoomName(value) {
  const text = cleanText(value, 260);
  if (!text || text.length < 4 || text.length > 240) return false;
  const lower = text.toLowerCase();
  const roomToken = /(room|suite|studio|apartment|villa|king|queen|twin|double|triple|quad|family|deluxe|superior|classic|standard|executive|premier|номер|люкс|комнат|غرفة|جناح)/i;
  const blocked = /(how much|parking|breakfast|restaurant|front desk|reception|concierge|room service|meeting room|prayer room|laundry room|locker room|non-smoking rooms|family rooms|guest rooms|choose your room|select room|room amenities|frequently asked|question|answer|policy|check[- ]?in|check[- ]?out)/i;
  if (!roomToken.test(text) || blocked.test(text)) return false;
  if (/[?؟]$/.test(text)) return false;
  const words = lower.split(/\s+/).filter(Boolean);
  if (words.length > 24) return false;
  return true;
}

function canonicalSourceURL(value) {
  try {
    const url = new URL(String(value || ''));
    url.hash = '';
    const keep = new Set(['hotelid','hotel_id','propertyid','property_id','id']);
    for (const key of [...url.searchParams.keys()]) {
      if (!keep.has(key.toLowerCase())) url.searchParams.delete(key);
    }
    url.hostname = url.hostname.toLowerCase().replace(/^www\./, '');
    url.pathname = url.pathname.replace(/\/+$/, '') || '/';
    return url.toString().slice(0, 3000);
  } catch {
    return null;
  }
}

function canonicalHotelKey(name, city, address, latitude, longitude) {
  const namePart = [...hotelNameTokens(name)].sort().join('-');
  const cityPart = slugify(canonicalCity(city) || city || '');
  let locationPart = '';
  const lat = nullableNumber(latitude, -90, 90);
  const lng = nullableNumber(longitude, -180, 180);
  if (lat != null && lng != null) locationPart = `${lat.toFixed(3)}:${lng.toFixed(3)}`;
  else locationPart = [...addressTokens(normalizedAddress(address))].slice(0, 8).join('-');
  return cleanText(`${cityPart}|${namePart}|${locationPart}`, 600);
}

function normalizedAddress(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\b(saudi arabia|kingdom of saudi arabia|ksa)\b/g, ' ')
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function hotelNameTokens(value) {
  const stop = new Set(['hotel','hotels','resort','resorts','by','the','makkah','mecca','madinah','medina','saudi','arabia','ksa','فندق']);
  const text = String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, ' ');
  return new Set(text.split(/\s+/).filter(token => token.length > 1 && !stop.has(token)));
}

function addressTokens(value) {
  const stop = new Set(['street','st','road','rd','district','area','saudi','arabia','makkah','mecca','madinah','medina']);
  return new Set(String(value || '').split(/\s+/).filter(token => token.length > 1 && !stop.has(token)));
}

function tokenSimilarity(a, b) {
  if (!(a instanceof Set) || !(b instanceof Set) || !a.size || !b.size) return 0;
  let overlap = 0;
  for (const token of a) if (b.has(token)) overlap += 1;
  return overlap / Math.max(a.size, b.size);
}

function haversineMeters(lat1, lon1, lat2, lon2) {
  const toRad = deg => deg * Math.PI / 180;
  const R = 6371000;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function googleMapsURL(latitude, longitude, address) {
  const lat = nullableNumber(latitude, -90, 90);
  const lng = nullableNumber(longitude, -180, 180);
  const query = lat != null && lng != null ? `${lat},${lng}` : cleanText(address, 900);
  return query ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}` : null;
}

function slugify(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 140);
}

function parseJSONArray(value) {
  try {
    const parsed = JSON.parse(value || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function readJSON(request, maxBytes) {
  const contentLength = Number(request.headers.get('content-length') || 0);
  if (contentLength > maxBytes) {
    return { ok: false, response: json({ ok: false, error: 'PAYLOAD_TOO_LARGE' }, 413) };
  }

  let text;
  try {
    text = await request.text();
  } catch {
    return { ok: false, response: json({ ok: false, error: 'INVALID_BODY' }, 400) };
  }

  if (new TextEncoder().encode(text).byteLength > maxBytes) {
    return { ok: false, response: json({ ok: false, error: 'PAYLOAD_TOO_LARGE' }, 413) };
  }

  try {
    return { ok: true, value: JSON.parse(text) };
  } catch {
    return { ok: false, response: json({ ok: false, error: 'INVALID_JSON' }, 400) };
  }
}

function methodNotAllowed() {
  return json({ ok: false, error: 'METHOD_NOT_ALLOWED' }, 405);
}

function json(value, status = 200, extraHeaders) {
  const headers = new Headers(JSON_HEADERS);
  if (extraHeaders) {
    Object.entries(extraHeaders).forEach(([key, value]) => headers.set(key, value));
  }
  return new Response(JSON.stringify(value), { status, headers });
}

function corsHeaders(request) {
  const origin = request.headers.get('origin') || '';
  const allowed = origin === 'https://iumrah.app' || origin === 'https://www.iumrah.app';
  return {
    'access-control-allow-origin': allowed ? origin : 'https://iumrah.app',
    'access-control-allow-credentials': 'true',
    'access-control-allow-methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
    'access-control-allow-headers': 'Content-Type,Authorization,Idempotency-Key,X-Iumrah-Allow-Possible-Duplicate,X-Iumrah-Source,X-Iumrah-Position,X-Iumrah-Cover,X-Iumrah-Category,X-Iumrah-Source-URL,X-Iumrah-Label,X-Iumrah-Room',
    'vary': 'Origin'
  };
}

function withCors(response, request) {
  const headers = new Headers(response.headers);
  Object.entries(corsHeaders(request)).forEach(([key, value]) => headers.set(key, value));
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}
