import { obtainHotelPrice, safePropertyKey } from './hotel-price-source.js';
import { HOTEL_PRICE_TTL_MS } from './hotel-price.js';

const JSON_HEADERS = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store'
};

function json(value, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(value), { status, headers: { ...JSON_HEADERS, ...extraHeaders } });
}

function cleanText(value, maxLength = 1000) {
  if (value == null) return null;
  const text = String(value).replace(/\u0000/g, '').trim();
  return text ? text.slice(0, maxLength) : null;
}

function cleanURL(value) {
  try {
    const url = new URL(String(value || ''));
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    return url.toString().slice(0, 3000);
  } catch { return null; }
}

function safeID(value) {
  const text = String(value || '').trim();
  return /^[A-Za-z0-9._:-]{1,128}$/.test(text) ? text : null;
}

function providerName(value, sourceURL = '') {
  const raw = String(value || '').trim().toLowerCase();
  if (raw === 'booking' || raw === 'booking.com') return 'Booking';
  if (raw === 'expedia' || raw === 'expedia.com') return 'Expedia';
  try {
    const host = new URL(sourceURL).hostname.toLowerCase();
    if (host === 'booking.com' || host.endsWith('.booking.com')) return 'Booking';
    if (host === 'expedia.com' || host.endsWith('.expedia.com') || host === 'expedia.sa' || host.endsWith('.expedia.sa')) return 'Expedia';
  } catch (_) {}
  return null;
}

async function hashToken(value) {
  const bytes = new TextEncoder().encode(String(value || ''));
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

function randomToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return [...bytes].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

async function ensurePriceSource(env, hotelID) {
  const expedia = await env.HOTELS_DB.prepare(`
    SELECT hs.id AS source_id, hs.provider, hs.source_url, hs.canonical_url
    FROM hotel_sources hs
    LEFT JOIN hotel_price_cache hp ON hp.hotel_id=hs.hotel_id
    WHERE hs.hotel_id=? AND LOWER(hs.provider) IN ('expedia','expedia.com')
      AND hs.source_url IS NOT NULL AND hs.source_url!=''
    ORDER BY CASE WHEN hp.source_id=hs.id THEN 0 WHEN hp.source_url=hs.source_url THEN 1 ELSE 2 END,
             hs.checked_at DESC
    LIMIT 1
  `).bind(hotelID).first().catch(() => null);

  const existing = await env.HOTELS_DB.prepare(`
    SELECT hps.source_id, hps.provider, hps.source_url, hs.canonical_url
    FROM hotel_price_sources hps
    LEFT JOIN hotel_sources hs ON hs.id=hps.source_id AND hs.hotel_id=hps.hotel_id
    WHERE hps.hotel_id=? LIMIT 1
  `).bind(hotelID).first().catch(() => null);

  let row = expedia || existing;
  if (!row?.source_url) {
    row = await env.HOTELS_DB.prepare(`
      SELECT hs.id AS source_id, hs.provider, hs.source_url, hs.canonical_url
      FROM hotel_sources hs
      WHERE hs.hotel_id=?
        AND LOWER(hs.provider) IN ('booking','booking.com','expedia','expedia.com')
        AND hs.source_url IS NOT NULL AND hs.source_url!=''
      ORDER BY CASE WHEN LOWER(hs.provider) IN ('expedia','expedia.com') THEN 0 ELSE 1 END,
               hs.checked_at DESC
      LIMIT 1
    `).bind(hotelID).first();
  }
  if (!row?.source_url) return null;

  const provider = providerName(row.provider, row.source_url);
  if (!provider) return null;
  const now = new Date().toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO hotel_price_sources (hotel_id, source_id, provider, source_url, locked_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(hotel_id) DO UPDATE SET
      source_id=excluded.source_id,
      provider=excluded.provider,
      source_url=excluded.source_url,
      updated_at=excluded.updated_at
  `).bind(hotelID, row.source_id, provider, row.source_url, now, now).run();
  return { ...row, provider };
}

async function currentHotelPrice(env, hotelID) {
  return env.HOTELS_DB.prepare(`
    SELECT h.id, h.name, h.city, h.stars,
      hp.nightly_price_usd AS source_nightly_usd,
      hpo.nightly_price_usd AS manual_nightly_usd,
      COALESCE(hpo.nightly_price_usd, hp.nightly_price_usd) AS effective_nightly_usd
    FROM hotels h
    LEFT JOIN hotel_price_cache hp ON hp.hotel_id=h.id
    LEFT JOIN hotel_price_overrides hpo ON hpo.hotel_id=h.id
    WHERE h.id=? LIMIT 1
  `).bind(hotelID).first();
}

async function probeHotelPrice(env, hotelID) {
  const hotel = await currentHotelPrice(env, hotelID);
  if (!hotel) throw new Error('HOTEL_NOT_FOUND');
  const source = await ensurePriceSource(env, hotelID);
  if (!source?.source_url) throw new Error('HOTEL_PRICE_SOURCE_MISSING');

  const sourceURL = cleanURL(source.source_url);
  if (!sourceURL) throw new Error('HOTEL_PRICE_SOURCE_INVALID');
  const provider = providerName(source.provider, sourceURL);
  if (!provider) throw new Error('HOTEL_PRICE_SOURCE_UNSUPPORTED');

  let priceURL = sourceURL;
  const lockedKey = safePropertyKey(sourceURL, provider);
  if (!lockedKey && source.canonical_url && safePropertyKey(source.canonical_url, provider)) {
    priceURL = source.canonical_url;
  }
  if (!safePropertyKey(priceURL, provider)) throw new Error('HOTEL_PRICE_SOURCE_PROPERTY_MISMATCH');

  const page = await obtainHotelPrice(env, priceURL, provider);
  const { quote, extracted, finalURL } = page;
  const oldPrice = Number(hotel.effective_nightly_usd);
  const candidate = Number(extracted.nightlyUSD);
  const changed = !Number.isFinite(oldPrice) || oldPrice <= 0 || Math.abs(oldPrice - candidate) >= 0.01;
  return {
    hotel,
    provider,
    sourceURL,
    resolvedURL: finalURL || priceURL,
    oldNightlyUSD: Number.isFinite(oldPrice) && oldPrice > 0 ? Math.round(oldPrice * 100) / 100 : null,
    candidateNightlyUSD: Math.round(candidate * 100) / 100,
    amountOriginal: Number(extracted.amount),
    currencyOriginal: cleanText(extracted.currency, 24),
    priceBasis: cleanText(extracted.priceBasis, 60) || 'nightly',
    quoteTotalUSD: Number.isFinite(Number(extracted.stayTotalUSD)) ? Number(extracted.stayTotalUSD) : null,
    quoteCheckIn: cleanText(quote?.checkIn, 40),
    quoteCheckOut: cleanText(quote?.checkOut, 40),
    quoteNights: Number(quote?.nights || 1),
    quoteAdults: Number(quote?.adults || 2),
    quoteRooms: Number(quote?.rooms || 1),
    confidence: Number(extracted.confidence || 0),
    method: cleanText(`${page.transport}:${extracted.method}`, 180),
    httpStatus: Number(page.httpStatus || 200),
    changed
  };
}

function monitorItem(row) {
  const oldPrice = row.old_nightly_usd == null ? null : Number(row.old_nightly_usd);
  const candidate = row.candidate_nightly_usd == null ? null : Number(row.candidate_nightly_usd);
  const delta = oldPrice != null && candidate != null ? Math.round((candidate - oldPrice) * 100) / 100 : null;
  const deltaPercent = oldPrice != null && oldPrice > 0 && candidate != null
    ? Math.round(((candidate - oldPrice) / oldPrice) * 10000) / 100
    : null;
  return {
    id: row.id,
    runID: row.run_id,
    hotelID: row.hotel_id,
    hotelName: row.hotel_name,
    city: row.city || null,
    stars: row.stars == null ? null : Number(row.stars),
    provider: row.provider || null,
    sourceURL: row.source_url || null,
    resolvedURL: row.resolved_url || null,
    oldNightlyUSD: oldPrice,
    candidateNightlyUSD: candidate,
    deltaUSD: delta,
    deltaPercent,
    confidence: row.confidence == null ? null : Number(row.confidence),
    method: row.method || null,
    status: row.status,
    error: row.error || null,
    checkedAt: row.checked_at || null,
    publishedAt: row.published_at || null
  };
}

function monitorRun(row, items = null) {
  return {
    id: row.id,
    status: row.status,
    totalHotels: Number(row.total_hotels || 0),
    checkedHotels: Number(row.checked_hotels || 0),
    changedHotels: Number(row.changed_hotels || 0),
    unchangedHotels: Number(row.unchanged_hotels || 0),
    failedHotels: Number(row.failed_hotels || 0),
    publishedHotels: Number(row.published_hotels || 0),
    error: row.error || null,
    createdAt: row.created_at,
    startedAt: row.started_at || null,
    completedAt: row.completed_at || null,
    updatedAt: row.updated_at,
    ...(items ? { items } : {})
  };
}

async function monitorRunDetail(env, runID) {
  const run = await env.HOTELS_DB.prepare('SELECT * FROM hotel_price_monitor_runs WHERE id=? LIMIT 1').bind(runID).first();
  if (!run) return null;
  const rows = await env.HOTELS_DB.prepare(`
    SELECT * FROM hotel_price_monitor_items WHERE run_id=?
    ORDER BY CASE status WHEN 'changed' THEN 0 WHEN 'failed' THEN 1 WHEN 'unchanged' THEN 2 WHEN 'published' THEN 3 ELSE 4 END,
             hotel_name COLLATE NOCASE ASC
  `).bind(runID).all();
  return monitorRun(run, (rows.results || []).map(monitorItem));
}

export async function handlePriceMonitorAdmin(request, env, url, parts, user) {
  if (parts.length === 0) {
    if (request.method === 'GET') {
      const rows = await env.HOTELS_DB.prepare('SELECT * FROM hotel_price_monitor_runs ORDER BY created_at DESC LIMIT 30').all();
      return json({ ok: true, runs: (rows.results || []).map(row => monitorRun(row)) });
    }
    if (request.method === 'POST') {
      const active = await env.HOTELS_DB.prepare("SELECT id FROM hotel_price_monitor_runs WHERE status IN ('queued','running') ORDER BY created_at DESC LIMIT 1").first();
      if (active?.id) {
        const existing = await monitorRunDetail(env, active.id);
        return json({ ok: true, reused: true, run: existing }, 200);
      }

      const hotels = await env.HOTELS_DB.prepare(`
        SELECT h.id, h.name, h.city, h.stars
        FROM hotels h
        WHERE h.status='published'
        ORDER BY CASE LOWER(h.city) WHEN 'makkah' THEN 0 WHEN 'madinah' THEN 1 ELSE 2 END, h.name COLLATE NOCASE
        LIMIT 200
      `).all();
      const rows = hotels.results || [];
      if (!rows.length) return json({ ok: false, error: 'NO_PUBLISHED_HOTELS' }, 409);

      const runID = `price-monitor-${crypto.randomUUID()}`;
      const now = new Date().toISOString();
      const statements = [env.HOTELS_DB.prepare(`
        INSERT INTO hotel_price_monitor_runs (id,status,requested_by,total_hotels,created_at,updated_at)
        VALUES (?, 'queued', ?, ?, ?, ?)
      `).bind(runID, cleanText(user?.login, 180), rows.length, now, now)];
      for (const hotel of rows) {
        statements.push(env.HOTELS_DB.prepare(`
          INSERT INTO hotel_price_monitor_items (id,run_id,hotel_id,hotel_name,city,stars,status,created_at,updated_at)
          VALUES (?, ?, ?, ?, ?, ?, 'queued', ?, ?)
        `).bind(crypto.randomUUID(), runID, hotel.id, hotel.name, hotel.city, hotel.stars, now, now));
      }
      await env.HOTELS_DB.batch(statements);

      try {
        const instance = await env.HOTEL_PRICE_MONITOR_WORKFLOW.create({ id: runID, params: { runID } });
        await env.HOTELS_DB.prepare('UPDATE hotel_price_monitor_runs SET workflow_instance_id=?, updated_at=? WHERE id=?')
          .bind(instance.id, new Date().toISOString(), runID).run();
      } catch (error) {
        const failedAt = new Date().toISOString();
        await env.HOTELS_DB.prepare("UPDATE hotel_price_monitor_runs SET status='failed', error=?, completed_at=?, updated_at=? WHERE id=?")
          .bind(cleanText(error?.message, 1200) || 'PRICE_MONITOR_WORKFLOW_START_FAILED', failedAt, failedAt, runID).run();
        return json({ ok: false, error: 'PRICE_MONITOR_WORKFLOW_START_FAILED', runID }, 503);
      }
      return json({ ok: true, run: await monitorRunDetail(env, runID) }, 202);
    }
    return json({ ok: false, error: 'METHOD_NOT_ALLOWED' }, 405);
  }

  const runID = safeID(parts[0]);
  if (!runID) return json({ ok: false, error: 'INVALID_MONITOR_RUN_ID' }, 400);

  if (parts.length === 1 && request.method === 'GET') {
    const run = await monitorRunDetail(env, runID);
    return run ? json({ ok: true, run }) : json({ ok: false, error: 'MONITOR_RUN_NOT_FOUND' }, 404);
  }

  if (parts.length === 2 && parts[1] === 'publish' && request.method === 'POST') {
    let body = {};
    try { body = await request.json(); } catch (_) {}
    const requestedIDs = Array.isArray(body?.hotelIDs) ? body.hotelIDs.map(safeID).filter(Boolean) : [];
    const publishAll = body?.all === true;
    if (!publishAll && !requestedIDs.length) return json({ ok: false, error: 'NO_HOTELS_SELECTED' }, 400);

    const placeholders = requestedIDs.map(() => '?').join(',');
    const query = publishAll
      ? `SELECT * FROM hotel_price_monitor_items WHERE run_id=? AND status IN ('changed','unchanged')`
      : `SELECT * FROM hotel_price_monitor_items WHERE run_id=? AND hotel_id IN (${placeholders}) AND status IN ('changed','unchanged')`;
    const selected = publishAll
      ? await env.HOTELS_DB.prepare(query).bind(runID).all()
      : await env.HOTELS_DB.prepare(query).bind(runID, ...requestedIDs).all();
    const rows = selected.results || [];
    if (!rows.length) return json({ ok: false, error: 'NO_PUBLISHABLE_MONITOR_ITEMS' }, 409);

    let published = 0;
    for (const row of rows) {
      await publishMonitorItem(env, row, user);
      published += 1;
    }
    await refreshRunCounters(env, runID);
    return json({ ok: true, published, run: await monitorRunDetail(env, runID) });
  }

  return json({ ok: false, error: 'NOT_FOUND' }, 404);
}

async function publishMonitorItem(env, row, user) {
  const candidate = Number(row.candidate_nightly_usd);
  if (!Number.isFinite(candidate) || candidate <= 0) throw new Error('INVALID_MONITOR_CANDIDATE');
  const nowDate = new Date();
  const now = nowDate.toISOString();
  const expiresAt = new Date(nowDate.getTime() + HOTEL_PRICE_TTL_MS).toISOString();
  const source = await ensurePriceSource(env, row.hotel_id);
  if (!source?.source_id || !source?.source_url) throw new Error('HOTEL_PRICE_SOURCE_MISSING');

  await env.HOTELS_DB.batch([
    env.HOTELS_DB.prepare(`
      INSERT INTO hotel_price_cache (
        hotel_id, source_id, provider, source_url, resolved_url,
        amount_original, currency_original, price_basis, nightly_price_usd, quote_total_usd,
        quote_check_in, quote_check_out, quote_nights, quote_adults, quote_rooms,
        confidence, method, status, fetched_at, expires_at, last_attempt_at, next_retry_at,
        last_http_status, error, pending_nightly_price_usd, pending_seen_count,
        pending_first_seen_at, pending_last_seen_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'fresh', ?, ?, ?, NULL, ?, NULL, NULL, 0, NULL, NULL, ?, ?)
      ON CONFLICT(hotel_id) DO UPDATE SET
        source_id=excluded.source_id, provider=excluded.provider, source_url=excluded.source_url,
        resolved_url=excluded.resolved_url, amount_original=excluded.amount_original,
        currency_original=excluded.currency_original, price_basis=excluded.price_basis,
        nightly_price_usd=excluded.nightly_price_usd, quote_total_usd=excluded.quote_total_usd,
        quote_check_in=excluded.quote_check_in, quote_check_out=excluded.quote_check_out,
        quote_nights=excluded.quote_nights, quote_adults=excluded.quote_adults, quote_rooms=excluded.quote_rooms,
        confidence=excluded.confidence, method=excluded.method, status='fresh', fetched_at=excluded.fetched_at,
        expires_at=excluded.expires_at, last_attempt_at=excluded.last_attempt_at, next_retry_at=NULL,
        last_http_status=excluded.last_http_status, error=NULL, pending_nightly_price_usd=NULL,
        pending_seen_count=0, pending_first_seen_at=NULL, pending_last_seen_at=NULL, updated_at=excluded.updated_at
    `).bind(
      row.hotel_id, source.source_id, row.provider || source.provider, source.source_url, row.resolved_url || source.source_url,
      row.amount_original, row.currency_original, row.price_basis || 'nightly', candidate, row.quote_total_usd,
      row.quote_check_in, row.quote_check_out, row.quote_nights || 1, row.quote_adults || 2, row.quote_rooms || 1,
      row.confidence, row.method || 'price-monitor', now, expiresAt, now, row.http_status || 200, now, now
    ),
    env.HOTELS_DB.prepare('DELETE FROM hotel_price_overrides WHERE hotel_id=?').bind(row.hotel_id),
    env.HOTELS_DB.prepare(`
      UPDATE hotel_price_monitor_items
      SET status='published', published_at=?, published_by=?, updated_at=?
      WHERE id=?
    `).bind(now, cleanText(user?.login, 180), now, row.id)
  ]);
}

async function refreshRunCounters(env, runID) {
  const counts = await env.HOTELS_DB.prepare(`
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN status NOT IN ('queued','checking') THEN 1 ELSE 0 END) AS checked,
      SUM(CASE
        WHEN status='changed' THEN 1
        WHEN status='published' AND (old_nightly_usd IS NULL OR ABS(candidate_nightly_usd-old_nightly_usd) >= 0.01) THEN 1
        ELSE 0 END) AS changed,
      SUM(CASE
        WHEN status='unchanged' THEN 1
        WHEN status='published' AND old_nightly_usd IS NOT NULL AND ABS(candidate_nightly_usd-old_nightly_usd) < 0.01 THEN 1
        ELSE 0 END) AS unchanged,
      SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed,
      SUM(CASE WHEN status='published' THEN 1 ELSE 0 END) AS published
    FROM hotel_price_monitor_items WHERE run_id=?
  `).bind(runID).first();
  await env.HOTELS_DB.prepare(`
    UPDATE hotel_price_monitor_runs SET
      total_hotels=?, checked_hotels=?, changed_hotels=?, unchanged_hotels=?, failed_hotels=?, published_hotels=?, updated_at=?
    WHERE id=?
  `).bind(
    Number(counts?.total || 0), Number(counts?.checked || 0), Number(counts?.changed || 0), Number(counts?.unchanged || 0),
    Number(counts?.failed || 0), Number(counts?.published || 0), new Date().toISOString(), runID
  ).run();
}

export async function handleChatGPTLinksAdmin(request, env, user) {
  if (request.method !== 'POST') return json({ ok: false, error: 'METHOD_NOT_ALLOWED' }, 405);
  let body = {};
  try { body = await request.json(); } catch (_) {}
  const runID = body?.runID ? safeID(body.runID) : null;
  const scope = runID ? 'price_monitor_run' : 'hotel_catalog';
  if (runID) {
    const run = await env.HOTELS_DB.prepare('SELECT id FROM hotel_price_monitor_runs WHERE id=? LIMIT 1').bind(runID).first();
    if (!run) return json({ ok: false, error: 'MONITOR_RUN_NOT_FOUND' }, 404);
  }

  const token = randomToken();
  const tokenHash = await hashToken(token);
  const id = crypto.randomUUID();
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 30 * 60 * 1000).toISOString();
  await env.HOTELS_DB.prepare(`
    INSERT INTO chatgpt_access_links (id, token_hash, scope, run_id, created_by, expires_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).bind(id, tokenHash, scope, runID, cleanText(user?.login, 180), expiresAt, now.toISOString()).run();

  return json({
    ok: true,
    scope,
    expiresAt,
    url: `https://iumrah.app/api/iumrah/chatgpt/${token}`
  }, 201);
}

export async function handleChatGPTPublic(request, env, url) {
  if (request.method !== 'GET') return json({ ok: false, error: 'METHOD_NOT_ALLOWED' }, 405);
  const prefix = '/api/iumrah/chatgpt/';
  const token = url.pathname.startsWith(prefix) ? url.pathname.slice(prefix.length).replace(/\/+$/, '') : '';
  if (!/^[a-f0-9]{64}$/i.test(token)) return json({ ok: false, error: 'INVALID_ACCESS_LINK' }, 404);
  const tokenHash = await hashToken(token);
  const now = new Date().toISOString();
  const link = await env.HOTELS_DB.prepare(`
    SELECT * FROM chatgpt_access_links
    WHERE token_hash=? AND revoked_at IS NULL AND expires_at>?
    LIMIT 1
  `).bind(tokenHash, now).first();
  if (!link) return json({ ok: false, error: 'ACCESS_LINK_EXPIRED' }, 410);
  await env.HOTELS_DB.prepare('UPDATE chatgpt_access_links SET last_used_at=? WHERE id=?').bind(now, link.id).run().catch(() => {});

  if (link.scope === 'price_monitor_run' && link.run_id) {
    const run = await monitorRunDetail(env, link.run_id);
    if (!run) return json({ ok: false, error: 'MONITOR_RUN_NOT_FOUND' }, 404);
    return json({
      ok: true,
      type: 'iumrah_price_monitor_run',
      readOnly: true,
      expiresAt: link.expires_at,
      instructions: 'Read-only iumrah Business price-monitor result. Analyze changes; do not claim that prices were published unless item.status is published.',
      run
    });
  }

  const rows = await env.HOTELS_DB.prepare(`
    SELECT h.id, h.name, h.city, h.stars, h.status,
      hps.provider, hps.source_url,
      COALESCE(hpo.nightly_price_usd, hp.nightly_price_usd) AS nightly_usd,
      hp.fetched_at, hp.status AS price_status
    FROM hotels h
    LEFT JOIN hotel_price_sources hps ON hps.hotel_id=h.id
    LEFT JOIN hotel_price_cache hp ON hp.hotel_id=h.id
    LEFT JOIN hotel_price_overrides hpo ON hpo.hotel_id=h.id
    WHERE h.status='published'
    ORDER BY CASE LOWER(h.city) WHEN 'makkah' THEN 0 WHEN 'madinah' THEN 1 ELSE 2 END, h.name COLLATE NOCASE
    LIMIT 500
  `).all();
  return json({
    ok: true,
    type: 'iumrah_hotel_catalog',
    readOnly: true,
    expiresAt: link.expires_at,
    hotels: (rows.results || []).map(row => ({
      id: row.id, name: row.name, city: row.city, stars: row.stars == null ? null : Number(row.stars),
      provider: row.provider || null, sourceURL: row.source_url || null,
      nightlyUSD: row.nightly_usd == null ? null : Number(row.nightly_usd),
      priceStatus: row.price_status || null, fetchedAt: row.fetched_at || null
    }))
  });
}

export async function runHotelPriceMonitorWorkflow(env, event, step) {
    const runID = safeID(event.payload?.runID);
    if (!runID) throw new Error('INVALID_PRICE_MONITOR_RUN_ID');

    await step.do('mark price monitor running', async () => {
      const now = new Date().toISOString();
      await env.HOTELS_DB.prepare("UPDATE hotel_price_monitor_runs SET status='running', started_at=COALESCE(started_at,?), updated_at=? WHERE id=?")
        .bind(now, now, runID).run();
      return { ok: true };
    });

    const result = await env.HOTELS_DB.prepare(`
      SELECT id, hotel_id FROM hotel_price_monitor_items WHERE run_id=? ORDER BY hotel_name COLLATE NOCASE
    `).bind(runID).all();
    const items = result.results || [];

    for (let index = 0; index < items.length; index += 1) {
      const item = items[index];
      const stepName = `check hotel ${String(index + 1).padStart(3, '0')}`;
      let outcome;
      try {
        outcome = await step.do(stepName, { retries: { limit: 1, delay: '3 seconds' }, timeout: '120 seconds' }, async () => {
          const started = new Date().toISOString();
          await env.HOTELS_DB.prepare("UPDATE hotel_price_monitor_items SET status='checking', error=NULL, updated_at=? WHERE id=?")
            .bind(started, item.id).run();
          return probeHotelPrice(env, item.hotel_id);
        });

        const now = new Date().toISOString();
        await env.HOTELS_DB.prepare(`
          UPDATE hotel_price_monitor_items SET
            provider=?, source_url=?, resolved_url=?, old_nightly_usd=?, candidate_nightly_usd=?,
            amount_original=?, currency_original=?, price_basis=?, quote_total_usd=?, quote_check_in=?, quote_check_out=?,
            quote_nights=?, quote_adults=?, quote_rooms=?, confidence=?, method=?, http_status=?, status=?, error=NULL,
            checked_at=?, updated_at=?
          WHERE id=?
        `).bind(
          outcome.provider, outcome.sourceURL, outcome.resolvedURL, outcome.oldNightlyUSD, outcome.candidateNightlyUSD,
          outcome.amountOriginal, outcome.currencyOriginal, outcome.priceBasis, outcome.quoteTotalUSD, outcome.quoteCheckIn, outcome.quoteCheckOut,
          outcome.quoteNights, outcome.quoteAdults, outcome.quoteRooms, outcome.confidence, outcome.method, outcome.httpStatus,
          outcome.changed ? 'changed' : 'unchanged', now, now, item.id
        ).run();
      } catch (error) {
        const now = new Date().toISOString();
        await env.HOTELS_DB.prepare(`
          UPDATE hotel_price_monitor_items SET status='failed', error=?, checked_at=?, updated_at=? WHERE id=?
        `).bind(cleanText(error?.message, 500) || 'PRICE_CHECK_FAILED', now, now, item.id).run();
      }
      await refreshRunCounters(env, runID);
    }

    await step.do('finalize price monitor', async () => {
      await refreshRunCounters(env, runID);
      const run = await env.HOTELS_DB.prepare('SELECT failed_hotels FROM hotel_price_monitor_runs WHERE id=?').bind(runID).first();
      const now = new Date().toISOString();
      const status = Number(run?.failed_hotels || 0) > 0 ? 'completed_with_errors' : 'completed';
      await env.HOTELS_DB.prepare('UPDATE hotel_price_monitor_runs SET status=?, completed_at=?, updated_at=? WHERE id=?')
        .bind(status, now, now, runID).run();
      return { ok: true, status };
    });
  }
